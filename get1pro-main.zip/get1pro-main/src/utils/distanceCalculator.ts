
// This file is kept as a facade for backward compatibility
// It re-exports all distance calculation related functionality

import { calculateDistance } from './distance/calculateDistance';
import { useDistanceCalculator } from './distance/useDistanceCalculator';
import { geocodeAddress } from './distance/geocodeAddress';
import { DistanceResult } from './distance/calculateDistance';

// Helper function to check if Google Maps API is loaded
export const isGoogleMapsLoaded = (): boolean => {
  return typeof window !== 'undefined' && 
         window.google && 
         window.google.maps && 
         window.google.maps.DistanceMatrixService !== undefined;
};

// Add API key for reference
export const GOOGLE_MAPS_API_KEY = 'AIzaSyDDiIHU7odJHeUvSsis3lBwxl5w8m6_bFE';

export { calculateDistance, useDistanceCalculator, geocodeAddress };
export type { DistanceResult };
