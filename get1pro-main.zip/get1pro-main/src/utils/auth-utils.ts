
import { supabase } from '@/integrations/supabase/client';

export const signUp = async (email: string, password: string, name: string) => {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
        },
      },
    });

    if (error) {
      console.error("Sign up error:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, error: null, data };
  } catch (error: any) {
    console.error("Unexpected sign up error:", error.message);
    return { success: false, error: error.message };
  }
};

export const signIn = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error("Sign in error:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, error: null, data };
  } catch (error: any) {
    console.error("Unexpected sign in error:", error.message);
    return { success: false, error: error.message };
  }
};

export const signOut = async () => {
  try {
    await supabase.auth.signOut();
    return { success: true, error: null };
  } catch (error: any) {
    console.error("Sign out error:", error);
    return { success: false, error: error.message };
  }
};

export const resendVerificationEmail = async (email: string) => {
  try {
    const { data, error } = await supabase.functions.invoke("verify-email", {
      body: { email }
    });

    if (error) {
      console.error("Error resending verification email:", error.message);
      return { success: false, error: error.message };
    }

    if (data.error) {
      console.error("Function returned error:", data.error);
      return { success: false, error: data.error };
    }

    return { success: true, error: null };
  } catch (error: any) {
    console.error("Unexpected error resending verification email:", error.message);
    return { success: false, error: error.message };
  }
};

export const verifyEmail = async (email: string, token: string) => {
  try {
    const { data, error } = await supabase.functions.invoke("verify-email", {
      body: { email, token }
    });

    if (error) {
      console.error("Error verifying email:", error.message);
      return { success: false, error: error.message };
    }

    if (data.error) {
      console.error("Function returned error:", data.error);
      return { success: false, error: data.error };
    }

    return { success: true, error: null };
  } catch (error: any) {
    console.error("Unexpected error verifying email:", error.message);
    return { success: false, error: error.message };
  }
};
