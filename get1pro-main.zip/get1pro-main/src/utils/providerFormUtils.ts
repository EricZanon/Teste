
import React from 'react';

/**
 * Handle form field change for provider profile
 */
export function handleFormFieldChange<T extends object>(
  e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  setProfile: React.Dispatch<React.SetStateAction<T>>
): void {
  const { name, value } = e.target;
  
  // Convert experience_years to number if it's a number field
  if (name === 'experience_years') {
    const numValue = value === '' ? null : Number(value);
    setProfile((prev) => ({ ...prev, [name]: numValue }));
  } else {
    setProfile((prev) => ({ ...prev, [name]: value }));
  }
}

/**
 * Handle select field change for provider profile
 */
export function handleSelectChange<T extends object>(
  name: string,
  value: string,
  setProfile: React.Dispatch<React.SetStateAction<T>>
): void {
  console.log(`Setting ${name} to ${value}`);
  setProfile((prev) => ({ ...prev, [name]: value }));
  
  // When changing country or state, we need to reset the dependent fields
  if (name === 'country') {
    setProfile(prev => ({ ...prev, state: '', city: '' }));
  } else if (name === 'state') {
    setProfile(prev => ({ ...prev, city: '' }));
  }
}
