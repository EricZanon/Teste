
// Utility functions for American phone number formatting

export const formatPhoneNumber = (value: string): string => {
  // Remove all non-numeric characters
  const phoneNumber = value.replace(/\D/g, '');
  
  // Apply American phone format: (XXX) XXX-XXXX
  if (phoneNumber.length === 0) return '';
  if (phoneNumber.length <= 3) return `(${phoneNumber}`;
  if (phoneNumber.length <= 6) return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
  return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
};

export const cleanPhoneNumber = (phoneNumber: string): string => {
  // Remove all formatting and return only numbers
  return phoneNumber.replace(/\D/g, '');
};

export const isValidPhoneNumber = (phoneNumber: string): boolean => {
  const cleaned = cleanPhoneNumber(phoneNumber);
  return cleaned.length === 10;
};

export const formatPhoneForDisplay = (phoneNumber: string): string => {
  if (!phoneNumber) return '';
  const cleaned = cleanPhoneNumber(phoneNumber);
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }
  return phoneNumber; // Return original if not standard format
};
