
import { findCityCode } from './cityCodeFinder';

interface CityMatcherProps {
  availableCities: string[];
  cityName: string;
  state: string;
}

export const findMatchingCity = async ({
  availableCities,
  cityName,
  state
}: CityMatcherProps): Promise<string | null> => {
  console.log('=== CITY MATCHER START ===');
  console.log('Available cities:', availableCities);
  console.log('Looking for city:', cityName, 'in state:', state);
  
  if (!cityName || !state) {
    console.log('Missing cityName or state');
    return null;
  }
  
  // Use the new Supabase-based city finder
  const cityCode = await findCityCode(state, cityName);
  console.log('City code from finder:', cityCode);
  
  // Check if the found city code is in the available cities list
  if (cityCode && availableCities.includes(cityCode)) {
    console.log('City code found in available cities:', cityCode);
    return cityCode;
  }
  
  console.log('City not found or not available');
  return null;
};
