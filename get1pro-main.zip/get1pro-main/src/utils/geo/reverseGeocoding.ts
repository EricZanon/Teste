
import { getStateCodeFromName } from './stateMapping';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface ReverseGeocodingResult {
  state: string;
  city: string;
}

// Utility function to find state and city from coordinates using Google Maps Geocoding API
export const reverseGeocode = async (
  coordinates: Coordinates
): Promise<ReverseGeocodingResult | null> => {
  try {
    console.log('=== REVERSE GEOCODING START ===');
    console.log('Input coordinates:', coordinates);
    
    if (!window.google || !window.google.maps || !window.google.maps.Geocoder) {
      console.error('Google Maps API not loaded');
      return null;
    }

    const geocoder = new window.google.maps.Geocoder();
    const latlng = {
      lat: coordinates.latitude,
      lng: coordinates.longitude,
    };

    return new Promise((resolve) => {
      geocoder.geocode({ location: latlng }, async (results, status) => {
        console.log('=== GEOCODING RESPONSE ===');
        console.log('Status:', status);
        console.log('Results count:', results?.length || 0);
        
        if (status === 'OK' && results && results.length > 0) {
          // Initialize result
          let state = '';
          let city = '';

          // Loop through address components to find state and city
          for (const result of results) {
            console.log('Processing result:', result.formatted_address);
            
            if (result.address_components) {
              for (const component of result.address_components) {
                console.log('Component:', component.long_name, 'Types:', component.types);
                
                // Find state - Google returns short_name (like "SP") for Brazilian states
                if (component.types.includes('administrative_area_level_1')) {
                  if (!state) {
                    state = component.short_name;
                    console.log('Found state from geocoding:', state);
                  }
                }
                
                // Find city - prioritize proper city types over neighborhoods
                if (component.types.includes('locality')) {
                  city = component.long_name;
                  console.log('Found city (locality) from geocoding:', city);
                  break; // Break to prioritize locality over other types
                } else if (component.types.includes('administrative_area_level_2') && !city) {
                  city = component.long_name;
                  console.log('Found city (admin level 2) from geocoding:', city);
                }
              }
            }

            // If we found both state and city (with locality priority), we can break
            if (state && city) break;
          }

          // If we still don't have a city, try to find it from sublocality as last resort
          if (state && !city) {
            for (const result of results) {
              if (result.address_components) {
                for (const component of result.address_components) {
                  if (component.types.includes('sublocality_level_1') || 
                      component.types.includes('sublocality')) {
                    city = component.long_name;
                    console.log('Found city (sublocality - fallback) from geocoding:', city);
                    break;
                  }
                }
              }
              if (city) break;
            }
          }

          console.log('=== GEOCODING FINAL RESULT ===');
          console.log('State:', state);
          console.log('City:', city);
          
          // Validate if the state exists in our data
          const stateCode = await getStateCodeFromName(state);
          
          if (stateCode) {
            console.log('State validated:', state, '->', stateCode);
            resolve({ state: stateCode, city });
          } else {
            console.log('State not found in our data:', state);
            // Still return the result even if state is not in our data
            resolve({ state, city });
          }
        } else {
          console.error('Geocoder failed due to:', status);
          resolve(null);
        }
      });
    });
  } catch (error) {
    console.error('Error in reverse geocoding:', error);
    return null;
  }
};
