
import { findNearestLocation } from './findNearestLocation';
import { findMatchingCity } from './cityMatcher';

interface LocationDetectionOptions {
  position: GeolocationPosition;
  availableStates: any[];
  availableCities: string[];
  onStateChange: (state: string) => void;
  onCityChange: (city: string) => void;
  onSuccess: (message: string) => void;
  onError: (title: string, description: string) => void;
}

export const detectAndSetLocation = async ({
  position,
  availableStates,
  availableCities,
  onStateChange,
  onCityChange,
  onSuccess,
  onError
}: LocationDetectionOptions) => {
  console.log('Starting location detection with position:', position);
  
  // Try to get location name from coordinates
  const locationInfo = await findNearestLocation({
    latitude: position.coords.latitude,
    longitude: position.coords.longitude
  });
  
  if (!locationInfo) {
    onError('Localização não identificada', 'Não foi possível identificar sua cidade. Selecione manualmente.');
    return;
  }
  
  console.log('Found location info:', locationInfo);
  
  // Check if we have the state in our available states
  if (!locationInfo.state) {
    console.log('Could not determine state from location');
    onError('Localização imprecisa', 'Não foi possível determinar seu estado. Selecione manualmente.');
    return;
  }

  console.log('Looking for state:', locationInfo.state, 'in available states:', availableStates.map(s => s.code));
  const stateExists = availableStates.find(s => s.code === locationInfo.state);
  
  if (!stateExists) {
    console.log('State not found in available states:', locationInfo.state);
    onError('Estado não disponível', `${locationInfo.state} não possui profissionais cadastrados ainda.`);
    return;
  }

  console.log('State exists in available states:', stateExists);
  // Set the state first
  onStateChange(locationInfo.state);
  
  // Now check for the city
  if (!locationInfo.city) {
    onSuccess(`Estado ${stateExists.name} selecionado. Selecione a cidade manualmente.`);
    return;
  }

  console.log('Processing city:', locationInfo.city);
  console.log('Available cities at detection time:', availableCities);
  
  // Wait for cities to load after state change
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Find matching city
  const cityCode = await findMatchingCity({
    availableCities,
    cityName: locationInfo.city,
    state: locationInfo.state
  });
  
  console.log('Final city code:', cityCode);
  console.log('Available cities for verification:', availableCities);
  
  if (cityCode && availableCities.includes(cityCode)) {
    console.log('Setting city to:', cityCode);
    onCityChange(cityCode);
    
    // Get the readable city name for the success message
    const readableCityName = cityCode.replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase());
    
    onSuccess(`${readableCityName}, ${stateExists.name}`);
  } else {
    console.log('City not found in available cities.');
    console.log('Geocoded city:', locationInfo.city, 'converted to code:', cityCode);
    console.log('Available cities:', availableCities);
    
    onError('Cidade não disponível', `${locationInfo.city} não possui profissionais cadastrados no momento.`);
  }
};
