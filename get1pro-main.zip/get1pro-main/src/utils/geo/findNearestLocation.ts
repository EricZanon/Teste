
import { reverseGeocode } from './reverseGeocoding';
import { getStateCodeFromName } from './stateMapping';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface ReverseGeocodingResult {
  state: string;
  city: string;
}

// Main function that combines reverse geocoding with state/city lookup from Supabase
export const findNearestLocation = async (
  coordinates: Coordinates
): Promise<ReverseGeocodingResult | null> => {
  const locationInfo = await reverseGeocode(coordinates);
  
  if (!locationInfo) {
    return null;
  }
  
  // Convert state name to code using Supabase lookup
  const stateCode = await getStateCodeFromName(locationInfo.state);
  
  return {
    state: stateCode || locationInfo.state,
    city: locationInfo.city
  };
};

// Export the city code finder for backward compatibility
export { findCityCode } from './cityCodeFinder';
