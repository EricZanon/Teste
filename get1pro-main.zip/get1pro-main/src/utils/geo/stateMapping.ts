
import { supabase } from '@/integrations/supabase/client';
import { normalizeText } from './textNormalization';

// Function to convert Brazil state name to state code using Supabase
export const getStateCodeFromName = async (stateName: string): Promise<string | null> => {
  const normalizedStateName = normalizeText(stateName);
  
  try {
    // First try exact matches (both code and name)
    const { data: exactMatch, error: exactError } = await supabase
      .from('states')
      .select('code, name')
      .or(`code.ilike.${normalizedStateName},name.ilike.${normalizedStateName}`)
      .limit(1);

    if (exactError) {
      console.error('Error fetching state by exact match:', exactError);
    }

    if (exactMatch && exactMatch.length > 0) {
      console.log('Found exact state match:', exactMatch[0]);
      return exactMatch[0].code;
    }
    
    // If no exact match, try partial matches only for names (not codes)
    const { data: partialMatch, error: partialError } = await supabase
      .from('states')
      .select('code, name')
      .ilike('name', `%${normalizedStateName}%`)
      .limit(1);

    if (partialError) {
      console.error('Error fetching state by partial match:', partialError);
    }
    
    if (partialMatch && partialMatch.length > 0) {
      console.log('Found partial state match:', partialMatch[0]);
      return partialMatch[0].code;
    }
    
    console.log('No state match found for:', stateName);
    return null;
  } catch (error) {
    console.error('Error in getStateCodeFromName:', error);
    return null;
  }
};
