
import { supabase } from '@/integrations/supabase/client';
import { normalizeText } from './textNormalization';

// Enhanced function to find the city code from city name using Supabase
export const findCityCode = async (stateCode: string, cityName: string): Promise<string | null> => {
  if (!stateCode || !cityName) {
    console.log('Missing stateCode or cityName:', { stateCode, cityName });
    return null;
  }
  
  console.log('=== FIND CITY CODE START ===');
  console.log('State code:', stateCode);
  console.log('City name:', cityName);
  
  // Normalize the input city name
  const cityNameNormalized = normalizeText(cityName);
  console.log('Normalized input city name:', cityNameNormalized);
  
  try {
    // First try exact matches (both code and name)
    const { data: exactMatch, error: exactError } = await supabase
      .from('cities')
      .select(`
        code, 
        name,
        states!inner(code)
      `)
      .eq('states.code', stateCode)
      .or(`code.ilike.${cityNameNormalized},name.ilike.${cityNameNormalized}`)
      .limit(1);

    if (exactError) {
      console.error('Error fetching city by exact match:', exactError);
    }

    if (exactMatch && exactMatch.length > 0) {
      console.log('Found exact city match:', exactMatch[0]);
      return exactMatch[0].code;
    }
    
    // If no exact match, try partial matches for names
    const { data: partialMatch, error: partialError } = await supabase
      .from('cities')
      .select(`
        code, 
        name,
        states!inner(code)
      `)
      .eq('states.code', stateCode)
      .ilike('name', `%${cityNameNormalized}%`)
      .limit(1);

    if (partialError) {
      console.error('Error fetching city by partial match:', partialError);
    }
    
    if (partialMatch && partialMatch.length > 0) {
      console.log('Found partial city match:', partialMatch[0]);
      return partialMatch[0].code;
    }
    
    console.log('=== NO CITY MATCH FOUND ===');
    console.log('Search term:', cityName, 'normalized:', cityNameNormalized);
    return null;
  } catch (error) {
    console.error('Error in findCityCode:', error);
    return null;
  }
};
