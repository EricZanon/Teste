
import { cities } from '@/data/cities';

// Debug function to check if Santo André is in SP cities
export const debugSantoAndreSearch = () => {
  const spCities = cities.BR.SP || [];
  console.log('Total cities in SP:', spCities.length);
  
  // Look for Santo André variations
  const santoAndreVariations = [
    'santo_andre',
    'Santo André',
    'santo andre',
    'SANTO ANDRE'
  ];
  
  santoAndreVariations.forEach(variation => {
    const found = spCities.find(city => 
      city.code.toLowerCase() === variation.toLowerCase() ||
      city.name.toLowerCase() === variation.toLowerCase()
    );
    
    if (found) {
      console.log(`Found Santo André as: ${found.name} (${found.code})`);
    } else {
      console.log(`Not found for variation: ${variation}`);
    }
  });
  
  // List all cities containing "santo"
  const santoClties = spCities.filter(city => 
    city.name.toLowerCase().includes('santo') || 
    city.code.toLowerCase().includes('santo')
  );
  
  console.log('Cities containing "santo":', santoClties);
  
  return spCities;
};
