
/**
 * Calculates the distance between two points using Google Maps Distance Matrix API
 */
import { GOOGLE_MAPS_API_KEY } from '../distanceCalculator';

export interface DistanceResult {
  distance: number;
  duration: string;
  status: 'OK' | 'ZERO_RESULTS' | 'ERROR' | 'NOT_LOADED';
}

// Check if Google Maps API is loaded properly
const isGoogleMapsLoaded = () => {
  return typeof window !== 'undefined' && 
         window.google && 
         window.google.maps && 
         window.google.maps.DistanceMatrixService;
};

export const calculateDistance = async (
  originLat: number,
  originLng: number,
  destinationLat: number,
  destinationLng: number
): Promise<DistanceResult> => {
  console.log('=== CALCULATING DISTANCE ===');
  console.log('Origin:', { lat: originLat, lng: originLng });
  console.log('Destination:', { lat: destinationLat, lng: destinationLng });

  try {
    // Check if Google Maps API is loaded
    if (!isGoogleMapsLoaded()) {
      console.error('Google Maps API is not loaded or not properly initialized');
      console.log('API Key being used:', GOOGLE_MAPS_API_KEY);
      console.log('Window available:', typeof window !== 'undefined');
      console.log('Google object:', !!(typeof window !== 'undefined' && window.google));
      console.log('Google maps:', !!(typeof window !== 'undefined' && window.google && window.google.maps));
      console.log('DistanceMatrixService:', !!(typeof window !== 'undefined' && window.google && window.google.maps && window.google.maps.DistanceMatrixService));
      return {
        distance: 0,
        duration: '',
        status: 'NOT_LOADED'
      };
    }

    console.log('✅ Google Maps API is loaded, creating DistanceMatrixService...');
    
    // Initialize the Google Maps Distance Matrix Service
    const service = new window.google.maps.DistanceMatrixService();
    
    // Request parameters
    const request: google.maps.DistanceMatrixRequest = {
      origins: [{ lat: originLat, lng: originLng }],
      destinations: [{ lat: destinationLat, lng: destinationLng }],
      travelMode: google.maps.TravelMode.DRIVING,
      unitSystem: google.maps.UnitSystem.METRIC,
    };
    
    console.log('Making Distance Matrix API request...', request);
    
    // Make the API request
    const response = await new Promise<google.maps.DistanceMatrixResponse>((resolve, reject) => {
      service.getDistanceMatrix(request, (response, status) => {
        console.log('Distance Matrix API response:', { status, response });
        if (status === 'OK') {
          resolve(response);
        } else {
          console.error('Distance Matrix API error:', status);
          reject(status);
        }
      });
    });
    
    console.log('Processing Distance Matrix response...');
    
    // Parse the response
    if (
      response.rows[0] &&
      response.rows[0].elements[0] &&
      response.rows[0].elements[0].status === 'OK'
    ) {
      const element = response.rows[0].elements[0];
      const distanceValue = element.distance?.value || 0;
      const distanceInKm = distanceValue / 1000; // Convert meters to kilometers
      const durationText = element.duration?.text || '';
      
      const result = {
        distance: parseFloat(distanceInKm.toFixed(1)),
        duration: durationText,
        status: 'OK' as const,
      };
      
      console.log('✅ Distance calculation successful:', result);
      return result;
    } else {
      console.warn('Distance Matrix returned ZERO_RESULTS');
      return {
        distance: 0,
        duration: '',
        status: 'ZERO_RESULTS',
      };
    }
  } catch (error) {
    console.error('❌ Error calculating distance:', error);
    return {
      distance: 0,
      duration: '',
      status: 'ERROR',
    };
  }
};
