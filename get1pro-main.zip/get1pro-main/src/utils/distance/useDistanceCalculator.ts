
import { useEffect, useState, useCallback } from 'react';
import { useGeolocation } from '@/hooks/useGeolocation';
import { calculateDistance } from './calculateDistance';
import { geocodeAddress } from './geocodeAddress';
import { GOOGLE_MAPS_API_KEY } from '../distanceCalculator';
import { ServiceProvider } from '@/types';

export const useDistanceCalculator = () => {
  const { position, getPosition, error: geoError } = useGeolocation();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleMapsLoaded, setIsGoogleMapsLoaded] = useState(false);
  
  // Verificar se Google Maps está carregado
  useEffect(() => {
    const checkGoogleMapsLoaded = () => {
      const loaded = typeof window !== 'undefined' && 
                   window.google && 
                   window.google.maps && 
                   window.google.maps.DistanceMatrixService &&
                   window.google.maps.Geocoder;
      
      console.log('=== STATUS DA API GOOGLE MAPS ===');
      console.log('Google Maps carregado:', !!loaded);
      console.log('API Key presente:', !!GOOGLE_MAPS_API_KEY);
      console.log('Posição do usuário:', position);
      
      setIsGoogleMapsLoaded(!!loaded);
      return !!loaded;
    };
    
    if (checkGoogleMapsLoaded()) {
      return;
    }
    
    const interval = setInterval(() => {
      if (checkGoogleMapsLoaded()) {
        clearInterval(interval);
      }
    }, 1000);
    
    setTimeout(() => clearInterval(interval), 10000);
    
    return () => clearInterval(interval);
  }, [position]);
  
  const calculateDistanceForProviders = useCallback(async (providers: ServiceProvider[]) => {
    console.log('=== INICIANDO CÁLCULO DE DISTÂNCIA ===');
    console.log('Número de providers:', providers.length);
    console.log('Posição do usuário:', position);
    console.log('Google Maps carregado:', isGoogleMapsLoaded);
    console.log('Erro de geolocalização:', geoError);
    
    // Se há erro de geolocalização, retornar sem distâncias
    if (geoError) {
      console.warn('❌ Erro de geolocalização detectado:', geoError);
      return providers.map(provider => ({
        ...provider,
        distance: undefined
      }));
    }
    
    // Garantir que temos posição do usuário
    let currentPosition = position;
    if (!currentPosition) {
      console.log('🔄 Tentando obter posição do usuário...');
      try {
        currentPosition = await getPosition();
      } catch (error) {
        console.error('❌ Falha ao obter posição do usuário:', error);
        return providers.map(provider => ({
          ...provider,
          distance: undefined
        }));
      }
    }
    
    if (!currentPosition) {
      console.warn('❌ Nenhuma posição do usuário disponível');
      return providers.map(provider => ({
        ...provider,
        distance: undefined
      }));
    }
    
    if (!isGoogleMapsLoaded) {
      console.warn('❌ Google Maps não carregado');
      return providers.map(provider => ({
        ...provider,
        distance: undefined
      }));
    }
    
    setIsLoading(true);
    
    try {
      const providersWithDistances = await Promise.all(
        providers.map(async (provider) => {
          console.log(`\n--- Calculando distância para: ${provider.name} ---`);
          
          // Geocodificar se não houver coordenadas
          let lat = provider.location.lat;
          let lng = provider.location.lng;
          
          if (!lat || !lng) {
            console.log('🔍 Geocodificando endereço...');
            
            const coordinates = await geocodeAddress(
              provider.location.address,
              provider.location.city,
              provider.location.state
            );
            
            if (coordinates) {
              lat = coordinates.lat;
              lng = coordinates.lng;
              console.log('✅ Coordenadas geocodificadas:', coordinates);
            } else {
              console.warn('❌ Falha na geocodificação para:', provider.name);
              return { 
                ...provider, 
                distance: undefined
              };
            }
          }
          
          // Calcular distância
          try {
            const distanceResult = await calculateDistance(
              currentPosition.latitude,
              currentPosition.longitude,
              lat,
              lng
            );
            
            console.log('📊 Resultado da distância:', distanceResult);
            
            // Garantir que retornamos apenas number ou undefined
            let finalDistance: number | undefined = undefined;
            
            if (distanceResult.status === 'OK' && 
                typeof distanceResult.distance === 'number' && 
                Number.isFinite(distanceResult.distance) && 
                !Number.isNaN(distanceResult.distance) &&
                distanceResult.distance >= 0) {
              
              finalDistance = Number(distanceResult.distance);
              console.log('✅ Distância calculada:', finalDistance, 'km');
            } else {
              console.log('❌ Cálculo de distância falhou');
            }
            
            return {
              ...provider,
              location: { ...provider.location, lat, lng },
              distance: finalDistance
            };
          } catch (error) {
            console.error('❌ Erro calculando distância:', error);
            return {
              ...provider,
              location: { ...provider.location, lat, lng },
              distance: undefined
            };
          }
        })
      );
      
      console.log('=== CÁLCULO DE DISTÂNCIA COMPLETO ===');
      const successCount = providersWithDistances.filter(p => typeof p.distance === 'number').length;
      console.log(`✅ Calculadas ${successCount}/${providers.length} distâncias`);
      
      return providersWithDistances;
    } catch (error) {
      console.error('❌ Erro no cálculo de distância:', error);
      return providers.map(provider => ({ ...provider, distance: undefined }));
    } finally {
      setIsLoading(false);
    }
  }, [position, getPosition, isGoogleMapsLoaded, geoError]);
  
  return {
    calculateDistanceForProviders,
    isLoading,
    userPosition: position,
    isGoogleMapsLoaded,
    hasGeolocationError: !!geoError
  };
};
