
/**
 * Geocodes an address string to get latitude and longitude coordinates
 */

import { GOOGLE_MAPS_API_KEY } from '../distanceCalculator';

// Check if Google Maps API is loaded properly
const isGoogleMapsLoaded = () => {
  return typeof window !== 'undefined' && 
         window.google && 
         window.google.maps && 
         window.google.maps.Geocoder;
};

export const geocodeAddress = async (
  address: string,
  city: string,
  state: string
): Promise<{ lat: number; lng: number } | null> => {
  console.log('=== GEOCODING ADDRESS ===');
  console.log('Input parameters:', { address, city, state });
  
  if (!isGoogleMapsLoaded()) {
    console.error('Google Maps API is not loaded or not properly initialized');
    console.log('API Key being used:', GOOGLE_MAPS_API_KEY);
    console.log('Window available:', typeof window !== 'undefined');
    console.log('Google object:', !!(typeof window !== 'undefined' && window.google));
    console.log('Google maps:', !!(typeof window !== 'undefined' && window.google && window.google.maps));
    console.log('Geocoder:', !!(typeof window !== 'undefined' && window.google && window.google.maps && window.google.maps.Geocoder));
    return null;
  }

  try {
    const geocoder = new window.google.maps.Geocoder();
    
    // First, try with the complete address
    const fullAddress = `${address}, ${city}, ${state}, Brasil`;
    console.log(`Attempting to geocode full address: "${fullAddress}"`);
    
    const result = await new Promise<google.maps.GeocoderResult[]>((resolve, reject) => {
      geocoder.geocode({ address: fullAddress }, (results, status) => {
        console.log(`Geocoding result for "${fullAddress}":`, { status, resultsCount: results?.length || 0 });
        if (status === 'OK' && results && results.length > 0) {
          console.log('First result:', results[0]);
          resolve(results);
        } else {
          console.warn(`Full address geocoding failed for ${fullAddress}: ${status}`);
          reject(status);
        }
      });
    });
    
    if (result && result[0] && result[0].geometry) {
      const { location } = result[0].geometry;
      const coords = {
        lat: location.lat(),
        lng: location.lng(),
      };
      console.log(`✅ Successfully geocoded full address coordinates:`, coords);
      
      return coords;
    }
  } catch (error) {
    console.warn(`Full address geocoding failed, trying city center fallback: ${error}`);
    
    // Fallback to city center
    try {
      const geocoder = new window.google.maps.Geocoder();
      const cityAddress = `${city}, ${state}, Brasil`;
      console.log(`Attempting to geocode city center: "${cityAddress}"`);
      
      const cityResult = await new Promise<google.maps.GeocoderResult[]>((resolve, reject) => {
        geocoder.geocode({ address: cityAddress }, (results, status) => {
          console.log(`City geocoding result for "${cityAddress}":`, { status, resultsCount: results?.length || 0 });
          if (status === 'OK' && results && results.length > 0) {
            console.log('City result:', results[0]);
            resolve(results);
          } else {
            console.error(`City center geocoding also failed for ${cityAddress}: ${status}`);
            reject(status);
          }
        });
      });
      
      if (cityResult && cityResult[0] && cityResult[0].geometry) {
        const { location } = cityResult[0].geometry;
        const coords = {
          lat: location.lat(),
          lng: location.lng(),
        };
        console.log(`✅ Successfully geocoded city center coordinates:`, coords);
        
        return coords;
      }
    } catch (cityError) {
      console.error(`❌ City center geocoding failed: ${cityError}`);
    }
  }
  
  console.log('❌ All geocoding attempts failed');
  return null;
};
