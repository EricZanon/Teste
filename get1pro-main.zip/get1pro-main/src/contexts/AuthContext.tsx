
import React, { createContext, useContext, useMemo } from 'react';
import { useAuthState } from '@/hooks/useAuthState';
import { AuthContextType, AuthProviderProps } from '@/types/auth';
import { signIn, signOut, signUp, resendVerificationEmail, verifyEmail } from '@/utils/auth-utils';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Admin email - the user with this email will have admin privileges
const ADMIN_EMAIL = "get1pro@vibedigitaltech.com";

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const { user, session, loading } = useAuthState();
  
  // Check if the current user is an admin
  const isAdmin = useMemo(() => {
    // User is admin if they have isAdmin in their metadata or if they have the specific admin email
    return !!user && (
      user.email === ADMIN_EMAIL || 
      (user.user_metadata && user.user_metadata.isAdmin === true)
    );
  }, [user]);

  const value = {
    user,
    session,
    loading,
    isAdmin,
    signUp,
    signIn,
    signOut,
    resendVerificationEmail,
    verifyEmail
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
