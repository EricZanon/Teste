
import React, { createContext, useContext, useState, useEffect } from 'react';
import { ServiceProvider } from '@/types';

interface FilterContextType {
  searchCriteria: {
    state: string;
    city: string;
    service: string;
  };
  setSearchCriteria: (criteria: { state: string; city: string; service: string }) => void;
  filteredProviders: ServiceProvider[];
  setFilteredProviders: (providers: ServiceProvider[]) => void;
  hasSearched: boolean;
  setHasSearched: (hasSearched: boolean) => void;
  resetFilters: () => void;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

// Get saved search criteria from sessionStorage to persist between page navigations
const getSavedSearchCriteria = () => {
  try {
    const saved = sessionStorage.getItem('searchCriteria');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (error) {
    console.error('Error loading saved search criteria:', error);
  }
  return { state: '', city: '', service: '' };
};

// Get saved searched state from sessionStorage
const getSavedHasSearched = () => {
  try {
    const saved = sessionStorage.getItem('hasSearched');
    return saved === 'true';
  } catch (error) {
    console.error('Error loading saved hasSearched state:', error);
  }
  return false;
};

export const FilterProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [searchCriteria, setSearchCriteriaState] = useState<{
    state: string;
    city: string;
    service: string;
  }>(getSavedSearchCriteria());
  
  const [filteredProviders, setFilteredProviders] = useState<ServiceProvider[]>([]);
  const [hasSearched, setHasSearchedState] = useState(getSavedHasSearched());

  // Save search criteria to sessionStorage when it changes
  const setSearchCriteria = (criteria: { state: string; city: string; service: string }) => {
    setSearchCriteriaState(criteria);
    try {
      sessionStorage.setItem('searchCriteria', JSON.stringify(criteria));
    } catch (error) {
      console.error('Error saving search criteria:', error);
    }
  };

  // Save hasSearched state to sessionStorage when it changes
  const setHasSearched = (value: boolean) => {
    setHasSearchedState(value);
    try {
      sessionStorage.setItem('hasSearched', value.toString());
    } catch (error) {
      console.error('Error saving hasSearched state:', error);
    }
  };

  // Reset all filters and clear sessionStorage
  const resetFilters = () => {
    const emptySearch = { state: '', city: '', service: '' };
    setSearchCriteriaState(emptySearch);
    setFilteredProviders([]);
    setHasSearchedState(false);
    
    try {
      sessionStorage.removeItem('searchCriteria');
      sessionStorage.removeItem('hasSearched');
    } catch (error) {
      console.error('Error clearing search criteria:', error);
    }
  };

  return (
    <FilterContext.Provider
      value={{
        searchCriteria,
        setSearchCriteria,
        filteredProviders,
        setFilteredProviders,
        hasSearched,
        setHasSearched,
        resetFilters
      }}
    >
      {children}
    </FilterContext.Provider>
  );
};

export const useFilterContext = (): FilterContextType => {
  const context = useContext(FilterContext);
  if (!context) {
    throw new Error('useFilterContext must be used within a FilterProvider');
  }
  return context;
};
