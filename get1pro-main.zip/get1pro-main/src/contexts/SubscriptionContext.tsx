
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  billing_period: string;
  features: string[];
}

interface UserSubscription {
  subscribed: boolean;
  status: string;
  plan: SubscriptionPlan | null;
  current_period_end: string | null;
}

interface SubscriptionContextType {
  subscription: UserSubscription;
  loading: boolean;
  checkSubscription: () => Promise<void>;
  hasActiveSubscription: boolean;
  isSubscriptionLoading: boolean;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<UserSubscription>({
    subscribed: false,
    status: 'inactive',
    plan: null,
    current_period_end: null
  });
  const [loading, setLoading] = useState(false);

  const checkSubscription = useCallback(async () => {
    if (!user) {
      console.log('🔄 No user, setting inactive subscription');
      setSubscription({
        subscribed: false,
        status: 'inactive',
        plan: null,
        current_period_end: null
      });
      return;
    }

    // Prevent multiple simultaneous calls
    if (loading) {
      console.log('⏸️ Subscription check already in progress');
      return;
    }

    setLoading(true);
    console.log('🔄 Starting subscription check for user:', user.email);

    try {
      const { data, error } = await supabase.functions.invoke('check-subscription');
      
      if (error) {
        console.error('❌ Supabase function error:', error);
        throw error;
      }
      
      console.log('✅ Subscription check successful:', data);
      setSubscription(data);
    } catch (error) {
      console.error('💥 Error checking subscription:', error);
      
      // Set to inactive state on error but don't show toast here
      // (to avoid spam when context auto-refreshes)
      setSubscription({
        subscribed: false,
        status: 'error',
        plan: null,
        current_period_end: null
      });
    } finally {
      setLoading(false);
    }
  }, [user, loading]);

  // Check subscription when user changes (but not on every render)
  useEffect(() => {
    console.log('👤 User changed, checking subscription');
    checkSubscription();
  }, [user?.id]); // Only depend on user ID, not the whole user object

  // Auto-refresh subscription status every 60 seconds when user is active (increased interval)
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      console.log('⏰ Auto-refresh subscription check');
      checkSubscription();
    }, 60000); // Increased to 60 seconds

    return () => clearInterval(interval);
  }, [user?.id, checkSubscription]);

  const value = {
    subscription,
    loading,
    checkSubscription,
    hasActiveSubscription: subscription.subscribed && subscription.status === 'active',
    isSubscriptionLoading: loading
  };

  return (
    <SubscriptionContext.Provider value={value}>
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscriptionContext = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscriptionContext must be used within a SubscriptionProvider');
  }
  return context;
};
