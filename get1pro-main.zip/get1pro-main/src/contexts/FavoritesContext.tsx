
import React, { createContext, useContext, ReactNode, useMemo } from 'react';
import { ServiceProvider } from '@/types';
import { useFavorites as useFavoritesHook } from '@/hooks/useFavorites';

type FavoritesContextType = {
  favorites: Array<{ id: string; website?: string; socialMedia?: any }>;
  favoriteProviders: ServiceProvider[];
  toggleFavorite: (provider: ServiceProvider) => void;
  isFavorite: (id: string) => boolean;
  loading: boolean;
  lastUpdateTime: number;
};

const FavoritesContext = createContext<FavoritesContextType>({
  favorites: [],
  favoriteProviders: [],
  toggleFavorite: () => {},
  isFavorite: () => false,
  loading: false,
  lastUpdateTime: Date.now()
});

export const FavoritesProvider = ({ children }: { children: ReactNode }) => {
  const { favorites, favoriteProviders, toggleFavorite, isFavorite, loading, lastUpdateTime } = useFavoritesHook();

  const contextValue = useMemo(() => ({
    favorites, 
    favoriteProviders, 
    toggleFavorite, 
    isFavorite,
    loading,
    lastUpdateTime
  }), [favorites, favoriteProviders, toggleFavorite, isFavorite, loading, lastUpdateTime]);

  return (
    <FavoritesContext.Provider value={contextValue}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavoritesContext = () => {
  const context = useContext(FavoritesContext);
  
  if (!context) {
    throw new Error('useFavoritesContext must be used within a FavoritesProvider');
  }
  
  return context;
};
