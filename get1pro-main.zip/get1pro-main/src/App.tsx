
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/contexts/AuthContext";
import { SubscriptionProvider } from "@/contexts/SubscriptionContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { FilterProvider } from "@/contexts/FilterContext";
import { FavoritesProvider } from "@/contexts/FavoritesContext";
import Index from "./pages/Index";
import ProviderDetail from "./pages/ProviderDetail";
import Settings from "./pages/Settings";
import Favorites from "./pages/Favorites";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";
import ProviderReviews from "./pages/ProviderReviews";

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <TooltipProvider>
          <BrowserRouter>
            <AuthProvider>
              <SubscriptionProvider>
                <LanguageProvider>
                  <FilterProvider>
                    <FavoritesProvider>
                      <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
                        <Routes>
                          <Route path="/" element={<Index />} />
                          <Route path="/profissional/:id" element={<ProviderDetail />} />
                          <Route path="/profissional/:id/avaliacoes" element={<ProviderReviews />} />
                          <Route path="/settings" element={<Settings />} />
                          <Route path="/favoritos" element={<Favorites />} />
                          <Route path="/admin" element={<Admin />} />
                          <Route path="*" element={<NotFound />} />
                        </Routes>
                      </div>
                      <Toaster />
                    </FavoritesProvider>
                  </FilterProvider>
                </LanguageProvider>
              </SubscriptionProvider>
            </AuthProvider>
          </BrowserRouter>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
