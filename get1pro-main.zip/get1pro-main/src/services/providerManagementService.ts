
import { supabase } from '@/integrations/supabase/client';
import { ProviderProfile } from '@/types/provider';

export const providerManagementService = {
  async fetchProviders(): Promise<ProviderProfile[]> {
    try {
      const { data, error } = await supabase
        .from('providers')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) {
        throw new Error(error.message);
      }
      
      if (data) {
        return data.map((provider: any) => ({
          ...provider,
          country: provider.country || 'BR'
        })) as ProviderProfile[];
      }
      
      return [];
    } catch (error) {
      console.error('Error fetching providers:', error);
      throw error;
    }
  },

  async createUserAccount(email: string) {
    try {
      console.log('Creating user account for email:', email);
      
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email,
        password: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
        options: {
          emailRedirectTo: `${window.location.origin}/`,
        }
      });

      if (signUpError) {
        console.error('Error creating user account:', signUpError);
        throw signUpError;
      }

      if (!signUpData.user) {
        throw new Error('Failed to create user account');
      }

      console.log('User account created successfully:', signUpData.user.id);
      return signUpData.user;
    } catch (error) {
      console.error('Error in createUserAccount:', error);
      throw error;
    }
  },

  async setUserAsAdmin(email: string) {
    try {
      // Since we can't access auth.users table directly, we'll skip the user lookup
      // and just update the current user's metadata if they're trying to set themselves as admin
      const { data: currentUser } = await supabase.auth.getUser();
      
      if (!currentUser.user || currentUser.user.email !== email) {
        throw new Error('Você só pode definir a si mesmo como administrador');
      }

      const { error: updateError } = await supabase.auth.updateUser({
        data: { isAdmin: true }
      });

      if (updateError) {
        throw updateError;
      }

      return currentUser.user;
    } catch (error) {
      console.error('Error setting user as admin:', error);
      throw error;
    }
  },

  async deleteProvider(providerId: string) {
    try {
      // First check if provider exists
      const { data: existingProvider } = await supabase
        .from('providers')
        .select('id')
        .eq('id', providerId)
        .maybeSingle();

      if (!existingProvider) {
        throw new Error('Profissional não encontrado');
      }

      const { error } = await supabase
        .from('providers')
        .delete()
        .eq('id', providerId);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting provider:', error);
      throw error;
    }
  },

  async toggleProviderActiveStatus(providerId: string, newActiveStatus: boolean) {
    try {
      // First check if provider exists
      const { data: existingProvider } = await supabase
        .from('providers')
        .select('id, active')
        .eq('id', providerId)
        .maybeSingle();

      if (!existingProvider) {
        throw new Error('Profissional não encontrado');
      }

      const { error } = await supabase
        .from('providers')
        .update({ active: newActiveStatus })
        .eq('id', providerId);

      if (error) throw error;
    } catch (error) {
      console.error('Error toggling provider status:', error);
      throw error;
    }
  }
};
