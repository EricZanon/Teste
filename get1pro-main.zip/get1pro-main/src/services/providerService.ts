
import { supabase } from '@/integrations/supabase/client';
import { ProviderProfile } from '@/types/provider';

export async function fetchProviderProfile(providerId?: string, userId?: string): Promise<Partial<ProviderProfile> | null> {
  try {
    console.log('🔍 fetchProviderProfile called with:', { providerId, userId });
    
    if (!userId && !providerId) {
      console.log('❌ No IDs provided');
      return null;
    }
    
    const id = providerId || userId;
    
    if (!id) {
      console.log('❌ No valid ID');
      return null;
    }
    
    let query = supabase.from('providers').select('*');
    
    if (providerId) {
      query = query.eq('id', providerId);
    } else {
      query = query.eq('user_id', id);
    }
    
    const { data, error } = await query.maybeSingle();
      
    if (error) {
      console.error('❌ Error fetching profile:', error);
      
      // Provide user-friendly error messages
      if (error.message?.includes('Failed to fetch') || !navigator.onLine) {
        throw new Error('Problema de conexão. Verifique sua internet e tente novamente.');
      } else if (error.message?.includes('JWT') || error.message?.includes('unauthorized')) {
        throw new Error('Sessão expirada. Faça login novamente.');
      }
      
      throw error;
    }
    
    if (data) {
      console.log('✅ Fetched profile:', data);
      return data;
    }
    
    console.log('ℹ️ No profile found');
    return null;
  } catch (error) {
    console.error('💥 Error fetching profile:', error);
    throw error;
  }
}

export async function saveProviderProfile(profile: Partial<ProviderProfile>, userId: string): Promise<ProviderProfile> {
  try {
    console.log('💾 saveProviderProfile called with:', { profile, userId });
    
    if (!userId) {
      throw new Error('ID do usuário é obrigatório para salvar o perfil');
    }

    // Check network connectivity
    if (!navigator.onLine) {
      throw new Error('Sem conexão com a internet. Verifique sua conexão e tente novamente.');
    }
    
    // Validate required fields
    const requiredFields = ['name', 'service_type', 'address', 'city', 'state', 'phone'];
    const missingFields = requiredFields.filter(field => {
      const value = profile[field as keyof ProviderProfile];
      return !value || String(value).trim() === '';
    });
    
    if (missingFields.length > 0) {
      console.error('❌ Missing required fields:', missingFields);
      
      // Map field names to Portuguese
      const fieldNames: Record<string, string> = {
        name: 'Nome',
        service_type: 'Tipo de Serviço',
        address: 'Endereço',
        city: 'Cidade',
        state: 'Estado',
        phone: 'Telefone'
      };
      
      const missingFieldsPortuguese = missingFields.map(field => fieldNames[field] || field);
      throw new Error(`Campos obrigatórios não preenchidos: ${missingFieldsPortuguese.join(', ')}`);
    }
    
    // Clean the data
    const cleanData = {
      name: profile.name!.trim(),
      service_type: profile.service_type!.trim(),
      address: profile.address!.trim(),
      city: profile.city!.trim(),
      state: profile.state!.trim(),
      country: profile.country || 'BR',
      phone: profile.phone!.trim(),
      website: profile.website?.trim() || null,
      facebook_url: profile.facebook_url?.trim() || null,
      instagram_url: profile.instagram_url?.trim() || null,
      linkedin_url: profile.linkedin_url?.trim() || null,
      phone_contact: profile.phone_contact?.trim() || profile.phone!.trim(),
      sms_contact: profile.sms_contact?.trim() || profile.phone!.trim(),
      experience_years: profile.experience_years || null,
      service_region: profile.service_region?.trim() || null,
      about: profile.about?.trim() || null,
      profile_image_url: profile.profile_image_url?.trim() || null,
    };
    
    console.log('📋 Clean data prepared:', cleanData);
    
    // Check if profile exists
    const { data: existingProfile, error: checkError } = await supabase
      .from('providers')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (checkError) {
      console.error('❌ Error checking existing profile:', checkError);
      
      // Provide user-friendly error message for network issues
      if (checkError.message?.includes('Failed to fetch') || !navigator.onLine) {
        throw new Error('Problema de conexão. Verifique sua internet e tente novamente.');
      } else if (checkError.message?.includes('JWT') || checkError.message?.includes('unauthorized')) {
        throw new Error('Sessão expirada. Faça login novamente.');
      }
      
      throw new Error(`Erro ao verificar perfil: ${checkError.message}`);
    }
    
    let result;
    
    if (existingProfile) {
      // Update existing profile
      console.log('🔄 Updating existing profile ID:', existingProfile.id);
      const { data, error } = await supabase
        .from('providers')
        .update({
          ...cleanData,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingProfile.id)
        .select('*')
        .single();
        
      if (error) {
        console.error('❌ Error updating profile:', error);
        
        // Provide user-friendly error message for network issues
        if (error.message?.includes('Failed to fetch') || !navigator.onLine) {
          throw new Error('Problema de conexão. Verifique sua internet e tente novamente.');
        } else if (error.message?.includes('JWT') || error.message?.includes('unauthorized')) {
          throw new Error('Sessão expirada. Faça login novamente.');
        }
        
        throw new Error(`Erro ao atualizar perfil: ${error.message}`);
      }
      
      result = data;
    } else {
      // Create new profile
      console.log('🆕 Creating new profile for user:', userId);
      const { data, error } = await supabase
        .from('providers')
        .insert({
          ...cleanData,
          user_id: userId,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select('*')
        .single();
        
      if (error) {
        console.error('❌ Error creating profile:', error);
        
        // Provide user-friendly error message for network issues
        if (error.message?.includes('Failed to fetch') || !navigator.onLine) {
          throw new Error('Problema de conexão. Verifique sua internet e tente novamente.');
        } else if (error.message?.includes('JWT') || error.message?.includes('unauthorized')) {
          throw new Error('Sessão expirada. Faça login novamente.');
        }
        
        throw new Error(`Erro ao criar perfil: ${error.message}`);
      }
      
      result = data;
    }
    
    if (!result) {
      throw new Error('Nenhum dado retornado após salvar');
    }
    
    console.log('✅ Profile saved successfully:', result);
    return result;
    
  } catch (error: any) {
    console.error('💥 Error in saveProviderProfile:', error);
    
    // Re-throw with original message if it's already user-friendly
    if (error.message?.includes('Problema de conexão') || 
        error.message?.includes('Campos obrigatórios') ||
        error.message?.includes('obrigatório') ||
        error.message?.includes('Sessão expirada') ||
        error.message?.includes('Sem conexão')) {
      throw error;
    }
    
    // Provide generic user-friendly message for unexpected errors
    throw new Error('Erro inesperado ao salvar perfil. Tente novamente ou entre em contato com o suporte.');
  }
}
