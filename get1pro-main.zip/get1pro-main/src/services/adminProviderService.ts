
import { supabase } from '@/integrations/supabase/client';
import { ProviderProfile } from '@/types/provider';

/**
 * Admin service for managing provider profiles with elevated permissions
 */
export async function saveProviderProfileAsAdmin(profile: Partial<ProviderProfile>): Promise<Partial<ProviderProfile>> {
  try {
    console.log('saveProviderProfileAsAdmin called with profile:', {
      id: profile.id,
      name: profile.name,
      service_type: profile.service_type,
      address: profile.address,
      country: profile.country,
      phone: profile.phone,
      user_id: profile.user_id
    });
    
    const countryValue = profile.country || 'BR';
    
    // Validate required fields
    const requiredFields = {
      name: profile.name,
      service_type: profile.service_type,
      address: profile.address,
      country: countryValue,
      phone: profile.phone
    };
    
    console.log('Admin save - Required fields validation:', requiredFields);
    
    const missingFields = Object.entries(requiredFields)
      .filter(([key, value]) => !value || value.trim() === '')
      .map(([key]) => key);
    
    if (missingFields.length > 0) {
      console.error('Missing required fields:', missingFields);
      throw new Error(`Por favor, preencha todos os campos obrigatórios: ${missingFields.join(', ')}`);
    }
    
    if (!profile.id) {
      throw new Error('ID do perfil é obrigatório para edição de administrador');
    }
    
    const profileData = {
      name: profile.name,
      service_type: profile.service_type,
      address: profile.address,
      city: profile.city || '',
      state: profile.state || '',
      country: countryValue,
      phone: profile.phone,
      website: profile.website || null,
      facebook_url: profile.facebook_url || null,
      instagram_url: profile.instagram_url || null,
      linkedin_url: profile.linkedin_url || null,
      phone_contact: profile.phone_contact || null,
      sms_contact: profile.sms_contact || null,
      experience_years: profile.experience_years || null,
      service_region: profile.service_region || null,
      about: profile.about || null,
      profile_image_url: profile.profile_image_url || null,
    };
    
    console.log('Admin save - Profile data to be saved:', profileData);
    
    // Use RPC function to bypass RLS as admin with type assertion
    const { data, error } = await (supabase as any).rpc('admin_update_provider', {
      provider_id: profile.id,
      provider_data: profileData
    });
    
    if (error) {
      console.error('Error in admin_update_provider RPC:', error);
      
      // Fallback to direct update if RPC doesn't exist yet
      const { data: fallbackData, error: fallbackError } = await supabase
        .from('providers')
        .update(profileData)
        .eq('id', profile.id)
        .select()
        .maybeSingle();
        
      if (fallbackError) {
        console.error('Fallback update also failed:', fallbackError);
        throw new Error(`Erro ao atualizar perfil: ${fallbackError.message}`);
      }
      
      if (!fallbackData) {
        throw new Error('Nenhum perfil foi atualizado. Verifique se o perfil existe.');
      }
      
      console.log('Admin save - Fallback update successful:', fallbackData);
      return fallbackData;
    }
    
    // Fix: The RPC function returns an array, but we need a single object
    let updatedProfile;
    if (Array.isArray(data) && data.length > 0) {
      updatedProfile = data[0];
    } else if (data && !Array.isArray(data)) {
      updatedProfile = data;
    } else {
      throw new Error('Nenhum perfil foi retornado após a atualização.');
    }
    
    console.log('Admin save - RPC update successful:', updatedProfile);
    return updatedProfile;
  } catch (error) {
    console.error('Error in saveProviderProfileAsAdmin:', error);
    throw error;
  }
}
