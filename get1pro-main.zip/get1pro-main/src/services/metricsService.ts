
import { supabase } from '@/integrations/supabase/client';

/**
 * Incrementa uma métrica específica para um provedor
 */
export async function incrementProviderMetric(
  providerId: string,
  metric: 'shares' | 'facebook' | 'instagram' | 'twitter' | 'google_business' | 'website' | 'favorites'
): Promise<boolean> {
  try {
    // Para google_business, mapeamos para linkedin no banco de dados
    let dbMetric: string = metric;
    
    // Mapear métricas personalizadas para colunas existentes no banco
    if (metric === 'google_business') {
      dbMetric = 'linkedin';
    } 
    
    // Chamar a função RPC do PostgreSQL para incrementar a métrica
    const { error } = await supabase
      .rpc('increment_provider_metric', {
        p_provider_id: providerId,
        p_metric: dbMetric
      });

    if (error) {
      console.error(`Erro ao incrementar métrica ${metric}:`, error);
      return false;
    }

    return true;
  } catch (error) {
    console.error(`Erro ao incrementar métrica ${metric}:`, error);
    return false;
  }
}

/**
 * Busca métricas para um provedor específico
 */
export async function getProviderMetrics(providerId: string) {
  try {
    const { data, error } = await supabase
      .from('provider_metrics')
      .select('*')
      .eq('provider_id', providerId)
      .single();

    if (error) {
      console.error('Erro ao buscar métricas:', error);
      return null;
    }

    // Transform the data to handle linkedin_clicks to google_business_clicks mapping
    if (data) {
      return {
        ...data,
        google_business_clicks: data.linkedin_clicks || 0,
        website_clicks: data.linkedin_clicks || 0, // Temporary workaround
        favorites_count: data.shares || 0 // Temporary workaround
      };
    }

    return data;
  } catch (error) {
    console.error('Erro ao buscar métricas:', error);
    return null;
  }
}
