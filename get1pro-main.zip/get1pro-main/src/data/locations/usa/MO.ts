
import { City } from '../../../types';

export const missouriCities: City[] = [
  { code: 'kansas_city', name: 'Kansas City' },
  { code: 'st_louis', name: 'St. Louis' },
  { code: 'springfield', name: 'Springfield' },
  { code: 'columbia', name: 'Columbia' },
  { code: 'independence', name: 'Independence' },
  { code: 'lees_summit', name: 'Lee\'s Summit' },
  { code: 'o_fallon', name: 'O\'Fallon' },
  { code: 'saint_joseph', name: 'Saint Joseph' },
  { code: 'saint_charles', name: 'Saint Charles' },
  { code: 'blue_springs', name: 'Blue Springs' },
  { code: 'saint_peters', name: 'Saint Peters' },
  { code: 'florissant', name: 'Florissant' },
  { code: 'joplin', name: 'Joplin' },
  { code: 'chesterfield', name: 'Chesterfield' },
  { code: 'jefferson_city', name: 'Jefferson City' },
  { code: 'cape_girardeau', name: 'Cape Girardeau' },
  { code: 'wentzville', name: 'Wentzville' },
  { code: 'university_city', name: 'University City' },
  { code: 'wildwood', name: 'Wildwood' },
  { code: 'liberty', name: 'Liberty' },
  { code: 'ballwin', name: 'Ballwin' },
  { code: 'raytown', name: 'Raytown' },
  { code: 'kirkwood', name: 'Kirkwood' },
  { code: 'ferguson', name: 'Ferguson' },
  { code: 'maryland_heights', name: 'Maryland Heights' }
];
