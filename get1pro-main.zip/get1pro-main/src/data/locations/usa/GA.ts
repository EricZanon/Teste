
import { City } from '../../../types';

export const georgiaCities: City[] = [
  { code: 'atlanta', name: 'Atlanta' },
  { code: 'augusta', name: 'Augusta' },
  { code: 'columbus', name: 'Columbus' },
  { code: 'cumming', name: 'Cumming' },
  { code: 'savannah', name: 'Savannah' },
  { code: 'athens', name: 'Athens' },
  { code: 'sandy_springs', name: 'Sandy Springs' },
  { code: 'macon', name: 'Macon' },
  { code: 'roswell', name: 'Roswell' },
  { code: 'albany', name: 'Albany' },
  { code: 'johns_creek', name: 'Johns Creek' },
  { code: 'warner_robins', name: 'Warner Robins' },
  { code: 'alpharetta', name: 'Alpharetta' },
  { code: 'marietta', name: 'Marietta' },
  { code: 'valdosta', name: 'Valdosta' },
  { code: 'smyrna', name: 'Smyrna' },
  { code: 'dunwoody', name: 'Dunwoody' },
  { code: 'peachtree_city', name: 'Peachtree City' },
  { code: 'rome', name: 'Rome' },
  { code: 'east_point', name: 'East Point' },
  { code: 'gainesville', name: 'Gainesville' },
  { code: 'hinesville', name: 'Hinesville' },
  { code: 'milton', name: 'Milton' },
  { code: 'dalton', name: 'Dalton' },
  { code: 'lawrenceville', name: 'Lawrenceville' },
  { code: 'statesboro', name: 'Statesboro' }
];
