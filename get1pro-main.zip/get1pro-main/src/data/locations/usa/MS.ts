
import { City } from '../../../types';

export const mississippiCities: City[] = [
  { code: 'jackson', name: 'Jackson' },
  { code: 'gulfport', name: 'Gulfport' },
  { code: 'southaven', name: 'Southaven' },
  { code: 'hattiesburg', name: 'Hattiesburg' },
  { code: 'biloxi', name: 'Biloxi' },
  { code: 'meridian', name: 'Meridian' },
  { code: 'tupelo', name: 'Tupelo' },
  { code: 'greenville', name: 'Greenville' },
  { code: 'olive_branch', name: 'Olive Branch' },
  { code: 'horn_lake', name: 'Horn Lake' },
  { code: 'clinton', name: 'Clinton' },
  { code: 'pearl', name: 'Pearl' },
  { code: 'ridgeland', name: 'Ridgeland' },
  { code: 'starkville', name: 'Starkville' },
  { code: 'columbus', name: 'Columbus' },
  { code: 'vicksburg', name: 'Vicksburg' },
  { code: 'pascagoula', name: 'Pascagoula' },
  { code: 'brandon', name: 'Brandon' },
  { code: 'oxford', name: 'Oxford' },
  { code: 'gautier', name: 'Gautier' },
  { code: 'laurel', name: 'Laurel' },
  { code: 'madison', name: 'Madison' },
  { code: 'ocean_springs', name: 'Ocean Springs' },
  { code: 'long_beach', name: 'Long Beach' },
  { code: 'natchez', name: 'Natchez' }
];
