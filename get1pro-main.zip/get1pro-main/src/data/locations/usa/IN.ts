
import { City } from '../../../types';

export const indianaCities: City[] = [
  { code: 'indianapolis', name: 'Indianapolis' },
  { code: 'fort_wayne', name: 'Fort Wayne' },
  { code: 'evansville', name: 'Evansville' },
  { code: 'south_bend', name: 'South Bend' },
  { code: 'carmel', name: 'Carmel' },
  { code: 'fishers', name: 'Fishers' },
  { code: 'bloomington', name: 'Bloomington' },
  { code: 'hammond', name: 'Hammond' },
  { code: 'gary', name: 'Gary' },
  { code: 'lafayette', name: 'Lafayette' },
  { code: 'muncie', name: 'Muncie' },
  { code: 'terre_haute', name: 'Terre Haute' },
  { code: 'kokomo', name: 'Kokomo' },
  { code: 'anderson', name: 'Anderson' },
  { code: 'noblesville', name: 'Noblesville' },
  { code: 'greenwood', name: 'Greenwood' },
  { code: 'elkhart', name: 'Elkhart' },
  { code: 'mishawaka', name: 'Mishawaka' },
  { code: 'lawrence', name: 'Lawrence' },
  { code: 'jeffersonville', name: 'Jeffersonville' },
  { code: 'columbus', name: 'Columbus' },
  { code: 'portage', name: 'Portage' },
  { code: 'new_albany', name: 'New Albany' },
  { code: 'richmond', name: 'Richmond' },
  { code: 'valparaiso', name: 'Valparaiso' }
];
