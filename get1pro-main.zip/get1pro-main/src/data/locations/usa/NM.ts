
import { City } from '../../../types';

export const newMexicoCities: City[] = [
  { code: 'albuquerque', name: 'Albuquerque' },
  { code: 'las_cruces', name: 'Las Cruces' },
  { code: 'rio_rancho', name: 'Rio Rancho' },
  { code: 'santa_fe', name: 'Santa Fe' },
  { code: 'roswell', name: 'Roswell' },
  { code: 'farmington', name: 'Farmington' },
  { code: 'clovis', name: 'Clovis' },
  { code: 'hobbs', name: 'Hobbs' },
  { code: 'alamogordo', name: 'Alamogordo' },
  { code: 'carlsbad', name: 'Carlsbad' },
  { code: 'gallup', name: 'Gallup' },
  { code: 'deming', name: 'Deming' },
  { code: 'los_lunas', name: 'Los Lunas' },
  { code: 'chaparral', name: 'Chaparral' },
  { code: 'sunland_park', name: 'Sunland Park' },
  { code: 'las_vegas', name: 'Las Vegas' },
  { code: 'portales', name: 'Portales' },
  { code: 'artesia', name: 'Artesia' },
  { code: 'silver_city', name: 'Silver City' },
  { code: 'lovington', name: 'Lovington' },
  { code: 'grants', name: 'Grants' },
  { code: 'socorro', name: 'Socorro' },
  { code: 'espanola', name: 'Española' },
  { code: 'bernalillo', name: 'Bernalillo' },
  { code: 'truth_or_consequences', name: 'Truth or Consequences' }
];
