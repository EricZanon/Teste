
import { City } from '../../../types';

export const kentuckyCities: City[] = [
  { code: 'louisville', name: 'Louisville' },
  { code: 'lexington', name: 'Lexington' },
  { code: 'bowling_green', name: 'Bowling Green' },
  { code: 'owensboro', name: 'Owensboro' },
  { code: 'covington', name: 'Covington' },
  { code: 'richmond', name: 'Richmond' },
  { code: 'georgetown', name: 'Georgetown' },
  { code: 'florence', name: 'Florence' },
  { code: 'hopkinsville', name: 'Hopkinsville' },
  { code: 'nicholasville', name: 'Nicholasville' },
  { code: 'frankfort', name: 'Frankfort' },
  { code: 'henderson', name: 'Henderson' },
  { code: 'paducah', name: 'Paducah' },
  { code: 'elizabethtown', name: 'Elizabethtown' },
  { code: 'jeffersontown', name: 'Jeffersontown' },
  { code: 'radcliff', name: 'Radcliff' },
  { code: 'ashland', name: 'Ashland' },
  { code: 'madisonville', name: 'Madisonville' },
  { code: 'independence', name: 'Independence' },
  { code: 'winchester', name: 'Winchester' },
  { code: 'erlanger', name: 'Erlanger' },
  { code: 'murray', name: 'Murray' },
  { code: 'saint_matthews', name: 'Saint Matthews' },
  { code: 'danville', name: 'Danville' },
  { code: 'shively', name: 'Shively' }
];
