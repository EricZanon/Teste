
import { City } from '../../../types';

export const alabamaCities: City[] = [
  { code: 'birmingham', name: 'Birmingham' },
  { code: 'montgomery', name: 'Montgomery' },
  { code: 'mobile', name: 'Mobile' },
  { code: 'huntsville', name: 'Huntsville' },
  { code: 'tuscaloosa', name: 'Tuscaloosa' },
  { code: 'hoover', name: 'Hoover' },
  { code: 'dothan', name: 'Dothan' },
  { code: 'auburn', name: 'Auburn' },
  { code: 'decatur', name: 'Decatur' },
  { code: 'madison', name: 'Madison' },
  { code: 'florence', name: 'Florence' },
  { code: 'gadsden', name: 'Gadsden' },
  { code: 'vestavia_hills', name: 'Vestavia Hills' },
  { code: 'prattville', name: 'Prattville' },
  { code: 'phenix_city', name: 'Phenix City' },
  { code: 'alabaster', name: 'Alabaster' },
  { code: 'bessemer', name: 'Bessemer' },
  { code: 'enterprise', name: 'Enterprise' },
  { code: 'opelika', name: 'Opelika' },
  { code: 'cullman', name: 'Cullman' },
  { code: 'daphne', name: 'Daphne' },
  { code: 'oxford', name: 'Oxford' },
  { code: 'trussville', name: 'Trussville' },
  { code: 'pelham', name: 'Pelham' },
  { code: 'selma', name: 'Selma' }
];
