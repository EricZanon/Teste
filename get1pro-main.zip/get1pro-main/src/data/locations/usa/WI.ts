
import { City } from '../../../types';

export const wisconsinCities: City[] = [
  { code: 'milwaukee', name: 'Milwaukee' },
  { code: 'madison', name: 'Madison' },
  { code: 'green_bay', name: 'Green Bay' },
  { code: 'kenosha', name: 'Kenosha' },
  { code: 'racine', name: 'Racine' },
  { code: 'appleton', name: 'Appleton' },
  { code: 'waukesha', name: 'Waukesha' },
  { code: 'eau_claire', name: 'Eau Claire' },
  { code: 'oshkosh', name: 'Oshkosh' },
  { code: 'janesville', name: 'Janesville' },
  { code: 'west_allis', name: 'West Allis' },
  { code: 'la_crosse', name: 'La Crosse' },
  { code: 'sheboygan', name: 'Sheboygan' },
  { code: 'wauwatosa', name: 'Wauwatosa' },
  { code: 'fond_du_lac', name: 'Fond du Lac' },
  { code: 'new_berlin', name: 'New Berlin' },
  { code: 'wausau', name: 'Wausau' },
  { code: 'brookfield', name: 'Brookfield' },
  { code: 'beloit', name: 'Beloit' },
  { code: 'greenfield', name: 'Greenfield' },
  { code: 'franklin', name: 'Franklin' },
  { code: 'oak_creek', name: 'Oak Creek' },
  { code: 'manitowoc', name: 'Manitowoc' },
  { code: 'west_bend', name: 'West Bend' },
  { code: 'sun_prairie', name: 'Sun Prairie' }
];
