
import { City } from '../../../types';

export const montanaCities: City[] = [
  { code: 'billings', name: 'Billings' },
  { code: 'missoula', name: 'Missoula' },
  { code: 'great_falls', name: 'Great Falls' },
  { code: 'bozeman', name: 'Bozeman' },
  { code: 'butte', name: 'Butte' },
  { code: 'helena', name: 'Helena' },
  { code: 'kalispell', name: 'Kalispell' },
  { code: 'havre', name: 'Havre' },
  { code: 'anaconda', name: 'Anaconda' },
  { code: 'miles_city', name: 'Miles City' },
  { code: 'livingston', name: 'Livingston' },
  { code: 'whitefish', name: 'Whitefish' },
  { code: 'laurel', name: 'Laurel' },
  { code: 'lewistown', name: 'Lewistown' },
  { code: 'sidney', name: 'Sidney' },
  { code: 'glendive', name: 'Glendive' },
  { code: 'polson', name: 'Polson' },
  { code: 'hamilton', name: 'Hamilton' },
  { code: 'columbia_falls', name: 'Columbia Falls' },
  { code: 'dillon', name: 'Dillon' }
];
