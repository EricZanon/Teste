
import { City } from '../../../types';

export const newHampshireCities: City[] = [
  { code: 'manchester', name: 'Manchester' },
  { code: 'nashua', name: 'Nashua' },
  { code: 'concord', name: 'Concord' },
  { code: 'dover', name: 'Dover' },
  { code: 'rochester', name: 'Rochester' },
  { code: 'keene', name: 'Keene' },
  { code: 'derry', name: 'Derry' },
  { code: 'portsmouth', name: 'Portsmouth' },
  { code: 'londonderry', name: 'Londonderry' },
  { code: 'hudson', name: 'Hudson' },
  { code: 'salem', name: 'Salem' },
  { code: 'bedford', name: 'Bedford' },
  { code: 'merrimack', name: 'Merrimack' },
  { code: 'lebanon', name: 'Lebanon' },
  { code: 'hooksett', name: 'Hooksett' },
  { code: 'claremont', name: 'Claremont' },
  { code: 'windham', name: 'Windham' },
  { code: 'pelham', name: 'Pelham' },
  { code: 'exeter', name: 'Exeter' },
  { code: 'somersworth', name: 'Somersworth' },
  { code: 'laconia', name: 'Laconia' },
  { code: 'hampton', name: 'Hampton' },
  { code: 'milford', name: 'Milford' },
  { code: 'hanover', name: 'Hanover' },
  { code: 'amherst', name: 'Amherst' }
];
