
import { City } from '../../../types';

export const nevadaCities: City[] = [
  { code: 'las_vegas', name: 'Las Vegas' },
  { code: 'henderson', name: 'Henderson' },
  { code: 'reno', name: 'Reno' },
  { code: 'north_las_vegas', name: 'North Las Vegas' },
  { code: 'sparks', name: 'Sparks' },
  { code: 'carson_city', name: 'Carson City' },
  { code: 'fernley', name: 'Fernley' },
  { code: 'elko', name: 'Elko' },
  { code: 'mesquite', name: 'Mesquite' },
  { code: 'boulder_city', name: 'Boulder City' },
  { code: 'fallon', name: 'Fallon' },
  { code: 'winnemucca', name: 'Winnemucca' },
  { code: 'west_wendover', name: 'West Wendover' },
  { code: 'yerington', name: 'Yerington' },
  { code: 'ely', name: 'Ely' },
  { code: 'carlin', name: 'Carlin' },
  { code: 'lovelock', name: 'Lovelock' },
  { code: 'wells', name: 'Wells' },
  { code: 'caliente', name: 'Caliente' },
  { code: 'pahrump', name: 'Pahrump' }
];
