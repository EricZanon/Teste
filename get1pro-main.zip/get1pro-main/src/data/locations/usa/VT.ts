
import { City } from '../../../types';

export const vermontCities: City[] = [
  { code: 'burlington', name: 'Burlington' },
  { code: 'south_burlington', name: 'South Burlington' },
  { code: 'rutland', name: 'Rutland' },
  { code: 'essex_junction', name: 'Essex Junction' },
  { code: 'bennington', name: 'Bennington' },
  { code: 'montpelier', name: 'Montpelier' },
  { code: 'barre', name: 'Barre' },
  { code: 'winooski', name: 'Winooski' },
  { code: 'st_albans', name: 'St. Albans' },
  { code: 'swanton', name: 'Swanton' },
  { code: 'middlebury', name: 'Middlebury' },
  { code: 'brattleboro', name: 'Brattleboro' },
  { code: 'springfield', name: 'Springfield' },
  { code: 'williston', name: 'Williston' },
  { code: 'milton', name: 'Milton' },
  { code: 'newport', name: 'Newport' },
  { code: 'bellows_falls', name: 'Bellows Falls' },
  { code: 'morrisville', name: 'Morrisville' },
  { code: 'stowe', name: 'Stowe' },
  { code: 'vergennes', name: 'Vergennes' }
];
