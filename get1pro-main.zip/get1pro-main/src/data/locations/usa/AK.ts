
import { City } from '../../../types';

export const alaskaCities: City[] = [
  { code: 'anchorage', name: 'Anchorage' },
  { code: 'fairbanks', name: 'Fairbanks' },
  { code: 'juneau', name: 'Juneau' },
  { code: 'sitka', name: 'Sitka' },
  { code: 'ketchikan', name: 'Ketchikan' },
  { code: 'wasilla', name: 'Wasilla' },
  { code: 'kenai', name: 'Kenai' },
  { code: 'kodiak', name: 'Kodiak' },
  { code: 'bethel', name: 'Bethel' },
  { code: 'palmer', name: 'Palmer' },
  { code: 'homer', name: 'Homer' },
  { code: 'unalaska', name: 'Unalaska' },
  { code: 'barrow', name: 'Barrow' },
  { code: 'soldotna', name: 'Soldotna' },
  { code: 'valdez', name: 'Valdez' },
  { code: 'nome', name: 'Nome' },
  { code: 'kotzebue', name: 'Kotzebue' },
  { code: 'seward', name: 'Seward' },
  { code: 'wrangell', name: 'Wrangell' },
  { code: 'dillingham', name: 'Dillingham' }
];
