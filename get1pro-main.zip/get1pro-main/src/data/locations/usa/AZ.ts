
import { City } from '../../../types';

export const arizonaCities: City[] = [
  { code: 'phoenix', name: 'Phoenix' },
  { code: 'tucson', name: 'Tucson' },
  { code: 'mesa', name: 'Mesa' },
  { code: 'chandler', name: 'Chandler' },
  { code: 'scottsdale', name: 'Scottsdale' },
  { code: 'glendale', name: 'Glendale' },
  { code: 'gilbert', name: 'Gilbert' },
  { code: 'tempe', name: 'Tempe' },
  { code: 'peoria', name: 'Peoria' },
  { code: 'surprise', name: 'Surprise' },
  { code: 'yuma', name: 'Yuma' },
  { code: 'avondale', name: 'Avondale' },
  { code: 'goodyear', name: 'Goodyear' },
  { code: 'flagstaff', name: 'Flagstaff' },
  { code: 'buckeye', name: 'Buckeye' },
  { code: 'lake_havasu_city', name: 'Lake Havasu City' },
  { code: 'casa_grande', name: 'Casa Grande' },
  { code: 'maricopa', name: 'Maricopa' },
  { code: 'prescott', name: 'Prescott' },
  { code: 'prescott_valley', name: 'Prescott Valley' },
  { code: 'oro_valley', name: 'Oro Valley' },
  { code: 'sierra_vista', name: 'Sierra Vista' },
  { code: 'queen_creek', name: 'Queen Creek' },
  { code: 'bullhead_city', name: 'Bullhead City' },
  { code: 'apache_junction', name: 'Apache Junction' }
];
