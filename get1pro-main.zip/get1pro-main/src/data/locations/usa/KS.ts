
import { City } from '../../../types';

export const kansasCities: City[] = [
  { code: 'wichita', name: 'Wichita' },
  { code: 'overland_park', name: 'Overland Park' },
  { code: 'kansas_city', name: 'Kansas City' },
  { code: 'topeka', name: 'Topeka' },
  { code: 'olathe', name: 'Olathe' },
  { code: 'lawrence', name: 'Lawrence' },
  { code: 'shawnee', name: 'Shawnee' },
  { code: 'manhattan', name: 'Manhattan' },
  { code: 'lenexa', name: 'Lenexa' },
  { code: 'salina', name: 'Salina' },
  { code: 'hutchinson', name: 'Hutchinson' },
  { code: 'leawood', name: 'Leawood' },
  { code: 'dodge_city', name: 'Dodge City' },
  { code: 'garden_city', name: 'Garden City' },
  { code: 'emporia', name: 'Emporia' },
  { code: 'derby', name: 'Derby' },
  { code: 'prairie_village', name: 'Prairie Village' },
  { code: 'hays', name: 'Hays' },
  { code: 'liberal', name: 'Liberal' },
  { code: 'pittsburg', name: 'Pittsburg' },
  { code: 'gardner', name: 'Gardner' },
  { code: 'great_bend', name: 'Great Bend' },
  { code: 'junction_city', name: 'Junction City' },
  { code: 'merriam', name: 'Merriam' },
  { code: 'atchison', name: 'Atchison' }
];
