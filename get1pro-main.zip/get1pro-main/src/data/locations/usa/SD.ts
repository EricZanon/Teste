
import { City } from '../../../types';

export const southDakotaCities: City[] = [
  { code: 'sioux_falls', name: 'Sioux Falls' },
  { code: 'rapid_city', name: 'Rapid City' },
  { code: 'aberdeen', name: 'Aberdeen' },
  { code: 'brookings', name: 'Brookings' },
  { code: 'watertown', name: 'Watertown' },
  { code: 'mitchell', name: 'Mitchell' },
  { code: 'yankton', name: 'Yankton' },
  { code: 'pierre', name: 'Pierre' },
  { code: 'huron', name: 'Huron' },
  { code: 'vermillion', name: 'Vermillion' },
  { code: 'box_elder', name: 'Box Elder' },
  { code: 'brandon', name: 'Brandon' },
  { code: 'spearfish', name: 'Spearfish' },
  { code: 'madison', name: 'Madison' },
  { code: 'sturgis', name: 'Sturgis' },
  { code: 'belle_fourche', name: 'Belle Fourche' },
  { code: 'harrisburg', name: 'Harrisburg' },
  { code: 'tea', name: 'Tea' },
  { code: 'dell_rapids', name: 'Dell Rapids' },
  { code: 'hot_springs', name: 'Hot Springs' }
];
