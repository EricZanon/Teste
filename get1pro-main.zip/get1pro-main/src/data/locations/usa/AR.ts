
import { City } from '../../../types';

export const arkansasCities: City[] = [
  { code: 'little_rock', name: 'Little Rock' },
  { code: 'fort_smith', name: 'Fort Smith' },
  { code: 'fayetteville', name: 'Fayetteville' },
  { code: 'springdale', name: 'Springdale' },
  { code: 'jonesboro', name: 'Jonesboro' },
  { code: 'north_little_rock', name: 'North Little Rock' },
  { code: 'conway', name: 'Conway' },
  { code: 'rogers', name: 'Rogers' },
  { code: 'pine_bluff', name: 'Pine Bluff' },
  { code: 'bentonville', name: 'Bentonville' },
  { code: 'hot_springs', name: 'Hot Springs' },
  { code: 'benton', name: 'Benton' },
  { code: 'texarkana', name: 'Texarkana' },
  { code: 'sherwood', name: 'Sherwood' },
  { code: 'jacksonville', name: 'Jacksonville' },
  { code: 'russellville', name: 'Russellville' },
  { code: 'bella_vista', name: 'Bella Vista' },
  { code: 'paragould', name: 'Paragould' },
  { code: 'cabot', name: 'Cabot' },
  { code: 'west_memphis', name: 'West Memphis' },
  { code: 'searcy', name: 'Searcy' },
  { code: 'van_buren', name: 'Van Buren' },
  { code: 'el_dorado', name: 'El Dorado' },
  { code: 'maumelle', name: 'Maumelle' },
  { code: 'bryant', name: 'Bryant' }
];
