
import { City } from '../../../types';

export const coloradoCities: City[] = [
  { code: 'denver', name: 'Denver' },
  { code: 'colorado_springs', name: 'Colorado Springs' },
  { code: 'aurora', name: 'Aurora' },
  { code: 'fort_collins', name: 'Fort Collins' },
  { code: 'lakewood', name: 'Lakewood' },
  { code: 'thornton', name: 'Thornton' },
  { code: 'arvada', name: 'Arvada' },
  { code: 'westminster', name: 'Westminster' },
  { code: 'pueblo', name: 'Pueblo' },
  { code: 'centennial', name: 'Centennial' },
  { code: 'boulder', name: 'Boulder' },
  { code: 'greeley', name: 'Greeley' },
  { code: 'longmont', name: 'Longmont' },
  { code: 'loveland', name: 'Loveland' },
  { code: 'grand_junction', name: 'Grand Junction' },
  { code: 'broomfield', name: 'Broomfield' },
  { code: 'castle_rock', name: 'Castle Rock' },
  { code: 'commerce_city', name: 'Commerce City' },
  { code: 'parker', name: 'Parker' },
  { code: 'littleton', name: 'Littleton' },
  { code: 'northglenn', name: 'Northglenn' },
  { code: 'brighton', name: 'Brighton' },
  { code: 'wheat_ridge', name: 'Wheat Ridge' },
  { code: 'fountain', name: 'Fountain' },
  { code: 'lafayette', name: 'Lafayette' }
];
