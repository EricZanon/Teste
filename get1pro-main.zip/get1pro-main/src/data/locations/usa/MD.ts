
import { City } from '../../../types';

export const marylandCities: City[] = [
  { code: 'baltimore', name: 'Baltimore' },
  { code: 'frederick', name: 'Frederick' },
  { code: 'rockville', name: 'Rockville' },
  { code: 'gaithersburg', name: 'Gaithersburg' },
  { code: 'bowie', name: 'Bowie' },
  { code: 'hagerstown', name: 'Hagerstown' },
  { code: 'annapolis', name: 'Annapolis' },
  { code: 'college_park', name: 'College Park' },
  { code: 'salisbury', name: 'Salisbury' },
  { code: 'laurel', name: 'Laurel' },
  { code: 'greenbelt', name: 'Greenbelt' },
  { code: 'cumberland', name: 'Cumberland' },
  { code: 'takoma_park', name: 'Takoma Park' },
  { code: 'westminster', name: 'Westminster' },
  { code: 'hyattsville', name: 'Hyattsville' },
  { code: 'easton', name: 'Easton' },
  { code: 'elkton', name: 'Elkton' },
  { code: 'aberdeen', name: 'Aberdeen' },
  { code: 'havre_de_grace', name: 'Havre de Grace' },
  { code: 'mount_airy', name: 'Mount Airy' },
  { code: 'cambridge', name: 'Cambridge' },
  { code: 'frostburg', name: 'Frostburg' },
  { code: 'riverdale_park', name: 'Riverdale Park' },
  { code: 'new_carrollton', name: 'New Carrollton' },
  { code: 'mount_rainier', name: 'Mount Rainier' }
];
