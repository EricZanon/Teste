
import { City } from '../../../types';

export const connecticutCities: City[] = [
  { code: 'bridgeport', name: 'Bridgeport' },
  { code: 'new_haven', name: 'New Haven' },
  { code: 'hartford', name: 'Hartford' },
  { code: 'stamford', name: 'Stamford' },
  { code: 'waterbury', name: 'Waterbury' },
  { code: 'norwalk', name: 'Norwalk' },
  { code: 'danbury', name: 'Danbury' },
  { code: 'new_britain', name: 'New Britain' },
  { code: 'west_hartford', name: 'West Hartford' },
  { code: 'greenwich', name: 'Greenwich' },
  { code: 'hamden', name: 'Hamden' },
  { code: 'meriden', name: 'Meriden' },
  { code: 'bristol', name: 'Bristol' },
  { code: 'west_haven', name: 'West Haven' },
  { code: 'milford', name: 'Milford' },
  { code: 'stratford', name: 'Stratford' },
  { code: 'east_hartford', name: 'East Hartford' },
  { code: 'middletown', name: 'Middletown' },
  { code: 'fairfield', name: 'Fairfield' },
  { code: 'wallingford', name: 'Wallingford' },
  { code: 'enfield', name: 'Enfield' },
  { code: 'southington', name: 'Southington' },
  { code: 'manchester', name: 'Manchester' },
  { code: 'cheshire', name: 'Cheshire' },
  { code: 'vernon', name: 'Vernon' }
];
