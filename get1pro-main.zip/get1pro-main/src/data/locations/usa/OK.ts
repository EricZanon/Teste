
import { City } from '../../../types';

export const oklahomaCities: City[] = [
  { code: 'oklahoma_city', name: 'Oklahoma City' },
  { code: 'tulsa', name: 'Tulsa' },
  { code: 'norman', name: 'Norman' },
  { code: 'broken_arrow', name: 'Broken Arrow' },
  { code: 'edmond', name: 'Edmond' },
  { code: 'lawton', name: 'Lawton' },
  { code: 'moore', name: 'Moore' },
  { code: 'midwest_city', name: 'Midwest City' },
  { code: 'enid', name: 'Enid' },
  { code: 'stillwater', name: 'Stillwater' },
  { code: 'muskogee', name: 'Muskogee' },
  { code: 'bartlesville', name: 'Bartlesville' },
  { code: 'owasso', name: 'Owasso' },
  { code: 'shawnee', name: 'Shawnee' },
  { code: 'ponca_city', name: 'Ponca City' },
  { code: 'ardmore', name: 'Ardmore' },
  { code: 'duncan', name: 'Duncan' },
  { code: 'del_city', name: 'Del City' },
  { code: 'bixby', name: 'Bixby' },
  { code: 'yukon', name: 'Yukon' },
  { code: 'mustang', name: 'Mustang' },
  { code: 'sand_springs', name: 'Sand Springs' },
  { code: 'claremore', name: 'Claremore' },
  { code: 'chickasha', name: 'Chickasha' },
  { code: 'ada', name: 'Ada' }
];
