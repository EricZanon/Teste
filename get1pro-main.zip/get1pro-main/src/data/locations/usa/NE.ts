
import { City } from '../../../types';

export const nebraskaCities: City[] = [
  { code: 'omaha', name: 'Omaha' },
  { code: 'lincoln', name: 'Lincoln' },
  { code: 'bellevue', name: 'Bellevue' },
  { code: 'grand_island', name: 'Grand Island' },
  { code: 'kearney', name: 'Kearney' },
  { code: 'fremont', name: 'Fremont' },
  { code: 'hastings', name: 'Hastings' },
  { code: 'norfolk', name: 'Norfolk' },
  { code: 'columbus', name: 'Columbus' },
  { code: 'north_platte', name: 'North Platte' },
  { code: 'papillion', name: 'Papillion' },
  { code: 'la_vista', name: 'La Vista' },
  { code: 'scottsbluff', name: 'Scottsbluff' },
  { code: 'south_sioux_city', name: 'South Sioux City' },
  { code: 'beatrice', name: 'Beatrice' },
  { code: 'lexington', name: 'Lexington' },
  { code: 'alliance', name: 'Alliance' },
  { code: 'gering', name: 'Gering' },
  { code: 'blair', name: 'Blair' },
  { code: 'york', name: 'York' },
  { code: 'ralston', name: 'Ralston' },
  { code: 'chadron', name: 'Chadron' },
  { code: 'seward', name: 'Seward' },
  { code: 'gretna', name: 'Gretna' },
  { code: 'sidney', name: 'Sidney' }
];
