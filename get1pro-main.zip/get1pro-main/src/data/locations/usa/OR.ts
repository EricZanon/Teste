
import { City } from '../../../types';

export const oregonCities: City[] = [
  { code: 'portland', name: 'Portland' },
  { code: 'eugene', name: 'Eugene' },
  { code: 'salem', name: 'Salem' },
  { code: 'gresham', name: 'Gresham' },
  { code: 'hillsboro', name: 'Hillsboro' },
  { code: 'beaverton', name: 'Beaverton' },
  { code: 'bend', name: 'Bend' },
  { code: 'medford', name: 'Medford' },
  { code: 'springfield', name: 'Springfield' },
  { code: 'corvallis', name: 'Corvallis' },
  { code: 'albany', name: 'Albany' },
  { code: 'tigard', name: 'Tigard' },
  { code: 'lake_oswego', name: 'Lake Oswego' },
  { code: 'keizer', name: 'Keizer' },
  { code: 'grants_pass', name: 'Grants Pass' },
  { code: 'oregon_city', name: 'Oregon City' },
  { code: 'mcminnville', name: 'McMinnville' },
  { code: 'redmond', name: 'Redmond' },
  { code: 'tualatin', name: 'Tualatin' },
  { code: 'west_linn', name: 'West Linn' },
  { code: 'woodburn', name: 'Woodburn' },
  { code: 'forest_grove', name: 'Forest Grove' },
  { code: 'newberg', name: 'Newberg' },
  { code: 'roseburg', name: 'Roseburg' },
  { code: 'happy_valley', name: 'Happy Valley' }
];
