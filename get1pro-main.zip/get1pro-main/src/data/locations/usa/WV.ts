
import { City } from '../../../types';

export const westVirginiaCities: City[] = [
  { code: 'charleston', name: 'Charleston' },
  { code: 'huntington', name: 'Huntington' },
  { code: 'morgantown', name: 'Morgantown' },
  { code: 'parkersburg', name: 'Parkersburg' },
  { code: 'wheeling', name: 'Wheeling' },
  { code: 'weirton', name: 'Weirton' },
  { code: 'fairmont', name: 'Fairmont' },
  { code: 'beckley', name: 'Beckley' },
  { code: 'clarksburg', name: 'Clarksburg' },
  { code: 'martinsburg', name: 'Martinsburg' },
  { code: 'south_charleston', name: 'South Charleston' },
  { code: 'vienna', name: 'Vienna' },
  { code: 'bluefield', name: 'Bluefield' },
  { code: 'st_albans', name: 'St. Albans' },
  { code: 'elkins', name: 'Elkins' },
  { code: 'moundsville', name: 'Moundsville' },
  { code: 'bridgeport', name: 'Bridgeport' },
  { code: 'dunbar', name: 'Dunbar' },
  { code: 'grafton', name: 'Grafton' },
  { code: 'hurricane', name: 'Hurricane' },
  { code: 'nitro', name: 'Nitro' },
  { code: 'princeton', name: 'Princeton' },
  { code: 'charles_town', name: 'Charles Town' },
  { code: 'ranson', name: 'Ranson' },
  { code: 'buckhannon', name: 'Buckhannon' }
];
