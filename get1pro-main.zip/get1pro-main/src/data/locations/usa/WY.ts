
import { City } from '../../../types';

export const wyomingCities: City[] = [
  { code: 'cheyenne', name: 'Cheyenne' },
  { code: 'casper', name: 'Casper' },
  { code: 'laramie', name: 'Laramie' },
  { code: 'gillette', name: 'Gillette' },
  { code: 'rock_springs', name: 'Rock Springs' },
  { code: 'sheridan', name: 'Sheridan' },
  { code: 'green_river', name: 'Green River' },
  { code: 'evanston', name: 'Evanston' },
  { code: 'riverton', name: 'Riverton' },
  { code: 'jackson', name: 'Jackson' },
  { code: 'cody', name: 'Cody' },
  { code: 'rawlins', name: 'Rawlins' },
  { code: 'lander', name: 'Lander' },
  { code: 'torrington', name: 'Torrington' },
  { code: 'powell', name: 'Powell' },
  { code: 'douglas', name: 'Douglas' },
  { code: 'worland', name: 'Worland' },
  { code: 'buffalo', name: 'Buffalo' },
  { code: 'wheatland', name: 'Wheatland' },
  { code: 'newcastle', name: 'Newcastle' }
];
