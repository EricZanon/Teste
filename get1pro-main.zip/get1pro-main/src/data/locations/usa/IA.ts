
import { City } from '../../../types';

export const iowaCities: City[] = [
  { code: 'des_moines', name: 'Des Moines' },
  { code: 'cedar_rapids', name: 'Cedar Rapids' },
  { code: 'davenport', name: 'Davenport' },
  { code: 'sioux_city', name: 'Sioux City' },
  { code: 'iowa_city', name: 'Iowa City' },
  { code: 'waterloo', name: 'Waterloo' },
  { code: 'council_bluffs', name: 'Council Bluffs' },
  { code: 'ames', name: 'Ames' },
  { code: 'west_des_moines', name: 'West Des Moines' },
  { code: 'ankeny', name: 'Ankeny' },
  { code: 'urbandale', name: 'Urbandale' },
  { code: 'cedar_falls', name: 'Cedar Falls' },
  { code: 'marion', name: 'Marion' },
  { code: 'bettendorf', name: 'Bettendorf' },
  { code: 'mason_city', name: 'Mason City' },
  { code: 'clinton', name: 'Clinton' },
  { code: 'burlington', name: 'Burlington' },
  { code: 'fort_dodge', name: 'Fort Dodge' },
  { code: 'marshalltown', name: 'Marshalltown' },
  { code: 'ottumwa', name: 'Ottumwa' },
  { code: 'muscatine', name: 'Muscatine' },
  { code: 'coralville', name: 'Coralville' },
  { code: 'johnston', name: 'Johnston' },
  { code: 'waukee', name: 'Waukee' },
  { code: 'altoona', name: 'Altoona' }
];
