
import { City } from '../../../types';

export const louisianaCities: City[] = [
  { code: 'new_orleans', name: 'New Orleans' },
  { code: 'baton_rouge', name: 'Baton Rouge' },
  { code: 'shreveport', name: 'Shreveport' },
  { code: 'lafayette', name: 'Lafayette' },
  { code: 'lake_charles', name: 'Lake Charles' },
  { code: 'kenner', name: 'Kenner' },
  { code: 'bossier_city', name: 'Bossier City' },
  { code: 'monroe', name: 'Monroe' },
  { code: 'alexandria', name: 'Alexandria' },
  { code: 'houma', name: 'Houma' },
  { code: 'marrero', name: 'Marrero' },
  { code: 'new_iberia', name: 'New Iberia' },
  { code: 'laplace', name: 'LaPlace' },
  { code: 'slidell', name: 'Slidell' },
  { code: 'opelousas', name: 'Opelousas' },
  { code: 'ruston', name: 'Ruston' },
  { code: 'hammond', name: 'Hammond' },
  { code: 'sulphur', name: 'Sulphur' },
  { code: 'natchitoches', name: 'Natchitoches' },
  { code: 'gretna', name: 'Gretna' },
  { code: 'pineville', name: 'Pineville' },
  { code: 'zachary', name: 'Zachary' },
  { code: 'thibodaux', name: 'Thibodaux' },
  { code: 'crowley', name: 'Crowley' },
  { code: 'baker', name: 'Baker' }
];
