
import { City } from '../../../types';

export const utahCities: City[] = [
  { code: 'salt_lake_city', name: 'Salt Lake City' },
  { code: 'west_valley_city', name: 'West Valley City' },
  { code: 'provo', name: 'Provo' },
  { code: 'west_jordan', name: 'West Jordan' },
  { code: 'orem', name: 'Orem' },
  { code: 'sandy', name: 'Sandy' },
  { code: 'ogden', name: 'Ogden' },
  { code: 'st_george', name: 'St. George' },
  { code: 'layton', name: 'Layton' },
  { code: 'taylorsville', name: 'Taylorsville' },
  { code: 'south_jordan', name: 'South Jordan' },
  { code: 'lehi', name: 'Lehi' },
  { code: 'logan', name: 'Logan' },
  { code: 'murray', name: 'Murray' },
  { code: 'draper', name: 'Draper' },
  { code: 'bountiful', name: 'Bountiful' },
  { code: 'riverton', name: 'Riverton' },
  { code: 'roy', name: 'Roy' },
  { code: 'spanish_fork', name: 'Spanish Fork' },
  { code: 'pleasant_grove', name: 'Pleasant Grove' },
  { code: 'cottonwood_heights', name: 'Cottonwood Heights' },
  { code: 'tooele', name: 'Tooele' },
  { code: 'cedar_city', name: 'Cedar City' },
  { code: 'holladay', name: 'Holladay' },
  { code: 'springville', name: 'Springville' }
];
