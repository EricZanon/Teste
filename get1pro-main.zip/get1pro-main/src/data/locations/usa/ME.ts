
import { City } from '../../../types';

export const maineCities: City[] = [
  { code: 'portland', name: 'Portland' },
  { code: 'lewiston', name: 'Lewiston' },
  { code: 'bangor', name: 'Bangor' },
  { code: 'south_portland', name: 'South Portland' },
  { code: 'auburn', name: 'Auburn' },
  { code: 'biddeford', name: 'Biddeford' },
  { code: 'sanford', name: 'Sanford' },
  { code: 'saco', name: 'Saco' },
  { code: 'augusta', name: 'Augusta' },
  { code: 'westbrook', name: 'Westbrook' },
  { code: 'waterville', name: 'Waterville' },
  { code: 'presque_isle', name: 'Presque Isle' },
  { code: 'brewer', name: 'Brewer' },
  { code: 'bath', name: 'Bath' },
  { code: 'caribou', name: 'Caribou' },
  { code: 'ellsworth', name: 'Ellsworth' },
  { code: 'old_town', name: 'Old Town' },
  { code: 'rockland', name: 'Rockland' },
  { code: 'belfast', name: 'Belfast' },
  { code: 'gardiner', name: 'Gardiner' },
  { code: 'eastport', name: 'Eastport' },
  { code: 'calais', name: 'Calais' }
];
