
import { City } from '../../../types';

export const rhodeIslandCities: City[] = [
  { code: 'providence', name: 'Providence' },
  { code: 'warwick', name: 'Warwick' },
  { code: 'cranston', name: 'Cranston' },
  { code: 'pawtucket', name: 'Pawtucket' },
  { code: 'east_providence', name: 'East Providence' },
  { code: 'woonsocket', name: 'Woonsocket' },
  { code: 'coventry', name: 'Coventry' },
  { code: 'cumberland', name: 'Cumberland' },
  { code: 'north_providence', name: 'North Providence' },
  { code: 'south_kingstown', name: 'South Kingstown' },
  { code: 'west_warwick', name: 'West Warwick' },
  { code: 'johnston', name: 'Johnston' },
  { code: 'north_kingstown', name: 'North Kingstown' },
  { code: 'newport', name: 'Newport' },
  { code: 'bristol', name: 'Bristol' },
  { code: 'westerly', name: 'Westerly' },
  { code: 'smithfield', name: 'Smithfield' },
  { code: 'lincoln', name: 'Lincoln' },
  { code: 'central_falls', name: 'Central Falls' },
  { code: 'barrington', name: 'Barrington' }
];
