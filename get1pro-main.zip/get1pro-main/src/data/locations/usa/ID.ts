
import { City } from '../../../types';

export const idahoCities: City[] = [
  { code: 'boise', name: 'Boise' },
  { code: 'nampa', name: 'Nampa' },
  { code: 'meridian', name: 'Meridian' },
  { code: 'idaho_falls', name: 'Idaho Falls' },
  { code: 'pocatello', name: 'Pocatello' },
  { code: 'caldwell', name: 'Caldwell' },
  { code: 'coeur_d_alene', name: 'Coeur d\'Alene' },
  { code: 'twin_falls', name: 'Twin Falls' },
  { code: 'lewiston', name: 'Lewiston' },
  { code: 'post_falls', name: 'Post Falls' },
  { code: 'rexburg', name: 'Rexburg' },
  { code: 'eagle', name: 'Eagle' },
  { code: 'moscow', name: 'Moscow' },
  { code: 'kuna', name: 'Kuna' },
  { code: 'ammon', name: 'Ammon' },
  { code: 'chubbuck', name: 'Chubbuck' },
  { code: 'hayden', name: 'Hayden' },
  { code: 'mountain_home', name: 'Mountain Home' },
  { code: 'blackfoot', name: 'Blackfoot' },
  { code: 'garden_city', name: 'Garden City' }
];
