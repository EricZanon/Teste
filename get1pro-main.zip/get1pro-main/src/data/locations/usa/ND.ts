
import { City } from '../../../types';

export const northDakotaCities: City[] = [
  { code: 'fargo', name: 'Fargo' },
  { code: 'bismarck', name: 'Bismarck' },
  { code: 'grand_forks', name: 'Grand Forks' },
  { code: 'minot', name: 'Minot' },
  { code: 'west_fargo', name: 'West Fargo' },
  { code: 'mandan', name: 'Mandan' },
  { code: 'dickinson', name: 'Dickinson' },
  { code: 'jamestown', name: 'Jamestown' },
  { code: 'williston', name: 'Williston' },
  { code: 'wahpeton', name: 'Wahpeton' },
  { code: 'devils_lake', name: 'Devils Lake' },
  { code: 'valley_city', name: 'Valley City' },
  { code: 'grafton', name: 'Grafton' },
  { code: 'watford_city', name: 'Watford City' },
  { code: 'beulah', name: 'Beulah' },
  { code: 'rugby', name: 'Rugby' },
  { code: 'lisbon', name: 'Lisbon' },
  { code: 'casselton', name: 'Casselton' },
  { code: 'hazen', name: 'Hazen' },
  { code: 'bottineau', name: 'Bottineau' }
];
