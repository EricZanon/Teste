
import { City } from '../../../types';

export const delawareCities: City[] = [
  { code: 'wilmington', name: 'Wilmington' },
  { code: 'dover', name: 'Dover' },
  { code: 'newark', name: 'Newark' },
  { code: 'middletown', name: 'Middletown' },
  { code: 'smyrna', name: 'Smyrna' },
  { code: 'milford', name: 'Milford' },
  { code: 'seaford', name: 'Seaford' },
  { code: 'georgetown', name: 'Georgetown' },
  { code: 'elsmere', name: 'Elsmere' },
  { code: 'new_castle', name: 'New Castle' },
  { code: 'millsboro', name: 'Millsboro' },
  { code: 'laurel', name: 'Laurel' },
  { code: 'harrington', name: 'Harrington' },
  { code: 'camden', name: 'Camden' },
  { code: 'clayton', name: 'Clayton' },
  { code: 'lewes', name: 'Lewes' },
  { code: 'milton', name: 'Milton' },
  { code: 'delmar', name: 'Delmar' },
  { code: 'selbyville', name: 'Selbyville' },
  { code: 'bridgeville', name: 'Bridgeville' }
];
