
import { City } from '../../../types';

export const southCarolinaCities: City[] = [
  { code: 'columbia', name: 'Columbia' },
  { code: 'charleston', name: 'Charleston' },
  { code: 'north_charleston', name: 'North Charleston' },
  { code: 'mount_pleasant', name: 'Mount Pleasant' },
  { code: 'rock_hill', name: 'Rock Hill' },
  { code: 'greenville', name: 'Greenville' },
  { code: 'summerville', name: 'Summerville' },
  { code: 'sumter', name: 'Sumter' },
  { code: 'goose_creek', name: 'Goose Creek' },
  { code: 'hilton_head_island', name: 'Hilton Head Island' },
  { code: 'spartanburg', name: 'Spartanburg' },
  { code: 'florence', name: 'Florence' },
  { code: 'myrtle_beach', name: 'Myrtle Beach' },
  { code: 'aiken', name: 'Aiken' },
  { code: 'greer', name: 'Greer' },
  { code: 'anderson', name: 'Anderson' },
  { code: 'mauldin', name: 'Mauldin' },
  { code: 'greenwood', name: 'Greenwood' },
  { code: 'north_augusta', name: 'North Augusta' },
  { code: 'easley', name: 'Easley' },
  { code: 'orangeburg', name: 'Orangeburg' },
  { code: 'hanahan', name: 'Hanahan' },
  { code: 'simpsonville', name: 'Simpsonville' },
  { code: 'lexington', name: 'Lexington' },
  { code: 'gaffney', name: 'Gaffney' }
];
