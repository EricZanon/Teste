
import { City } from '../../../types';

export const hawaiiCities: City[] = [
  { code: 'honolulu', name: 'Honolulu' },
  { code: 'hilo', name: 'Hilo' },
  { code: 'kailua', name: 'Kailua' },
  { code: 'kapolei', name: 'Kapolei' },
  { code: 'kaneohe', name: 'Kaneohe' },
  { code: 'pearl_city', name: 'Pearl City' },
  { code: 'waipahu', name: 'Waipahu' },
  { code: 'mililani', name: 'Mililani' },
  { code: 'kahului', name: 'Kahului' },
  { code: 'ewa_beach', name: 'Ewa Beach' },
  { code: 'waianae', name: 'Waianae' },
  { code: 'kihei', name: 'Kihei' },
  { code: 'wailuku', name: 'Wailuku' },
  { code: 'lahaina', name: 'Lahaina' },
  { code: 'wahiawa', name: 'Wahiawa' },
  { code: 'makakilo', name: 'Makakilo' },
  { code: 'kailua-kona', name: 'Kailua-Kona' },
  { code: 'aiea', name: 'Aiea' },
  { code: 'waimalu', name: 'Waimalu' },
  { code: 'halawa', name: 'Halawa' }
];
