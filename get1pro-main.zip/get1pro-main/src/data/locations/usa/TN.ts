
import { City } from '../../../types';

export const tennesseeCities: City[] = [
  { code: 'nashville', name: 'Nashville' },
  { code: 'memphis', name: 'Memphis' },
  { code: 'knoxville', name: 'Knoxville' },
  { code: 'chattanooga', name: 'Chattanooga' },
  { code: 'clarksville', name: 'Clarksville' },
  { code: 'murfreesboro', name: 'Murfreesboro' },
  { code: 'franklin', name: 'Franklin' },
  { code: 'jackson', name: 'Jackson' },
  { code: 'johnson_city', name: 'Johnson City' },
  { code: 'hendersonville', name: 'Hendersonville' },
  { code: 'kingsport', name: 'Kingsport' },
  { code: 'bartlett', name: 'Bartlett' },
  { code: 'collierville', name: 'Collierville' },
  { code: 'cleveland', name: 'Cleveland' },
  { code: 'smyrna', name: 'Smyrna' },
  { code: 'germantown', name: 'Germantown' },
  { code: 'brentwood', name: 'Brentwood' },
  { code: 'columbia', name: 'Columbia' },
  { code: 'la_vergne', name: 'La Vergne' },
  { code: 'cookeville', name: 'Cookeville' },
  { code: 'lebanon', name: 'Lebanon' },
  { code: 'spring_hill', name: 'Spring Hill' },
  { code: 'gallatin', name: 'Gallatin' },
  { code: 'morristown', name: 'Morristown' },
  { code: 'oak_ridge', name: 'Oak Ridge' }
];
