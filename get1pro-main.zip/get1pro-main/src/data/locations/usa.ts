
import { City } from '../../types';

import { alabamaCities } from './usa/AL';
import { alaskaCities } from './usa/AK';
import { arizonaCities } from './usa/AZ';
import { arkansasCities } from './usa/AR';
import { californiaCities } from './usa/CA';
import { coloradoCities } from './usa/CO';
import { connecticutCities } from './usa/CT';
import { delawareCities } from './usa/DE';
import { floridaCities } from './usa/FL';
import { georgiaCities } from './usa/GA';
import { hawaiiCities } from './usa/HI';
import { idahoCities } from './usa/ID';
import { illinoisCities } from './usa/IL';
import { indianaCities } from './usa/IN';
import { iowaCities } from './usa/IA';
import { kansasCities } from './usa/KS';
import { kentuckyCities } from './usa/KY';
import { louisianaCities } from './usa/LA';
import { maineCities } from './usa/ME';
import { marylandCities } from './usa/MD';
import { massachusettsCities } from './usa/MA';
import { michiganCities } from './usa/MI';
import { minnesotaCities } from './usa/MN';
import { mississippiCities } from './usa/MS';
import { missouriCities } from './usa/MO';
import { montanaCities } from './usa/MT';
import { nebraskaCities } from './usa/NE';
import { nevadaCities } from './usa/NV';
import { newHampshireCities } from './usa/NH';
import { newJerseyCities } from './usa/NJ';
import { newMexicoCities } from './usa/NM';
import { newYorkCities } from './usa/NY';
import { northCarolinaCities } from './usa/NC';
import { northDakotaCities } from './usa/ND';
import { ohioCities } from './usa/OH';
import { oklahomaCities } from './usa/OK';
import { oregonCities } from './usa/OR';
import { pennsylvaniaCities } from './usa/PA';
import { rhodeIslandCities } from './usa/RI';
import { southCarolinaCities } from './usa/SC';
import { southDakotaCities } from './usa/SD';
import { tennesseeCities } from './usa/TN';
import { texasCities } from './usa/TX';
import { utahCities } from './usa/UT';
import { vermontCities } from './usa/VT';
import { virginiaCities } from './usa/VA';
import { washingtonCities } from './usa/WA';
import { westVirginiaCities } from './usa/WV';
import { wisconsinCities } from './usa/WI';
import { wyomingCities } from './usa/WY';

export const usaCities: Record<string, City[]> = {
  AL: alabamaCities,
  AK: alaskaCities,
  AZ: arizonaCities,
  AR: arkansasCities,
  CA: californiaCities,
  CO: coloradoCities,
  CT: connecticutCities,
  DE: delawareCities,
  FL: floridaCities,
  GA: georgiaCities,
  HI: hawaiiCities,
  ID: idahoCities,
  IL: illinoisCities,
  IN: indianaCities,
  IA: iowaCities,
  KS: kansasCities,
  KY: kentuckyCities,
  LA: louisianaCities,
  ME: maineCities,
  MD: marylandCities,
  MA: massachusettsCities,
  MI: michiganCities,
  MN: minnesotaCities,
  MS: mississippiCities,
  MO: missouriCities,
  MT: montanaCities,
  NE: nebraskaCities,
  NV: nevadaCities,
  NH: newHampshireCities,
  NJ: newJerseyCities,
  NM: newMexicoCities,
  NY: newYorkCities,
  NC: northCarolinaCities,
  ND: northDakotaCities,
  OH: ohioCities,
  OK: oklahomaCities,
  OR: oregonCities,
  PA: pennsylvaniaCities,
  RI: rhodeIslandCities,
  SC: southCarolinaCities,
  SD: southDakotaCities,
  TN: tennesseeCities,
  TX: texasCities,
  UT: utahCities,
  VT: vermontCities,
  VA: virginiaCities,
  WA: washingtonCities,
  WV: westVirginiaCities,
  WI: wisconsinCities,
  WY: wyomingCities
};
