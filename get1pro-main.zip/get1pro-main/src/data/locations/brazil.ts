
import { City } from '../../types';
import { acreCities } from './brazil/AC';
import { alagoasCities } from './brazil/AL';
import { amapaCities } from './brazil/AP';
import { amazonasCities } from './brazil/AM';
import { bahiaCities } from './brazil/BA';
import { cearaCities } from './brazil/CE';
import { distritoFederalCities } from './brazil/DF';
import { espiritoSantoCities } from './brazil/ES';
import { goiasCities } from './brazil/GO';
import { maranhaoCities } from './brazil/MA';
import { matoGrossoCities } from './brazil/MT';
import { matoGrossoDoSulCities } from './brazil/MS';
import { minasGeraisCities } from './brazil/MG';
import { paraCities } from './brazil/PA';
import { paraibaCities } from './brazil/PB';
import { paranaCities } from './brazil/PR';
import { pernambucoCities } from './brazil/PE';
import { piauiCities } from './brazil/PI';
import { rioDeJaneiroCities } from './brazil/RJ';
import { rioGrandeDoNorteCities } from './brazil/RN';
import { rioGrandeDoSulCities } from './brazil/RS';
import { rondoniaciaCities } from './brazil/RO';
import { roraimaCities } from './brazil/RR';
import { santaCatarinaCities } from './brazil/SC';
import { saoPauloCities } from './brazil/SP';
import { sergipeCities } from './brazil/SE';
import { tocantinsCities } from './brazil/TO';

export const brazilCities: Record<string, City[]> = {
  AC: acreCities,
  AL: alagoasCities,
  AP: amapaCities,
  AM: amazonasCities,
  BA: bahiaCities,
  CE: cearaCities,
  DF: distritoFederalCities,
  ES: espiritoSantoCities,
  GO: goiasCities,
  MA: maranhaoCities,
  MT: matoGrossoCities,
  MS: matoGrossoDoSulCities,
  MG: minasGeraisCities,
  PA: paraCities,
  PB: paraibaCities,
  PR: paranaCities,
  PE: pernambucoCities,
  PI: piauiCities,
  RJ: rioDeJaneiroCities,
  RN: rioGrandeDoNorteCities,
  RS: rioGrandeDoSulCities,
  RO: rondoniaciaCities,
  RR: roraimaCities,
  SC: santaCatarinaCities,
  SP: saoPauloCities,
  SE: sergipeCities,
  TO: tocantinsCities
};
