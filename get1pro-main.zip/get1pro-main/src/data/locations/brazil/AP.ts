
import { City } from '../../../types';

export const amapaCities: City[] = [
  { code: 'macapa', name: 'Macapá' },
  { code: 'santana', name: 'Santana' },
  { code: 'laranjal_do_jari', name: 'Laranjal do Jari' },
  { code: 'oiapoque', name: 'Oiapoque' },
  { code: 'porto_grande', name: 'Porto Grande' },
  { code: 'mazagao', name: 'Mazagão' },
  { code: 'tartarugalzinho', name: 'Tartarugalzinho' },
  { code: 'vitoria_do_jari', name: 'Vitória do Jari' },
  { code: 'ferreira_gomes', name: 'Ferreira Gomes' },
  { code: 'calcoene', name: 'Calçoene' },
  { code: 'amapa', name: 'Amapá' },
  { code: 'pedra_branca_do_amapari', name: 'Pedra Branca do Amapari' },
  { code: 'serra_do_navio', name: 'Serra do Navio' },
  { code: 'cutias', name: 'Cutias' },
  { code: 'itaubal', name: 'Itaubal' },
  { code: 'pracuuba', name: 'Pracuúba' }
];
