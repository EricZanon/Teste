
import { City } from '../../../types';

export const roraimaCities: City[] = [
  { code: 'boa_vista', name: 'Boa Vista' },
  { code: 'caracarai', name: 'Caracaraí' },
  { code: 'rorainopolis', name: 'Rorainópolis' },
  { code: 'alto_alegre', name: 'Alto Alegre' },
  { code: 'mucajai', name: 'Mucajaí' },
  { code: 'pacaraima', name: 'Pacaraima' },
  { code: 'canta', name: 'Cantá' },
  { code: 'bonfim', name: 'Bonfim' },
  { code: 'amajari', name: 'Amajari' },
  { code: 'sao_joao_da_baliza', name: 'São João da Baliza' },
  { code: 'caroebe', name: 'Caroebe' },
  { code: 'sao_luiz', name: 'São Luiz' },
  { code: 'normandia', name: 'Normandia' },
  { code: 'iracema', name: 'Iracema' },
  { code: 'uiramuta', name: 'Uiramutã' }
];
