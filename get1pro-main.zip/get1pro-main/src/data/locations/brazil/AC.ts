
import { City } from '../../../types';

export const acreCities: City[] = [
  { code: 'rio_branco', name: 'Rio Branco' },
  { code: 'cruzeiro_do_sul', name: 'Cruzeiro do Sul' },
  { code: 'sena_madureira', name: 'Sena Madureira' },
  { code: 'tarauaca', name: 'Tarauacá' },
  { code: 'feijo', name: 'Feijó' },
  { code: 'brasileia', name: 'Brasiléia' },
  { code: 'epitaciolandia', name: 'Epitaciolândia' },
  { code: 'xapuri', name: 'Xapuri' },
  { code: 'porto_acre', name: 'Porto Acre' },
  { code: 'mancio_lima', name: 'Mâncio Lima' },
  { code: 'placido_de_castro', name: 'Plácido de Castro' },
  { code: 'manoel_urbano', name: 'Manoel Urbano' },
  { code: 'rodrigues_alves', name: 'Rodrigues Alves' },
  { code: 'acrelandia', name: 'Acrelândia' },
  { code: 'capixaba', name: 'Capixaba' },
  { code: 'jordao', name: 'Jordão' },
  { code: 'porto_walter', name: 'Porto Walter' },
  { code: 'marechal_thaumaturgo', name: 'Marechal Thaumaturgo' },
  { code: 'santa_rosa_do_purus', name: 'Santa Rosa do Purus' },
  { code: 'assis_brasil', name: 'Assis Brasil' },
  { code: 'bujari', name: 'Bujari' },
  { code: 'senador_guiomard', name: 'Senador Guiomard' }
];
