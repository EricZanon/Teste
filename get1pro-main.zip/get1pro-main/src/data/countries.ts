
import { Country } from '../types';

export const countries: Country[] = [
  { code: 'BR', name: 'Brasil' },
  { code: 'US', name: 'Estados Unidos' }
];
