
import { ServiceType } from '../types';

export const serviceTypes: ServiceType[] = [
  { id: '1', name: 'Eletricista' },
  { id: '2', name: 'Encanador' },
  { id: '3', name: 'Diarista' },
  { id: '4', name: 'Pintor' },
  { id: '5', name: 'Jardineiro' },
  { id: '6', name: 'Pedreiro' },
  { id: '7', name: 'Marceneiro' },
  { id: '8', name: 'Técnico de Ar Condicionado' },
];

export const cities = {
  SP: [
    'São Paulo',
    'Campinas',
    'Guarulhos',
    'Santos',
    'Ribeirão Preto',
  ],
  RJ: [
    'Rio de Janeiro',
    'Niterói',
    'Petrópolis',
    'Duque de Caxias',
    'Nova Iguaçu',
  ],
  MG: [
    'Belo Horizonte',
    'Uberlândia',
    'Contagem',
    'Juiz de Fora',
    'Betim',
  ],
  BA: [
    'Salvador',
    'Feira de Santana',
    'Vitória da Conquista',
    'Camaçari',
    'Itabuna',
  ],
  RS: [
    'Porto Alegre',
    'Caxias do Sul',
    'Pelotas',
    'Canoas',
    'Santa Maria',
  ],
};
