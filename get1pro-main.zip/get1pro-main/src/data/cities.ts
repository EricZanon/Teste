
import { City } from '../types';
import { brazilCities } from './locations/brazil';
import { usaCities } from './locations/usa';

export const cities: Record<string, Record<string, City[]>> = {
  BR: brazilCities,
  US: usaCities
};
