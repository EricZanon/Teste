import { ServiceProvider } from '../types';

export const serviceProviders: ServiceProvider[] = [
  // São Paulo (SP)
  {
    id: '1',
    name: 'Carlos Silva',
    service: 'Eletricista',
    phone: '(11) 98765-4321',
    socialMedia: {
      instagram: 'carlos_eletricista',
      facebook: 'carlossilvaeletricista',
      googleBusiness: 'carlos-silva-eletricista'
    },
    rating: 4.8,
    location: {
      lat: -23.5505,
      lng: -46.6333,
      address: 'Rua das Flores, 123',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '2',
    name: 'Ana Oliveira',
    service: 'Diarista',
    phone: '(11) 91234-5678',
    socialMedia: {
      instagram: 'ana_diarista',
      facebook: 'anaoliveiradiarista'
    },
    rating: 4.9,
    location: {
      lat: -23.5587,
      lng: -46.6401,
      address: 'Av. Paulista, 1000',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '3',
    name: 'Pedro Santos',
    service: 'Encanador',
    phone: '(11) 95555-6666',
    socialMedia: {
      instagram: 'pedro_encanador',
      googleBusiness: 'pedro-santos-encanador'
    },
    rating: 4.6,
    location: {
      lat: -23.5635,
      lng: -46.6522,
      address: 'Rua Augusta, 500',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '4',
    name: 'Fernanda Lima',
    service: 'Pintora',
    phone: '(11) 94444-3333',
    socialMedia: {
      instagram: 'fe_pintora',
      facebook: 'fernandalimapintora',
      googleBusiness: 'fernanda-lima-pintora'
    },
    rating: 4.7,
    location: {
      lat: -23.5805,
      lng: -46.6453,
      address: 'Rua Oscar Freire, 700',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '5',
    name: 'Roberto Martins',
    service: 'Jardineiro',
    phone: '(11) 97777-8888',
    socialMedia: {
      instagram: 'roberto_jardins',
      googleBusiness: 'roberto-martins-jardinagem'
    },
    rating: 4.5,
    location: {
      lat: -23.5905,
      lng: -46.6703,
      address: 'Rua dos Pinheiros, 300',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '6',
    name: 'Marcos Gomes',
    service: 'Pedreiro',
    phone: '(11) 96321-1234',
    socialMedia: {
      instagram: 'marcos_pedreiro'
    },
    rating: 4.1,
    location: {
      lat: -23.6123,
      lng: -46.6921,
      address: 'Avenida Ipiranga, 678',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '7',
    name: 'Tatiane Moraes',
    service: 'Marceneira',
    phone: '(11) 90099-8877',
    socialMedia: {
      instagram: 'tatimarcenaria'
    },
    rating: 4.2,
    location: {
      lat: -23.5292,
      lng: -46.6291,
      address: 'Rua Vergueiro, 2400',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '8',
    name: 'Daniel Ferreira',
    service: 'Técnico de Ar Condicionado',
    phone: '(11) 98999-2233',
    socialMedia: {
      facebook: 'danielclimasp'
    },
    rating: 3.7,
    location: {
      lat: -23.5225,
      lng: -46.6990,
      address: 'Rua Aurora, 55',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  // Campinas (SP)
  {
    id: '9',
    name: 'Juliana Brito',
    service: 'Diarista',
    phone: '(19) 98888-2233',
    socialMedia: {
      instagram: 'julianalimpacampinas'
    },
    rating: 5,
    location: {
      lat: -22.9009,
      lng: -47.0573,
      address: 'Rua das Palmeiras, 82',
      city: 'Campinas',
      state: 'SP'
    }
  },
  {
    id: '10',
    name: 'Paula Souza',
    service: 'Encanadora',
    phone: '(19) 97777-3566',
    socialMedia: {},
    rating: 4.4,
    location: {
      lat: -22.9086,
      lng: -47.0632,
      address: 'Rua General Osório, 321',
      city: 'Campinas',
      state: 'SP'
    }
  },
  // Rio de Janeiro (RJ)
  {
    id: '11',
    name: 'Henrique Paz',
    service: 'Eletricista',
    phone: '(21) 92345-1122',
    socialMedia: {
      instagram: 'henrique_eletro_rio'
    },
    rating: 4.9,
    location: {
      lat: -22.9083,
      lng: -43.1964,
      address: 'Rua Farme de Amoedo, 67',
      city: 'Rio de Janeiro',
      state: 'RJ'
    }
  },
  {
    id: '12',
    name: 'Bruna Almeida',
    service: 'Diarista',
    phone: '(21) 90000-1234',
    socialMedia: {
      facebook: 'brunadiarista'
    },
    rating: 4.6,
    location: {
      lat: -22.9129,
      lng: -43.2003,
      address: 'Rua da Glória, 10',
      city: 'Rio de Janeiro',
      state: 'RJ'
    }
  },
  {
    id: '13',
    name: 'Lucas Souza',
    service: 'Técnico de Ar Condicionado',
    phone: '(21) 95678-3456',
    socialMedia: {},
    rating: 5,
    location: {
      lat: -22.9234,
      lng: -43.2345,
      address: 'Rua da Paz, 99',
      city: 'Rio de Janeiro',
      state: 'RJ'
    }
  },
  // Belo Horizonte (MG)
  {
    id: '14',
    name: 'Carla Silva',
    service: 'Encanadora',
    phone: '(31) 91234-5566',
    socialMedia: {
      instagram: 'carla24hbh'
    },
    rating: 3.9,
    location: {
      lat: -19.9245,
      lng: -43.9352,
      address: 'Av. Afonso Pena, 3001',
      city: 'Belo Horizonte',
      state: 'MG'
    }
  },
  {
    id: '15',
    name: 'Luiz Augusto',
    service: 'Jardineiro',
    phone: '(31) 99887-7766',
    socialMedia: {
      facebook: 'luizjardinsbh'
    },
    rating: 4.3,
    location: {
      lat: -19.9201,
      lng: -43.9419,
      address: 'Rua Goiás, 29',
      city: 'Belo Horizonte',
      state: 'MG'
    }
  },
  // Salvador (BA)
  {
    id: '16',
    name: 'Ivone Costa',
    service: 'Diarista',
    phone: '(71) 99191-3131',
    socialMedia: {
      instagram: 'ivonelimpaba'
    },
    rating: 4.2,
    location: {
      lat: -12.9711,
      lng: -38.5108,
      address: 'Av. Sete de Setembro, 88',
      city: 'Salvador',
      state: 'BA'
    }
  },
  {
    id: '17',
    name: 'Wagner Barreto',
    service: 'Pedreiro',
    phone: '(71) 99878-7788',
    socialMedia: {},
    rating: 4.1,
    location: {
      lat: -12.9777,
      lng: -38.5016,
      address: 'Rua do Carmo, 77',
      city: 'Salvador',
      state: 'BA'
    }
  },
  // Porto Alegre (RS)
  {
    id: '18',
    name: 'Marisa Farias',
    service: 'Pintora',
    phone: '(51) 93333-1122',
    socialMedia: {},
    rating: 4.7,
    location: {
      lat: -30.0346,
      lng: -51.2177,
      address: 'Rua Padre Chagas, 11',
      city: 'Porto Alegre',
      state: 'RS'
    }
  },
  {
    id: '19',
    name: 'José Ricardo',
    service: 'Eletricista',
    phone: '(51) 91111-2233',
    socialMedia: {
      facebook: 'eletricistapa'
    },
    rating: 3.8,
    location: {
      lat: -30.0425,
      lng: -51.2303,
      address: 'Av. Ipiranga, 3500',
      city: 'Porto Alegre',
      state: 'RS'
    }
  },
  {
    id: '20',
    name: 'Elisa Coelho',
    service: 'Marceneira',
    phone: '(51) 94545-7766',
    socialMedia: {
      instagram: 'elisamarcenaria'
    },
    rating: 4.6,
    location: {
      lat: -30.0523,
      lng: -51.2061,
      address: 'Rua Santana, 2050',
      city: 'Porto Alegre',
      state: 'RS'
    }
  },
  // New Electrician (Eletricista) entries for São Paulo
  {
    id: '21',
    name: 'Eduardo Mendes',
    service: 'Eletricista',
    phone: '(11) 97654-3210',
    socialMedia: {
      instagram: 'eduardo_eletro_sp',
      facebook: 'eduardomendeseletricista'
    },
    rating: 4.6,
    location: {
      lat: -23.5470,
      lng: -46.6361,
      address: 'Rua Margarida, 456',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '22',
    name: 'Mariana Costa',
    service: 'Eletricista',
    phone: '(11) 93333-7777',
    socialMedia: {
      googleBusiness: 'mariana-costa-eletricista',
      instagram: 'mari_eletricista_sp'
    },
    rating: 4.9,
    location: {
      lat: -23.5550,
      lng: -46.6400,
      address: 'Av. Brigadeiro Luís Antônio, 789',
      city: 'São Paulo',
      state: 'SP'
    }
  },
  {
    id: '23',
    name: 'Ricardo Oliveira',
    service: 'Eletricista',
    phone: '(11) 95555-2222',
    socialMedia: {
      facebook: 'ricardoeletroservicos'
    },
    rating: 4.3,
    location: {
      lat: -23.5620,
      lng: -46.6550,
      address: 'Rua Joaquim Eugênio, 234',
      city: 'São Paulo',
      state: 'SP'
    }
  },
];
