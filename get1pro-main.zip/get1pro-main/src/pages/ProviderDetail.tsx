import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MapPin, Briefcase, Star, MessageSquare } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { ServiceProvider } from '@/types';
import { useIsMobile } from '@/hooks/use-mobile';
import { useProviderDetailPage } from '@/hooks/useProviderDetailPage';
import { useCityName } from '@/hooks/useCityName';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import ProviderNotFound from '@/components/provider/ProviderNotFound';
import ProviderAvatar from '@/components/provider/ProviderAvatar';
import SocialMediaButtons from '@/components/provider/SocialMediaButtons';
import RatingStars from '@/components/RatingStars';
import { useProviderRating } from '@/hooks/useProviderRating';
import { Link } from 'react-router-dom';
import { formatPhoneForDisplay } from '@/utils/phoneUtils';

const ProviderDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const isMobile = useIsMobile();
  const { provider, loading } = useProviderDetailPage(id);
  const { rating: realRating, reviewCount: realReviewCount } = useProviderRating(id);
  const { cityName } = useCityName(provider?.location?.city || '', provider?.location?.state || '');

  const handleBack = () => {
    navigate(-1);
  };

  const formatServiceRegion = () => {
    if (!provider?.service_region) {
      return language === 'pt' 
        ? 'Região de atendimento não especificada' 
        : 'Service region not specified';
    }

    if (/\d/.test(provider.service_region)) {
      const numericValue = parseFloat(provider.service_region.replace(/[^\d.]/g, ''));
      if (!isNaN(numericValue)) {
        return language === 'pt' 
          ? `${numericValue}km` 
          : `${Math.round(numericValue * 0.621371)}mi`;
      }
    }

    return provider.service_region;
  };

  if (loading) return <LoadingSpinner />;
  if (!provider) return <ProviderNotFound />;

  // Ensure all social media data is properly formatted
  const socialMediaData = {
    website: provider.website || provider.socialMedia?.website || '',
    instagram: provider.socialMedia?.instagram || '',
    facebook: provider.socialMedia?.facebook || '',
    googleBusiness: provider.socialMedia?.googleBusiness || '',
    sms: provider.socialMedia?.sms || provider.phone || '',
    phone: provider.socialMedia?.phone || provider.phone || '',
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col">
      <Header />
      
      <main className="container mx-auto max-w-[600px] px-4 py-4 pt-8 w-full flex-1">
        {/* Header with back button */}
        <div className="flex items-center mb-6">
          <Button variant="ghost" size="sm" onClick={handleBack} className="mr-2">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold">{t('provider.details')}</h1>
        </div>

        {/* Provider Profile Card */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 mb-6" style={{boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'}}>
          {/* Avatar and Basic Info */}
          <div className="flex flex-col items-center text-center mb-6">
            <ProviderAvatar 
              name={provider.name}
              imageUrl={provider.profile_image_url}
              size="xl"
            />
            <h2 className="text-2xl font-bold mt-4 dark:text-white">{provider.name}</h2>
            <p className="text-gray-600 dark:text-gray-300 text-lg">{provider.service}</p>
            
            {/* Rating */}
            <div className="flex items-center gap-2 mt-2">
              <RatingStars rating={realRating} />
              <Link 
                to={`/profissional/${id}/avaliacoes`} 
                className="text-app-primary hover:underline text-sm dark:text-blue-400 flex items-center gap-1"
              >
                <MessageSquare className="h-3 w-3" />
                {realReviewCount} {realReviewCount === 1 ? t('avaliação') : t('avaliações')}
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
              <span className="text-lg">📞</span>
              <span>{formatPhoneForDisplay(provider.phone)}</span>
            </div>
            
            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
              <MapPin className="h-4 w-4" />
              <span>{cityName || provider.location?.city}, {provider.location?.state}</span>
            </div>

            {provider.experience_years && (
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
                <Briefcase className="h-4 w-4" />
                <span>{provider.experience_years} {t('provider.years')} de experiência</span>
              </div>
            )}

            <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
              <MapPin className="h-4 w-4" />
              <span><strong>Área de atendimento:</strong> {formatServiceRegion()}</span>
            </div>
          </div>

          {/* Social Media Buttons */}
          <div className="flex justify-center mb-6">
            <SocialMediaButtons 
              providerId={provider.id}
              phone={provider.phone}
              socialMedia={socialMediaData}
            />
          </div>
        </div>

        {/* About Section */}
        {provider.about && (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6" style={{boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'}}>
            <h3 className="text-lg font-semibold mb-3 dark:text-white">{t('provider.about')}</h3>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              {provider.about}
            </p>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default ProviderDetail;
