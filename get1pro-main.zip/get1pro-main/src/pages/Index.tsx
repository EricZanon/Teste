import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SearchForm from '@/components/search/SearchForm';
import ProviderList from '@/components/ProviderList';
import { ServiceProvider } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { useProviders } from '@/hooks/useProviders';
import { useFilterContext } from '@/contexts/FilterContext';
import { useToast } from '@/components/ui/use-toast';

const Index = () => {
  const {
    searchCriteria,
    setSearchCriteria,
    hasSearched,
    setHasSearched,
    filteredProviders,
    setFilteredProviders,
    resetFilters
  } = useFilterContext();
  const {
    t
  } = useLanguage();
  const isMobile = useIsMobile();
  const {
    providers,
    loading,
    refetch
  } = useProviders();
  const {
    toast
  } = useToast();

  // Clear filters on page reload/mount
  useEffect(() => {
    // Check if this is a fresh page load (not a navigation)
    const navigationEntries = performance.getEntriesByType('navigation');
    const navigationType = navigationEntries.length > 0 ? (navigationEntries[0] as PerformanceNavigationTiming).type : 'navigate';

    // If it's a reload, clear the filters
    if (navigationType === 'reload') {
      resetFilters();
    }
  }, [resetFilters]);

  const handleSearch = (state: string, city: string, service: string) => {
    console.log('Search criteria:', {
      state,
      city,
      service
    });
    // Save search criteria for refiltering
    setSearchCriteria({
      state,
      city,
      service
    });

    // Filter providers based on search criteria
    applyFilters(state, city, service);
    setHasSearched(true);
  };

  // Apply all filters (search criteria)
  const applyFilters = (state: string, city: string, service: string) => {
    console.log('Applying filters:', {
      state,
      city,
      service
    });
    console.log('Available providers:', providers);
    let filtered = [...providers];
    if (state) {
      console.log('Filtering by state:', state);
      filtered = filtered.filter(provider => {
        const matches = provider.location.state === state;
        console.log(`Provider ${provider.name} state: ${provider.location.state}, matches: ${matches}`);
        return matches;
      });
      console.log('After state filter:', filtered.length);
    }
    if (city) {
      console.log('Filtering by city:', city);
      filtered = filtered.filter(provider => {
        const matches = provider.location.city === city;
        console.log(`Provider ${provider.name} city: ${provider.location.city}, matches: ${matches}`);
        return matches;
      });
      console.log('After city filter:', filtered.length);
    }
    if (service) {
      console.log('Filtering by service:', service);
      filtered = filtered.filter(provider => {
        // Check both service_type (ID) and service (name) for compatibility
        const matchesServiceType = provider.service_type === service;
        const matchesServiceName = provider.service === service;
        const matches = matchesServiceType || matchesServiceName;
        console.log(`Provider ${provider.name} service_type: ${provider.service_type}, service: ${provider.service}, search: ${service}, matches: ${matches}`);
        return matches;
      });
      console.log('After service filter:', filtered.length);
    }

    // Sort alphabetically by name instead of distance
    filtered = filtered.sort((a, b) => a.name.localeCompare(b.name));
    console.log('Final filtered providers:', filtered);
    setFilteredProviders(filtered);

    // Show toast if no results found
    if (filtered.length === 0 && state && city) {
      toast({
        title: t('search.results.empty_title'),
        description: t('search.results.empty_description'),
        duration: 5000
      });
    }
  };

  // Update results when providers change
  useEffect(() => {
    if (hasSearched && providers.length > 0) {
      applyFilters(searchCriteria.state, searchCriteria.city, searchCriteria.service);
    }
  }, [providers, hasSearched, searchCriteria]);

  return <div className="min-h-screen flex flex-col items-center">
      <div className="w-full max-w-[600px]">
        <Header />
        
        <main className="container mx-auto px-4 py-4 pt-8">
          {loading ? <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-app-primary"></div>
            </div> : <>
              <SearchForm onSearch={handleSearch} initialState={searchCriteria.state} initialCity={searchCriteria.city} initialService={searchCriteria.service} />
              
              {hasSearched ? <>
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold my-[14px]">
                      {filteredProviders.length > 0 ? `${filteredProviders.length} ${t('search.results.found')}` : t('search.results.notFound')}
                    </h2>
                  </div>
                  <ProviderList filteredProviders={filteredProviders} />
                </> : <div className="text-center py-8" style={{
            paddingTop: '1rem'
          }}>
                  <p className="text-lg mb-2">{t('search.title')}</p>
                  <p className="text-app-darkgray dark:text-gray-400 mb-4" style={{
              marginBottom: '2rem'
            }}>{t('search.subtitle')}</p>
                  <div className="flex flex-col gap-4 justify-center items-center mb-6">
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg text-center w-full" style={{
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
              }}>
                      <span className="text-3xl mb-2 block">🔍</span>
                      <h3 className="font-semibold mb-1">{t('search.steps.search.title')}</h3>
                      <p className="text-sm text-app-darkgray dark:text-gray-400">{t('search.steps.search.description')}</p>
                    </div>
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg text-center w-full" style={{
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
              }}>
                      <span className="text-3xl mb-2 block">👨‍🔧</span>
                      <h3 className="font-semibold mb-1">{t('search.steps.find.title')}</h3>
                      <p className="text-sm text-app-darkgray dark:text-gray-400">{t('search.steps.find.description')}</p>
                    </div>
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg text-center w-full" style={{
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
              }}>
                      <span className="text-3xl mb-2 block">📞</span>
                      <h3 className="font-semibold mb-1">{t('search.steps.contact.title')}</h3>
                      <p className="text-sm text-app-darkgray dark:text-gray-400">{t('search.steps.contact.description')}</p>
                    </div>
                  </div>
                </div>}
            </>}
        </main>
      </div>
      
      <Footer />
    </div>;
};

export default Index;
