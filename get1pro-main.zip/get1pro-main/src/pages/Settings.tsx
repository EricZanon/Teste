
import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Shield, CreditCard, UserCog } from 'lucide-react';
import { UserProfileForm } from '@/components/settings/UserProfileForm';
import ProfessionalProfileForm from '@/components/settings/ProfessionalProfileForm';
import { ChangePasswordForm } from '@/components/settings/ChangePasswordForm';
import { SubscriptionPlans } from '@/components/settings/provider/SubscriptionPlans';
import { Toaster } from '@/components/ui/toaster';
import { useNavigate } from 'react-router-dom';
import { useSubscriptionCheck } from '@/hooks/useSubscriptionCheck';

const Settings = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string>('profile');
  
  // Initialize subscription check
  useSubscriptionCheck();

  React.useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  if (!user) {
    return null;
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="container mx-auto max-w-4xl flex-1 px-4 py-8 pt-20">
        <div className="space-y-6">
          <div className="text-center md:text-left">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              {t('settings.title')}
            </h1>
            <p className="text-muted-foreground">
              Gerencie suas informações pessoais e profissionais
            </p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full space-y-6">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto p-1 bg-muted/50">
              <TabsTrigger 
                value="profile" 
                className="flex flex-col md:flex-row items-center gap-1 md:gap-2 py-3 px-2 text-xs md:text-sm"
              >
                <User className="h-4 w-4" />
                <span className="font-medium">{t('settings.profile')}</span>
              </TabsTrigger>
              <TabsTrigger 
                value="professional" 
                className="flex flex-col md:flex-row items-center gap-1 md:gap-2 py-3 px-2 text-xs md:text-sm"
              >
                <UserCog className="h-4 w-4" />
                <span className="font-medium">{t('settings.professional')}</span>
              </TabsTrigger>
              <TabsTrigger 
                value="security" 
                className="flex flex-col md:flex-row items-center gap-1 md:gap-2 py-3 px-2 text-xs md:text-sm"
              >
                <Shield className="h-4 w-4" />
                <span className="font-medium">{t('settings.security')}</span>
              </TabsTrigger>
              <TabsTrigger 
                value="subscription" 
                className="flex flex-col md:flex-row items-center gap-1 md:gap-2 py-3 px-2 text-xs md:text-sm"
              >
                <CreditCard className="h-4 w-4" />
                <span className="font-medium">Assinatura</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile" className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">{t('settings.profile_information')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <UserProfileForm />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="professional" className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">{t('settings.professional_profile')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ProfessionalProfileForm />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security" className="space-y-6">
              <Card className="shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">{t('settings.change_password')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ChangePasswordForm />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="subscription" className="space-y-6">
              <SubscriptionPlans />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default Settings;
