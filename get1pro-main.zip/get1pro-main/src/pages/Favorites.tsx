
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFavoritesContext } from '@/contexts/FavoritesContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { ScrollArea } from '@/components/ui/scroll-area';
import ProviderCard from '@/components/ProviderCard';
import { Skeleton } from '@/components/ui/skeleton';
import { ServiceProvider } from '@/types';
import { incrementProviderMetric } from '@/services/metricsService';

const Favorites = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [mounted, setMounted] = useState(false);
  const [providers, setProviders] = useState<ServiceProvider[]>([]);
  
  let favorites = [];
  let favoriteProviders: ServiceProvider[] = [];
  let loading = false;
  let lastUpdateTime = 0;
  
  try {
    const favoritesContext = useFavoritesContext();
    favorites = favoritesContext.favorites;
    favoriteProviders = favoritesContext.favoriteProviders;
    loading = favoritesContext.loading;
    lastUpdateTime = favoritesContext.lastUpdateTime || 0;
  } catch (error) {
    console.error('FavoritesContext not available:', error);
  }

  // Handle going back to the previous page
  const handleGoBack = () => {
    navigate(-1);
  };

  // Handle sharing all favorite providers
  const handleShareAll = async () => {
    if (favoriteProviders.length === 0) {
      toast({
        description: t('favorites.noProvidersToShare'),
        duration: 2000
      });
      return;
    }
    const baseUrl = window.location.origin;
    const shareText = t('favorites.shareText');

    // Create list of provider names and their IDs for sharing
    const providersList = favoriteProviders.map(p => p.name).join(', ');

    // Create deep link with all provider IDs
    const providerIds = favoriteProviders.map(p => p.id).join(',');
    const shareUrl = `${baseUrl}/favoritos?ids=${providerIds}`;
    try {
      // Track sharing in metrics for all providers
      for (const provider of favoriteProviders) {
        try {
          await incrementProviderMetric(provider.id, 'shares');
        } catch (err) {
          console.error(`Error recording share for provider ${provider.id}:`, err);
        }
      }
      console.log('Sharing URL with IDs:', shareUrl);

      // Use Web Share API if available
      if (navigator.share) {
        await navigator.share({
          title: t('favorites.shareTitle'),
          text: `${shareText}\n${providersList}`,
          url: shareUrl
        });
        toast({
          description: t('favorites.shareSuccess'),
          duration: 2000
        });
        return;
      }

      // Fallback to clipboard
      const fullShareText = `${shareText}\n${providersList}\n${shareUrl}`;
      await navigator.clipboard.writeText(fullShareText);
      toast({
        description: t('favorites.copied'),
        duration: 2000
      });
    } catch (error) {
      console.error('Error sharing favorites:', error);
      toast({
        description: t('favorites.shareError'),
        duration: 2000
      });
    }
  };

  useEffect(() => {
    setMounted(true);
    console.log('Favorites page mounted with providers:', favoriteProviders.length);

    // Force refresh of providers when component mounts
    setProviders([...favoriteProviders]);
  }, [favoriteProviders, lastUpdateTime]);

  if (!mounted) {
    return null; // Wait until after client-side hydration
  }

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900 flex flex-col">
      <div className="w-full max-w-[600px] mx-auto flex-1">
        <Header />
        
        <main className="container mx-auto px-4 py-6 pt-16">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" onClick={handleGoBack} className="mr-2">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <h1 className="text-2xl font-bold py-0 my-[20px]">{t('favorites.title')}</h1>
            </div>
            
            <Button variant="outline" size="sm" onClick={handleShareAll} className="flex items-center gap-1">
              <Share2 className="h-4 w-4" />
              <span>{t('favorites.shareList')}</span>
            </Button>
          </div>
          
          {loading ? (
            <div className="space-y-4">
              <Skeleton className="h-[100px] w-full" />
              <Skeleton className="h-[100px] w-full" />
              <Skeleton className="h-[100px] w-full" />
            </div>
          ) : favorites.length === 0 ? (
            <div className="text-center p-4 text-muted-foreground">
              <p>{t('favorites.empty')}</p>
            </div>
          ) : favoriteProviders.length === 0 ? (
            <div className="text-center p-4 text-muted-foreground">
              <p>{t('favorites.notFound')}</p>
            </div>
          ) : (
            <ScrollArea className="h-full w-full">
              <div className="space-y-4 pb-20">
                {favoriteProviders.map(provider => {
                  // Generate unique keys for each provider
                  const uniqueKey = `${provider.id}-${lastUpdateTime}`;
                  return (
                    <div key={uniqueKey} className="provider-card-wrapper" style={{
                      touchAction: 'manipulation',
                      WebkitTapHighlightColor: 'rgba(0,0,0,0)'
                    }}>
                      <ProviderCard provider={provider} />
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </main>
      </div>
      
      <Footer />
    </div>
  );
};

export default Favorites;
