
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Card } from '@/components/ui/card';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useLanguage } from '@/contexts/LanguageContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { useProviderReviews } from '@/hooks/useProviderReviews';
import { useProviderDetails } from '@/hooks/useProviderDetails';
import ReviewForm from '@/components/reviews/ReviewForm';
import ReviewsList from '@/components/reviews/ReviewsList';

const ProviderReviews = () => {
  const {
    id
  } = useParams<{
    id: string;
  }>();
  const navigate = useNavigate();
  const {
    t
  } = useLanguage();
  const isMobile = useIsMobile();
  const {
    provider,
    loading: providerLoading
  } = useProviderDetails(id);
  const {
    reviews,
    isLoading: reviewsLoading,
    refreshReviews
  } = useProviderReviews(id);

  const handleBackClick = () => {
    // Navigate back to the previous page (which should be the filtered results page)
    navigate(-1);
  };

  if (providerLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col items-center">
        <Header />
        <main className="container mx-auto max-w-[600px] px-4 py-6 pt-16 w-full flex-1">
          <div className="flex flex-col items-center justify-center py-8">
            <p className="text-center">{t('common.loading')}...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col items-center">
        <Header />
        <main className="container mx-auto max-w-[600px] px-4 py-6 pt-16 w-full flex-1">
          <div className="flex flex-col items-center justify-center py-8">
            <h1 className="text-2xl font-bold mb-4">{t('provider.notFound')}</h1>
            <Button onClick={handleBackClick} variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" /> {t('provider.backToHome')}
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col items-center">
      <Header />
      
      <main className="container mx-auto max-w-[600px] px-4 py-6 pt-16 w-full flex-1">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center my-[20px]">
            <Button variant="ghost" size="sm" onClick={handleBackClick} className="mr-2">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold">{t('review.title')}: {provider.name}</h1>
          </div>
        </div>
        
        <Card className="bg-white dark:bg-gray-800 p-4 mb-6" style={{boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'}}>
          <h2 className="text-xl font-semibold mb-3">{t('review.writeReview')}</h2>
          <ReviewForm providerId={id || ''} onReviewSubmitted={refreshReviews} />
        </Card>
        
        <div>
          <h2 className="text-xl font-semibold mb-3">
            {reviews.length} {t('review.reviews')}
          </h2>
          
          <ReviewsList reviews={reviews} isLoading={reviewsLoading} />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProviderReviews;
