
export interface ServiceProvider {
  id: string;
  name: string;
  service: string;
  service_type?: string;  // Add this field to match the database structure
  phone?: string;
  website?: string;
  profile_image_url?: string | null;  // Add this field
  socialMedia: {
    instagram?: string;
    facebook?: string;
    googleBusiness?: string;
    twitter?: string;
    phone?: string;
    sms?: string;
    website?: string;  // Explicitly add website to socialMedia
  };
  rating: number;
  location: {
    lat: number;
    lng: number;
    address: string;
    city: string;
    state: string;
    country?: string;
  };
  // New fields
  experience_years?: number;
  service_region?: string;
  about?: string;
}

export interface State {
  code: string;
  name: string;
}

export interface Country {
  code: string;
  name: string;
}

export interface City {
  code: string;
  name: string;
}

export interface ServiceType {
  id: string;
  name: string;
}
