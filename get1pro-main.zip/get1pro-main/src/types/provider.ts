
export interface ProviderProfile {
  id: string;
  user_id: string;
  name: string;
  service_type: string;
  description: string | null;
  address: string;
  city: string;
  state: string;
  country: string;
  phone: string;
  website?: string | null;
  profile_image_url?: string | null;
  facebook_url?: string | null;
  instagram_url?: string | null;
  linkedin_url?: string | null;
  twitter_url?: string | null;
  phone_contact?: string | null;
  sms_contact?: string | null;
  // New fields
  experience_years?: number | null;
  service_region?: string | null;
  about?: string | null;
  active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export type ProviderFormData = Omit<ProviderProfile, 'id' | 'user_id'>;
