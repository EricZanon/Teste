
import { ProviderProfile } from '@/types/provider';

export interface ProviderManagementState {
  providers: ProviderProfile[];
  loading: boolean;
  loadingAction: boolean;
  error: Error | null;
  
  // Dialog states
  providerToDelete: ProviderProfile | null;
  providerToToggleActive: ProviderProfile | null;
  isDeleteDialogOpen: boolean;
  isToggleActiveDialogOpen: boolean;
  
  // Sheet state
  editingProvider: string | null;
  isSheetOpen: boolean;
}

export interface ProviderManagementActions {
  fetchProviders: () => Promise<void>;
  handleCreateProvider: (newEmail: string) => Promise<void>;
  handleSetAdmin: (adminEmail: string) => Promise<void>;
  handleDeleteProvider: () => Promise<void>;
  handleToggleActiveStatus: () => Promise<void>;
  handleViewProfile: (id: string) => string;
  handleEditProfile: (id: string) => void;
  handleSheetClose: () => void;
  setProviderToDelete: (provider: ProviderProfile | null) => void;
  setProviderToToggleActive: (provider: ProviderProfile | null) => void;
  setIsDeleteDialogOpen: (open: boolean) => void;
  setIsToggleActiveDialogOpen: (open: boolean) => void;
}
