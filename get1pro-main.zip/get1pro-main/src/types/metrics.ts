
import { ReactNode } from 'react';

export interface MetricsData {
  name: string;
  value: number;
  icon?: ReactNode;
  color?: string;
  onClick?: () => void;
}

export type ProviderMetrics = {
  id: string;
  provider_id: string;
  provider_name?: string;
  shares: number;
  facebook_clicks: number;
  instagram_clicks: number;
  twitter_clicks: number;
  google_business_clicks: number;
  website_clicks: number;
  favorites_count: number;
  created_at: string;
  updated_at: string;
};
