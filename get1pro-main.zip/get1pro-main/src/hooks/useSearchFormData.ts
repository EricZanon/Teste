
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { serviceTypes } from '@/data/serviceTypes';

export interface ServiceType {
  id: string;
  name: string;
}

export interface State {
  code: string;
  name: string;
}

export function useSearchFormData(selectedState: string, selectedCity: string) {
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availableServices, setAvailableServices] = useState<ServiceType[]>([]);
  const [availableStates, setAvailableStates] = useState<State[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch available states (states with registered professionals)
  useEffect(() => {
    const fetchAvailableStates = async () => {
      try {
        setLoading(true);
        console.log('Fetching states with registered professionals');
        
        // Get states with providers and join with states table to get names
        const { data, error } = await supabase
          .from('providers')
          .select('state')
          .order('state');
        
        if (error) {
          console.error('Error fetching available states:', error);
          throw error;
        }
        
        if (data) {
          console.log('States data from providers:', data);
          
          // Get unique state codes
          const uniqueStateCodes = [...new Set(data.map(item => item.state).filter(Boolean))];
          console.log('Unique state codes:', uniqueStateCodes);
          
          if (uniqueStateCodes.length === 0) {
            console.log('No states found in providers, setting empty array');
            setAvailableStates([]);
            return;
          }
          
          // Now fetch state names from states table
          const { data: statesData, error: statesError } = await supabase
            .from('states')
            .select('code, name')
            .in('code', uniqueStateCodes);
          
          if (statesError) {
            console.error('Error fetching state names:', statesError);
            // Fallback: create states with code as name
            const fallbackStates = uniqueStateCodes.map(code => ({
              code,
              name: code
            }));
            console.log('Using fallback states:', fallbackStates);
            setAvailableStates(fallbackStates);
          } else {
            console.log('States with names from database:', statesData);
            
            // If no states found in database, use fallback
            if (!statesData || statesData.length === 0) {
              const fallbackStates = uniqueStateCodes.map(code => ({
                code,
                name: code
              }));
              console.log('No states in database, using fallback:', fallbackStates);
              setAvailableStates(fallbackStates);
            } else {
              // Merge database states with fallback for missing ones
              const dbStateCodes = statesData.map(s => s.code);
              const missingStates = uniqueStateCodes
                .filter(code => !dbStateCodes.includes(code))
                .map(code => ({ code, name: code }));
              
              const allStates = [...statesData, ...missingStates];
              console.log('Final merged states:', allStates);
              setAvailableStates(allStates);
            }
          }
        }
      } catch (err) {
        console.error('Error fetching available states:', err);
        setAvailableStates([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchAvailableStates();
  }, []);

  // Fetch cities when state changes
  useEffect(() => {
    if (selectedState) {
      setLoading(true);
      
      const fetchCities = async () => {
        try {
          console.log('Fetching cities for state:', selectedState);
          
          const { data, error } = await supabase
            .from('providers')
            .select('city')
            .eq('state', selectedState)
            .order('city');
          
          if (error) {
            console.error('Error fetching cities:', error);
            throw error;
          }
          
          if (data) {
            console.log('Cities data from Supabase:', data);
            
            // Extract unique cities
            const uniqueCities = [...new Set(data.map(item => item.city).filter(Boolean))];
            console.log('Unique cities:', uniqueCities);
            
            setAvailableCities(uniqueCities);
          }
        } catch (err) {
          console.error('Error fetching cities:', err);
          setAvailableCities([]);
        } finally {
          setLoading(false);
        }
      };
      
      fetchCities();
    } else {
      setAvailableCities([]);
    }
  }, [selectedState]);

  // Fetch services when city changes
  useEffect(() => {
    if (selectedCity && selectedState) {
      setLoading(true);
      
      const fetchServices = async () => {
        try {
          console.log('Fetching services for city:', selectedCity, 'and state:', selectedState);
          
          const { data, error } = await supabase
            .from('providers')
            .select('service_type')
            .eq('state', selectedState)
            .eq('city', selectedCity)
            .order('service_type');
          
          if (error) {
            console.error('Error fetching services:', error);
            throw error;
          }
          
          if (data) {
            console.log('Services data from Supabase:', data);
            
            // Extract unique service types
            const uniqueServiceTypes = [...new Set(data.map(item => item.service_type).filter(Boolean))];
            console.log('Unique service types:', uniqueServiceTypes);
            
            // Map service type IDs to their names using the serviceTypes data
            const servicesList = uniqueServiceTypes.map(typeId => {
              const serviceInfo = serviceTypes.find(s => s.id === typeId);
              return {
                id: typeId,
                name: serviceInfo ? serviceInfo.name : typeId // Fallback to ID if name not found
              };
            });
            
            console.log('Mapped services list:', servicesList);
            setAvailableServices(servicesList);
          }
        } catch (err) {
          console.error('Error fetching services:', err);
          setAvailableServices([]);
        } finally {
          setLoading(false);
        }
      };
      
      fetchServices();
    } else {
      setAvailableServices([]);
    }
  }, [selectedCity, selectedState]);

  return {
    availableStates,
    availableCities,
    availableServices,
    loading
  };
}
