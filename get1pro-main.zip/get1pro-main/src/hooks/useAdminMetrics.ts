
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ProviderMetrics } from '@/types/metrics';

interface AdminMetricsHookReturn {
  metrics: ProviderMetrics[];
  loading: boolean;
  error: Error | null;
  fetchMetrics: () => Promise<void>;
}

export function useAdminMetrics(): AdminMetricsHookReturn {
  const [metrics, setMetrics] = useState<ProviderMetrics[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  const fetchMetrics = async () => {
    try {
      setLoading(true);
      setError(null);

      // Try to fetch with a timeout to avoid hanging
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Timeout na consulta')), 10000); // 10 second timeout
      });

      const queryPromise = supabase
        .from('provider_metrics')
        .select(`
          *,
          providers(id, name)
        `);

      const { data, error } = await Promise.race([queryPromise, timeoutPromise]) as any;

      if (error) {
        throw new Error(error.message);
      }

      if (data) {
        // Process data to match the ProviderMetrics type
        const processedMetrics = data.map((item: any) => ({
          id: item.id,
          provider_id: item.provider_id,
          provider_name: item.providers?.name || 'Unknown Provider',
          shares: item.shares || 0,
          facebook_clicks: item.facebook_clicks || 0,
          instagram_clicks: item.instagram_clicks || 0,
          twitter_clicks: item.twitter_clicks || 0,
          google_business_clicks: item.linkedin_clicks || 0,
          website_clicks: 0,
          favorites_count: 0,
          created_at: item.created_at,
          updated_at: item.updated_at
        }));

        setMetrics(processedMetrics);
      } else {
        // Set empty metrics if no data
        setMetrics([]);
      }
    } catch (err) {
      console.error('Error fetching metrics:', err);
      setError(err as Error);
      
      // Set mock data as fallback to prevent UI crashes
      const mockMetrics: ProviderMetrics[] = [
        {
          id: 'mock-1',
          provider_id: 'mock-provider-1',
          provider_name: 'Provider 1',
          shares: 5,
          facebook_clicks: 10,
          instagram_clicks: 8,
          twitter_clicks: 3,
          google_business_clicks: 12,
          website_clicks: 15,
          favorites_count: 7,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 'mock-2',
          provider_id: 'mock-provider-2',
          provider_name: 'Provider 2',
          shares: 3,
          facebook_clicks: 6,
          instagram_clicks: 12,
          twitter_clicks: 2,
          google_business_clicks: 8,
          website_clicks: 10,
          favorites_count: 4,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ];
      
      setMetrics(mockMetrics);
      
      toast({
        variant: 'destructive',
        title: 'Erro ao carregar métricas',
        description: 'Usando dados de exemplo. Verifique sua conexão.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  return { metrics, loading, error, fetchMetrics };
}
