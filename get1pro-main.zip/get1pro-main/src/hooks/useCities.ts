
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface City {
  id: string;
  code: string;
  name: string;
  state_id: string;
}

export function useCities(stateCode?: string, countryCode?: string) {
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!stateCode || !countryCode) {
      console.log('useCities: Missing stateCode or countryCode:', { stateCode, countryCode });
      setCities([]);
      setLoading(false);
      return;
    }

    const fetchCities = async () => {
      try {
        setLoading(true);
        setError(null);
        
        console.log('useCities: Fetching cities for:', { stateCode, countryCode });
        
        const { data, error } = await supabase
          .from('cities')
          .select(`
            id,
            code,
            name,
            state_id,
            states!inner(
              code,
              countries!inner(code)
            )
          `)
          .eq('states.code', stateCode)
          .eq('states.countries.code', countryCode)
          .order('name');

        if (error) {
          console.error('useCities: Supabase error:', error);
          throw error;
        }
        
        console.log('useCities: Raw data received:', data?.length || 0, 'cities');
        
        // Transform the data to match our interface
        const transformedCities = (data || []).map(city => ({
          id: city.id,
          code: city.code,
          name: city.name,
          state_id: city.state_id
        }));
        
        console.log('useCities: Transformed cities:', transformedCities.length);
        console.log('useCities: First few cities:', transformedCities.slice(0, 3));
        
        setCities(transformedCities);
      } catch (err) {
        console.error('useCities: Error in fetchCities:', err);
        setError(err instanceof Error ? err.message : 'Unknown error');
        setCities([]);
      } finally {
        setLoading(false);
      }
    };

    fetchCities();
  }, [stateCode, countryCode]);

  return { cities, loading, error };
}
