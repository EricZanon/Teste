
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import { useToast } from '@/hooks/use-toast';

export function useAuthState() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, newSession) => {
        console.log('Auth state changed:', event);
        setSession(newSession);
        setUser(newSession?.user ?? null);
        
        // Show toast notifications for auth events
        if (event === 'SIGNED_IN') {
          toast({
            description: "Lodado com sucesso",
          });
        } else if (event === 'SIGNED_OUT') {
          toast({
            description: "Deslogado",
          });
        } else if (event === 'USER_UPDATED') {
          toast({
            description: "Informação Atualizada",
          });
        } else if (event === 'PASSWORD_RECOVERY') {
          toast({
            description: "Password recovery email sent",
          });
        }
      }
    );

    // Then check for existing session
    supabase.auth.getSession().then(({ data: { session: currentSession } }) => {
      setSession(currentSession);
      setUser(currentSession?.user ?? null);
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [toast]);

  return { user, session, loading };
}
