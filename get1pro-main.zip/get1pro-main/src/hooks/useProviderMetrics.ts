
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type ProviderMetrics = {
  id: string;
  provider_id: string;
  shares: number;
  facebook_clicks: number;
  instagram_clicks: number;
  twitter_clicks: number;
  google_business_clicks: number;
  created_at: string;
  updated_at: string;
};

export function useProviderMetrics(providerId?: string) {
  const [metrics, setMetrics] = useState<ProviderMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Buscar métricas atuais do provedor
  const fetchMetrics = async () => {
    if (!providerId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('provider_metrics')
        .select('*')
        .eq('provider_id', providerId)
        .single();

      if (error) {
        console.error('Erro ao buscar métricas:', error);
        return;
      }

      // Transform the data to handle linkedin_clicks to google_business_clicks mapping
      if (data) {
        const transformedData: ProviderMetrics = {
          id: data.id,
          provider_id: data.provider_id,
          shares: data.shares || 0,
          facebook_clicks: data.facebook_clicks || 0,
          instagram_clicks: data.instagram_clicks || 0,
          twitter_clicks: data.twitter_clicks || 0,
          google_business_clicks: data.linkedin_clicks || 0, // Map linkedin_clicks to google_business_clicks
          created_at: data.created_at,
          updated_at: data.updated_at
        };
        
        setMetrics(transformedData);
      }
    } catch (error) {
      console.error('Erro ao buscar métricas:', error);
    } finally {
      setLoading(false);
    }
  };

  // Incrementar uma métrica específica
  const incrementMetric = async (metric: 'shares' | 'facebook' | 'instagram' | 'twitter' | 'google_business') => {
    if (!providerId) return;

    try {
      // Se o metric for google_business, mapeie para linkedin na chamada à função RPC
      const dbMetric = metric === 'google_business' ? 'linkedin' : metric;
      
      // Chamar a função RPC do PostgreSQL para incrementar a métrica
      const { error } = await supabase
        .rpc('increment_provider_metric', {
          p_provider_id: providerId,
          p_metric: dbMetric
        });

      if (error) {
        console.error(`Erro ao incrementar métrica ${metric}:`, error);
        toast({
          variant: 'destructive',
          title: 'Erro',
          description: `Não foi possível atualizar a métrica ${metric}`
        });
        return;
      }

      // Atualizar o estado local sem precisar buscar novamente
      if (metrics) {
        const updatedMetrics = {...metrics};
        
        if (metric === 'shares') {
          updatedMetrics.shares += 1;
        } else if (metric === 'facebook') {
          updatedMetrics.facebook_clicks += 1;
        } else if (metric === 'instagram') {
          updatedMetrics.instagram_clicks += 1;
        } else if (metric === 'twitter') {
          updatedMetrics.twitter_clicks += 1;
        } else if (metric === 'google_business') {
          updatedMetrics.google_business_clicks += 1;
        }
        
        updatedMetrics.updated_at = new Date().toISOString();
        setMetrics(updatedMetrics);
      }

      // Opcional: Atualizar automaticamente para ter certeza de que os dados estão sincronizados
      fetchMetrics();
    } catch (error) {
      console.error(`Erro ao incrementar métrica ${metric}:`, error);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, [providerId]);

  return {
    metrics,
    loading,
    fetchMetrics,
    incrementMetric
  };
}
