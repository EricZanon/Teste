
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  created_at: string;
}

export const useProviderReviews = (providerId?: string) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();

  const fetchReviews = async () => {
    if (!providerId) return;
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('provider_id', providerId)
        .order('created_at', { ascending: false });
        
      if (error) {
        console.error('Error fetching reviews:', error);
        toast({
          title: t('review.error.title'),
          description: t('review.error.fetching'),
          variant: "destructive",
        });
        return;
      }
      
      setReviews(data || []);
    } catch (error) {
      console.error('Error in reviews fetch:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [providerId]);

  return {
    reviews,
    isLoading,
    refreshReviews: fetchReviews,
  };
};
