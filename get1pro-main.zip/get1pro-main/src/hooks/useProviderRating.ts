
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useProviderRating = (providerId?: string) => {
  const [rating, setRating] = useState<number>(0);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(false);

  const calculateRating = async () => {
    if (!providerId) {
      setRating(0);
      setReviewCount(0);
      return;
    }
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('rating')
        .eq('provider_id', providerId);
        
      if (error) {
        console.error('Error fetching reviews for rating:', error);
        setRating(0);
        setReviewCount(0);
        return;
      }
      
      if (data && data.length > 0) {
        const totalRating = data.reduce((sum, review) => sum + review.rating, 0);
        const averageRating = totalRating / data.length;
        setRating(averageRating);
        setReviewCount(data.length);
      } else {
        setRating(0);
        setReviewCount(0);
      }
    } catch (error) {
      console.error('Error calculating rating:', error);
      setRating(0);
      setReviewCount(0);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    calculateRating();
  }, [providerId]);

  return {
    rating,
    reviewCount,
    isLoading,
    refreshRating: calculateRating,
  };
};
