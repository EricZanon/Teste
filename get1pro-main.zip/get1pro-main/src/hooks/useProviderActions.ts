
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { providerManagementService } from '@/services/providerManagementService';
import { ProviderProfile } from '@/types/provider';

export function useProviderActions() {
  const { t } = useLanguage();
  const { toast } = useToast();

  const handleCreateProvider = async (newEmail: string, onSuccess: (userId: string) => void) => {
    try {
      console.log('Creating provider for email:', newEmail);
      const user = await providerManagementService.createUserAccount(newEmail);
      console.log('User created successfully with ID:', user.id);

      toast({
        title: 'Usuário criado',
        description: `Usuário com email ${newEmail} criado com sucesso. Um email de redefinição de senha foi enviado.`,
      });
      
      onSuccess(user.id);
    } catch (error: any) {
      console.error('Error in handleCreateProvider:', error);
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: error.message || 'Não foi possível criar o usuário.',
      });
      throw error;
    }
  };

  const handleSetAdmin = async (adminEmail: string) => {
    try {
      await providerManagementService.setUserAsAdmin(adminEmail);

      toast({
        title: 'Permissões atualizadas',
        description: `Você foi definido como administrador do sistema.`,
      });
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Erro',
        description: error.message || 'Não foi possível definir como administrador.',
      });
      throw error;
    }
  };

  const handleDeleteProvider = async (provider: ProviderProfile, onSuccess: () => void) => {
    try {
      await providerManagementService.deleteProvider(provider.id);

      toast({
        title: t('admin.provider_deleted') || 'Profissional excluído',
        description: `${provider.name} foi excluído do sistema.`
      });

      onSuccess();
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: t('common.error') || 'Erro',
        description: error.message || 'Não foi possível excluir o profissional.'
      });
      throw error;
    }
  };

  const handleToggleActiveStatus = async (provider: ProviderProfile, onSuccess: () => void) => {
    const newActiveStatus = !provider.active;
    
    try {
      await providerManagementService.toggleProviderActiveStatus(provider.id, newActiveStatus);

      const statusMessage = newActiveStatus 
        ? t('admin.provider_activated') || 'Profissional ativado' 
        : t('admin.provider_deactivated') || 'Profissional inativado';
        
      toast({
        title: statusMessage,
        description: `${provider.name} foi ${newActiveStatus ? 'ativado' : 'inativado'} no sistema.`
      });

      onSuccess();
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: t('common.error') || 'Erro',
        description: error.message || 'Não foi possível alterar o status do profissional.'
      });
      throw error;
    }
  };

  return {
    handleCreateProvider,
    handleSetAdmin,
    handleDeleteProvider,
    handleToggleActiveStatus,
  };
}
