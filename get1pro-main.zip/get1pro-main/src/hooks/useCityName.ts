
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useCityName = (cityCode: string, stateCode: string) => {
  const [cityName, setCityName] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchCityName = async () => {
      if (!cityCode || !stateCode) {
        setCityName('');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        
        // First try to find by city code
        const { data: cityData, error: cityError } = await supabase
          .from('cities')
          .select('name, states!inner(code)')
          .eq('code', cityCode)
          .eq('states.code', stateCode)
          .maybeSingle();

        if (cityError) {
          console.error('Error fetching city name:', cityError);
        }

        if (cityData) {
          setCityName(cityData.name);
        } else {
          // If not found by code, return the original cityCode as fallback
          setCityName(cityCode);
        }
      } catch (error) {
        console.error('Error in useCityName:', error);
        setCityName(cityCode);
      } finally {
        setLoading(false);
      }
    };

    fetchCityName();
  }, [cityCode, stateCode]);

  return { cityName, loading };
};
