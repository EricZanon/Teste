
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Subscriber {
  id: string;
  email: string;
  status: string;
  plan_name: string;
  current_period_end: string;
  created_at: string;
}

export const useSubscribers = () => {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchSubscribers = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select(`
          id,
          email,
          status,
          current_period_end,
          created_at,
          subscription_plans (
            name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const transformedData = (data || []).map(sub => ({
        id: sub.id,
        email: sub.email,
        status: sub.status,
        plan_name: (sub.subscription_plans as any)?.name || 'N/A',
        current_period_end: sub.current_period_end || '',
        created_at: sub.created_at
      }));

      setSubscribers(transformedData);

    } catch (error) {
      console.error('Error fetching subscribers:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar a lista de assinantes',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscribers();
  }, []);

  return {
    subscribers,
    loading,
    refetch: fetchSubscribers
  };
};
