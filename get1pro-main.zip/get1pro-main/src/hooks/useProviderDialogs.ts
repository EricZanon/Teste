
import { useState } from 'react';
import { ProviderProfile } from '@/types/provider';

export function useProviderDialogs() {
  const [providerToDelete, setProviderToDelete] = useState<ProviderProfile | null>(null);
  const [providerToToggleActive, setProviderToToggleActive] = useState<ProviderProfile | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isToggleActiveDialogOpen, setIsToggleActiveDialogOpen] = useState(false);
  
  const [editingProvider, setEditingProvider] = useState<string | null>(null);
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  return {
    providerToDelete,
    providerToToggleActive,
    isDeleteDialogOpen,
    isToggleActiveDialogOpen,
    editingProvider,
    isSheetOpen,
    setProviderToDelete,
    setProviderToToggleActive,
    setIsDeleteDialogOpen,
    setIsToggleActiveDialogOpen,
    setEditingProvider,
    setIsSheetOpen,
  };
}
