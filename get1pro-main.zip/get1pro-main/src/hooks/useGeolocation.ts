
import { useState, useEffect } from 'react';

interface GeolocationPosition {
  latitude: number;
  longitude: number;
  accuracy: number;
}

interface UseGeolocationReturn {
  position: GeolocationPosition | null;
  error: string | null;
  loading: boolean;
  getPosition: () => Promise<GeolocationPosition | null>;
}

export function useGeolocation(): UseGeolocationReturn {
  const [position, setPosition] = useState<GeolocationPosition | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const getPosition = (): Promise<GeolocationPosition | null> => {
    return new Promise((resolve) => {
      console.log('=== INICIANDO GEOLOCALIZAÇÃO ===');
      
      if (!navigator.geolocation) {
        const errorMsg = 'Geolocalização não é suportada pelo seu navegador';
        console.error('❌', errorMsg);
        setError(errorMsg);
        resolve(null);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const newPosition = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy,
            };
            console.log('✅ Geolocalização bem-sucedida:', newPosition);
            
            setPosition(newPosition);
            setError(null);
            setLoading(false);
            resolve(newPosition);
          },
          (error) => {
            let errorMessage;
            switch (error.code) {
              case error.PERMISSION_DENIED:
                errorMessage = 'Acesso à localização foi negado. Por favor, permita o acesso à localização nas configurações do navegador.';
                console.error('❌ PERMISSÃO NEGADA');
                break;
              case error.POSITION_UNAVAILABLE:
                errorMessage = 'Informações de localização não estão disponíveis.';
                console.error('❌ POSIÇÃO INDISPONÍVEL');
                break;
              case error.TIMEOUT:
                errorMessage = 'Tempo esgotado para obter localização.';
                console.error('❌ TIMEOUT');
                break;
              default:
                errorMessage = 'Erro desconhecido ao obter localização.';
                console.error('❌ ERRO DESCONHECIDO');
            }
            
            setError(errorMessage);
            setLoading(false);
            resolve(null);
          },
          {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 300000, // 5 minutos
          }
        );
      } catch (e) {
        const errorMsg = 'Exceção durante solicitação de geolocalização';
        console.error('❌ Exceção durante geolocalização:', e);
        setError(errorMsg);
        setLoading(false);
        resolve(null);
      }
    });
  };

  // Tentativa inicial de geolocalização
  useEffect(() => {
    const initGeolocation = async () => {
      try {
        console.log('🌍 Inicializando geolocalização...');
        await getPosition();
      } catch (e) {
        console.error('❌ Erro na geolocalização inicial:', e);
      }
    };
    
    initGeolocation();
  }, []);

  return { position, error, loading, getPosition };
}
