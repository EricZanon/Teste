
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface State {
  id: string;
  code: string;
  name: string;
  country_id: string;
}

export function useStates(countryCode?: string) {
  const [states, setStates] = useState<State[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!countryCode) {
      setStates([]);
      setLoading(false);
      return;
    }

    const fetchStates = async () => {
      try {
        setLoading(true);
        setError(null);
        
        console.log('useStates: Fetching states for country:', countryCode);
        
        const { data, error } = await supabase
          .from('states')
          .select(`
            id,
            code,
            name,
            country_id,
            countries!inner(code)
          `)
          .eq('countries.code', countryCode)
          .order('name');

        if (error) {
          console.error('useStates: Error fetching states:', error);
          throw error;
        }
        
        console.log('useStates: States fetched successfully:', data?.length || 0);
        setStates(data || []);
      } catch (err) {
        console.error('useStates: Error in fetchStates:', err);
        setError(err instanceof Error ? err.message : 'Unknown error');
        setStates([]);
      } finally {
        setLoading(false);
      }
    };

    fetchStates();
  }, [countryCode]);

  return { states, loading, error };
}
