
import { useCallback } from 'react';
import { incrementProviderMetric } from '@/services/metricsService';

type SocialPlatform = 'facebook' | 'instagram' | 'website' | 'phone' | 'sms' | 'googleBusiness';
type TrackablePlatform = 'facebook' | 'instagram' | 'google_business' | 'website' | 'shares';

export const useSocialMediaClick = (providerId: string) => {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  
  const handlePhoneCall = useCallback((phone: string) => {
    if (!phone) return;
    
    try {
      console.log('Phone call tracked for provider:', providerId);
      
      // Remove all non-digits for a clean phone number
      const formattedPhone = phone.replace(/\D/g, '');
      const phoneUrl = `tel:${formattedPhone}`;
      console.log('Opening phone URL:', phoneUrl);
      
      // iOS specific approach for handling phone calls
      if (isIOS) {
        // Use setTimeout to break iOS event chain
        setTimeout(() => {
          console.log('Executing phone call with delay for iOS');
          window.location.href = phoneUrl;
        }, 100);
      } else {
        window.location.href = phoneUrl;
      }
    } catch (error) {
      console.error('Error making phone call:', error);
    }
  }, [providerId, isIOS]);

  const handleSendSMS = useCallback((smsNumber: string, fallbackPhone: string) => {
    if (!smsNumber && !fallbackPhone) return;
    
    try {
      console.log('SMS tracked for provider:', providerId);
      
      // Use the SMS number or fallback to phone
      const phoneToUse = smsNumber || fallbackPhone;
      const formattedPhone = phoneToUse.replace(/\D/g, '');
      const smsUrl = `sms:${formattedPhone}`;
      console.log('Opening SMS URL:', smsUrl);
      
      // iOS specific approach for handling SMS
      if (isIOS) {
        // Use setTimeout to break iOS event chain
        setTimeout(() => {
          console.log('Executing SMS with delay for iOS');
          window.location.href = smsUrl;
        }, 100);
      } else {
        window.location.href = smsUrl;
      }
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  }, [providerId, isIOS]);
  
  const handleSocialClick = useCallback(async (platform: SocialPlatform, url?: string) => {
    if (!url) {
      console.log(`No URL provided for ${platform}`);
      return;
    }
    
    try {
      // Track metrics based on platform
      if (['facebook', 'instagram'].includes(platform)) {
        await incrementProviderMetric(providerId, platform as TrackablePlatform);
      } else if (platform === 'googleBusiness') {
        await incrementProviderMetric(providerId, 'google_business');
      } else if (platform === 'website') {
        await incrementProviderMetric(providerId, 'website');
      } else {
        console.log(`Click on ${platform} tracked locally for provider:`, providerId);
      }
    } catch (error) {
      console.error(`Error registering click on ${platform}:`, error);
    }
    
    // Handle special cases for phone and SMS
    if (platform === 'phone') {
      handlePhoneCall(url);
      return;
    }
    
    if (platform === 'sms') {
      handleSendSMS(url, '');
      return;
    }
    
    // Prepare and clean URL for social media and website links
    let finalUrl = url.trim();
    
    // Ensure URL has proper format for iOS and other platforms
    if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
      switch (platform) {
        case 'facebook':
          // Handle various facebook URL patterns
          if (finalUrl.includes('facebook.com')) {
            finalUrl = `https://${finalUrl}`;
          } else if (finalUrl.startsWith('www.facebook.com')) {
            finalUrl = `https://${finalUrl}`;
          } else {
            finalUrl = `https://facebook.com/${finalUrl}`;
          }
          break;
        case 'instagram':
          if (finalUrl.includes('instagram.com')) {
            finalUrl = `https://${finalUrl}`;
          } else if (finalUrl.startsWith('www.instagram.com')) {
            finalUrl = `https://${finalUrl}`;
          } else {
            finalUrl = `https://instagram.com/${finalUrl}`;
          }
          break;
        case 'googleBusiness':
          if (finalUrl.includes('maps.google.com') || finalUrl.includes('business.google.com')) {
            finalUrl = `https://${finalUrl}`;
          } else {
            finalUrl = `https://business.google.com/${finalUrl}`;
          }
          break;
        case 'website':
          // Enhanced website URL detection and formatting - critical for iOS
          if (finalUrl.startsWith('www.')) {
            finalUrl = `https://${finalUrl}`;
          } else if (finalUrl.includes('.') && !finalUrl.includes('http')) {
            // Has domain name but no protocol
            finalUrl = `https://${finalUrl}`;
          } else if (!finalUrl.includes('.')) {
            // No domain extension, might be incomplete
            finalUrl = `https://${finalUrl}.com`;
          } else {
            // Default fallback
            finalUrl = `https://${finalUrl}`;
          }
          break;
        default:
          break;
      }
    }
    
    console.log(`Opening ${platform} URL: ${finalUrl}`);
    
    // iOS optimized URL opening with increased delay
    try {
      if (isIOS) {
        console.log(`Using iOS-specific URL opening for ${platform}`);
        // Break the iOS event chain with increased delay for more reliability
        setTimeout(() => {
          console.log(`Executing delayed URL navigation for ${platform} on iOS`);
          window.location.href = finalUrl;
        }, 150); // Increased delay for better iOS compatibility
      } else {
        // For non-iOS, opening in new tab is fine
        window.open(finalUrl, '_blank', 'noopener,noreferrer');
      }
    } catch (error) {
      console.error('Error opening URL, falling back to direct navigation:', error);
      window.location.href = finalUrl;
    }
  }, [providerId, isIOS, handlePhoneCall, handleSendSMS]);

  return {
    handlePhoneCall,
    handleSendSMS,
    handleSocialClick
  };
};
