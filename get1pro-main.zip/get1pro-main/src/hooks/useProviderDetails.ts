
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useProviders } from './useProviders';
import { ServiceProvider } from '@/types';

export const useProviderDetails = (providerId?: string) => {
  const [provider, setProvider] = useState<Partial<ServiceProvider> | null>(null);
  const [loading, setLoading] = useState(true);
  const { providers } = useProviders();
  
  const calculateProviderRating = async (providerId: string): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('rating')
        .eq('provider_id', providerId);
        
      if (error) {
        console.error('Error fetching reviews for rating:', error);
        return 0;
      }
      
      if (data && data.length > 0) {
        const totalRating = data.reduce((sum, review) => sum + review.rating, 0);
        return totalRating / data.length;
      }
      
      return 0;
    } catch (error) {
      console.error('Error calculating rating:', error);
      return 0;
    }
  };
  
  useEffect(() => {
    const fetchProviderDetails = async () => {
      if (!providerId) {
        setLoading(false);
        return;
      }
      
      // First check if the provider is in the providers list
      if (providers.length > 0) {
        const foundProvider = providers.find(p => p.id === providerId);
        if (foundProvider) {
          console.log('Provider found in providers list with rating:', foundProvider.rating);
          console.log('Provider found with avatar URL:', foundProvider.profile_image_url);
          setProvider(foundProvider);
          setLoading(false);
          return;
        }
      }
      
      // If not found in the list or list is empty, fetch directly
      try {
        const { data, error } = await supabase
          .from('providers')
          .select('*')
          .eq('id', providerId)
          .single();
          
        if (error) {
          console.error('Error fetching provider:', error);
          setLoading(false);
          return;
        }
        
        if (data) {
          console.log('Provider fetched directly:', data);
          console.log('Provider avatar URL from DB:', data.profile_image_url);
          
          // Calculate real rating based on reviews
          const realRating = await calculateProviderRating(data.id);
          
          // Create a safe way to access the social media properties
          const socialUrls = {
            instagram: data.instagram_url || '',
            facebook: data.facebook_url || '',
            googleBusiness: data.linkedin_url || '',
            phone: data.phone_contact || data.phone || '',
            sms: data.sms_contact || data.phone || '',
            website: data.website || '',
          };
          
          const providerData: Partial<ServiceProvider> = {
            id: data.id,
            name: data.name,
            service: data.service_type,
            phone: data.phone || '',
            rating: realRating,
            website: data.website || '',
            profile_image_url: data.profile_image_url,
            location: {
              address: data.address || '',
              city: data.city || '',
              state: data.state || '',
              lat: 0,
              lng: 0,
            },
            socialMedia: socialUrls,
            experience_years: data.experience_years,
            service_region: data.service_region,
            about: data.about,
          };
          
          console.log('Transformed provider data with avatar:', providerData.profile_image_url);
          setProvider(providerData);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error in provider fetch:', error);
        setLoading(false);
      }
    };
    
    fetchProviderDetails();
  }, [providerId, providers]);
  
  return { provider, loading };
};
