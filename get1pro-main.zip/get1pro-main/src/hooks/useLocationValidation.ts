
import { useEffect, useState } from 'react';

interface LocationValidationProps {
  country: string;
  state: string;
  city: string;
  availableStates: Array<{code: string; name: string}>;
  availableCities: Array<{code: string; name: string}>;
  onStateChange: (value: string) => void;
  onCityChange: (value: string) => void;
}

export function useLocationValidation({
  country,
  state,
  city,
  availableStates,
  availableCities,
  onStateChange,
  onCityChange
}: LocationValidationProps) {
  const [isValidating, setIsValidating] = useState(false);

  // Only clear state when country changes and state becomes invalid
  useEffect(() => {
    if (isValidating) return;
    
    setIsValidating(true);
    
    const validateState = () => {
      console.log('useLocationValidation: Validating state:', { 
        state, 
        availableStatesCount: availableStates.length,
        country 
      });
      
      // Only validate if we have loaded states and current state is set
      if (state && availableStates.length > 0) {
        const stateExists = availableStates.some(s => s.code === state);
        
        if (!stateExists) {
          console.log('useLocationValidation: State not found in available states, clearing:', state);
          onStateChange('');
          onCityChange(''); // Also clear city when state is invalid
        }
      }
      
      setIsValidating(false);
    };

    // Only validate after states are loaded and with a small delay
    if (availableStates.length > 0) {
      const timer = setTimeout(validateState, 300);
      return () => clearTimeout(timer);
    } else {
      setIsValidating(false);
    }
  }, [country, state, availableStates, onStateChange, onCityChange, isValidating]);

  // Only clear city when state changes and city becomes invalid
  useEffect(() => {
    if (isValidating) return;
    
    setIsValidating(true);
    
    const validateCity = () => {
      console.log('useLocationValidation: Validating city:', { 
        city, 
        availableCitiesCount: availableCities.length,
        state 
      });
      
      // Only validate if we have loaded cities and current city is set
      if (city && availableCities.length > 0) {
        const cityExists = availableCities.some(c => c.code === city);
        
        if (!cityExists) {
          console.log('useLocationValidation: City not found in available cities, clearing:', city);
          onCityChange('');
        }
      }
      
      setIsValidating(false);
    };

    // Only validate after cities are loaded and with a small delay
    if (availableCities.length > 0) {
      const timer = setTimeout(validateCity, 300);
      return () => clearTimeout(timer);
    } else {
      setIsValidating(false);
    }
  }, [state, city, availableCities, onCityChange, isValidating]);

  return { isValidating };
}
