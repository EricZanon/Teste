import { useState } from 'react';

export function useLocationSearch() {
  const [isLocating, setIsLocating] = useState<boolean>(false);

  // Keep the functions for backward compatibility but make them do nothing
  const detectUserLocation = async (
    availableStates: any[],
    availableCities: string[],
    onStateChange: (state: string) => void,
    onCityChange: (city: string) => void
  ) => {
    console.log('Location detection disabled');
  };

  const searchByUserLocation = async (
    availableStates: any[],
    availableCities: string[],
    onStateChange: (state: string) => void,
    onCityChange: (city: string) => void,
    onSearch: (state: string, city: string, service: string) => void
  ) => {
    console.log('Location search disabled');
  };

  return {
    detectUserLocation,
    searchByUserLocation,
    isLocating: false
  };
}
