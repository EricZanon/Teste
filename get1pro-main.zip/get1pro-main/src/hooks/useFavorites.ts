
import { useState, useEffect, useCallback } from 'react';
import { ServiceProvider } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { incrementProviderMetric } from '@/services/metricsService';

interface FavoriteProvider {
  id: string;
  website?: string;
  socialMedia?: {
    instagram?: string;
    facebook?: string;
    googleBusiness?: string;
    sms?: string;
    phone?: string;
    website?: string;
  };
}

export const useFavorites = () => {
  const [favorites, setFavorites] = useState<FavoriteProvider[]>([]);
  const [favoriteProviders, setFavoriteProviders] = useState<ServiceProvider[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState<number>(Date.now());

  const toggleFavorite = useCallback(async (provider: ServiceProvider) => {
    console.log('Toggling favorite for provider:', provider.id);
    
    const existingIndex = favorites.findIndex(f => f.id === provider.id);
    let newFavorites: FavoriteProvider[];
    
    if (existingIndex >= 0) {
      console.log('Removing provider from favorites');
      newFavorites = favorites.filter(f => f.id !== provider.id);
    } else {
      console.log('Adding provider to favorites');
      
      const socialMediaToSave = {
        instagram: provider.socialMedia?.instagram || '',
        facebook: provider.socialMedia?.facebook || '',
        googleBusiness: provider.socialMedia?.googleBusiness || '',
        sms: provider.socialMedia?.sms || provider.phone || '',
        phone: provider.socialMedia?.phone || provider.phone || '',
        website: provider.socialMedia?.website || provider.website || '',
      };
      
      newFavorites = [...favorites, {
        id: provider.id,
        website: provider.website || provider.socialMedia?.website || '',
        socialMedia: socialMediaToSave
      }];
      
      // Track favorite action in metrics
      try {
        await incrementProviderMetric(provider.id, 'favorites');
      } catch (error) {
        console.error('Error incrementing favorites metric:', error);
      }
    }
    
    setFavorites([...newFavorites]);
    setLastUpdateTime(Date.now());
    
    try {
      localStorage.setItem('favorites', JSON.stringify(newFavorites));
      console.log('Favorites saved to localStorage:', newFavorites.length);
    } catch (error) {
      console.error('Error saving favorites to localStorage:', error);
    }
  }, [favorites]);

  // Load favorites from localStorage on initial render
  useEffect(() => {
    try {
      const storedFavorites = localStorage.getItem('favorites');
      if (storedFavorites) {
        console.log('Loading stored favorites from localStorage');
        const parsedFavorites = JSON.parse(storedFavorites);
        setFavorites(parsedFavorites);
      }
    } catch (error) {
      console.error('Error loading favorites from localStorage:', error);
      setFavorites([]);
    }
  }, []);

  // Fetch favorite providers from the database when favorites list changes
  useEffect(() => {
    const fetchFavoriteProviders = async () => {
      if (favorites.length === 0) {
        setFavoriteProviders([]);
        return;
      }

      setLoading(true);
      try {
        const favoriteIds = favorites.map(fav => fav.id).filter(id => id && id.trim() !== '');
        
        if (favoriteIds.length === 0) {
          setFavoriteProviders([]);
          setLoading(false);
          return;
        }
        
        console.log('Fetching favorite providers with IDs:', favoriteIds);
        
        const { data, error } = await supabase
          .from('providers')
          .select('*')
          .in('id', favoriteIds);
          
        if (error) {
          console.error('Error fetching favorite providers:', error);
          return;
        }
        
        if (data) {
          console.log('Received provider data from Supabase:', data.length);
          
          const transformedProviders: ServiceProvider[] = data.map(provider => {
            const favorite = favorites.find(f => f.id === provider.id);
            
            const socialMedia = {
              instagram: favorite?.socialMedia?.instagram || provider.instagram_url || '',
              facebook: favorite?.socialMedia?.facebook || provider.facebook_url || '',
              googleBusiness: favorite?.socialMedia?.googleBusiness || provider.linkedin_url || '',
              phone: favorite?.socialMedia?.phone || provider.phone_contact || provider.phone || '',
              sms: favorite?.socialMedia?.sms || provider.sms_contact || provider.phone || '',
              website: favorite?.socialMedia?.website || favorite?.website || provider.website || '',
            };
            
            return {
              id: provider.id,
              name: provider.name,
              service: provider.service_type,
              service_type: provider.service_type,
              phone: provider.phone || favorite?.socialMedia?.phone || 'N/A',
              website: favorite?.socialMedia?.website || favorite?.website || provider.website || '',
              socialMedia: socialMedia,
              rating: 4.5,
              location: {
                lat: 0,
                lng: 0,
                address: provider.address || 'Endereço não disponível',
                city: provider.city || 'Cidade não disponível',
                state: provider.state || 'UF',
              },
            };
          });
          
          console.log('Transformed favorite providers:', transformedProviders.length);
          setFavoriteProviders(transformedProviders);
        }
      } catch (err) {
        console.error('Error in fetchFavoriteProviders:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchFavoriteProviders();
    setLastUpdateTime(Date.now());
  }, [favorites]);

  const isFavorite = useCallback((providerId: string) => 
    favorites.some(f => f.id === providerId), 
  [favorites]);

  return { favorites, favoriteProviders, toggleFavorite, isFavorite, loading, lastUpdateTime };
};
