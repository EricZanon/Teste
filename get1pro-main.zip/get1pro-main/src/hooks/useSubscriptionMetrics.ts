
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SubscriptionMetrics {
  totalSubscribers: number;
  monthlyRevenue: number;
  newSubscribersThisMonth: number;
  conversionRate: number;
  planBreakdown: Array<{
    planName: string;
    count: number;
    revenue: number;
  }>;
}

export const useSubscriptionMetrics = () => {
  const [metrics, setMetrics] = useState<SubscriptionMetrics>({
    totalSubscribers: 0,
    monthlyRevenue: 0,
    newSubscribersThisMonth: 0,
    conversionRate: 0,
    planBreakdown: []
  });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchMetrics = async () => {
    try {
      setLoading(true);
      
      // Get total active subscribers
      const { data: activeSubscribers, error: subsError } = await supabase
        .from('user_subscriptions')
        .select('*, subscription_plans(*)')
        .eq('status', 'active');

      if (subsError) throw subsError;

      // Calculate metrics
      const totalSubscribers = activeSubscribers?.length || 0;
      
      let monthlyRevenue = 0;
      const planBreakdown: { [key: string]: { count: number; revenue: number } } = {};

      activeSubscribers?.forEach(sub => {
        if (sub.subscription_plans) {
          const plan = sub.subscription_plans as any;
          const planPrice = plan.price || 0;
          
          // Convert to monthly revenue
          const monthlyPrice = plan.billing_period === 'year' ? planPrice / 12 : planPrice;
          monthlyRevenue += monthlyPrice;
          
          if (!planBreakdown[plan.name]) {
            planBreakdown[plan.name] = { count: 0, revenue: 0 };
          }
          planBreakdown[plan.name].count++;
          planBreakdown[plan.name].revenue += monthlyPrice;
        }
      });

      // Get new subscribers this month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: newSubs, error: newSubsError } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('status', 'active')
        .gte('created_at', startOfMonth.toISOString());

      if (newSubsError) throw newSubsError;

      const newSubscribersThisMonth = newSubs?.length || 0;

      // Mock conversion rate for now (you can implement proper tracking later)
      const conversionRate = totalSubscribers > 0 ? Math.round((newSubscribersThisMonth / Math.max(totalSubscribers, 1)) * 100) : 0;

      setMetrics({
        totalSubscribers,
        monthlyRevenue: Math.round(monthlyRevenue * 100) / 100,
        newSubscribersThisMonth,
        conversionRate,
        planBreakdown: Object.entries(planBreakdown).map(([planName, data]) => ({
          planName,
          count: data.count,
          revenue: Math.round(data.revenue * 100) / 100
        }))
      });

    } catch (error) {
      console.error('Error fetching subscription metrics:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar as métricas de assinatura',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  return {
    metrics,
    loading,
    refetch: fetchMetrics
  };
};
