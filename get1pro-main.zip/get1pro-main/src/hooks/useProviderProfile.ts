
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ProviderProfile } from '@/types/provider';
import { useToast } from '@/hooks/use-toast';
import { fetchProviderProfile, saveProviderProfile } from '@/services/providerService';
import { saveProviderProfileAsAdmin } from '@/services/adminProviderService';
import { DEFAULT_PROVIDER_PROFILE } from '@/constants/providerDefaults';

export function useProviderProfile(providerId?: string) {
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [fetchingProfile, setFetchingProfile] = useState(true);
  const [profile, setProfile] = useState<Partial<ProviderProfile>>({
    ...DEFAULT_PROVIDER_PROFILE,
    country: 'BR'
  });

  const isAdminEdit = isAdmin && providerId && providerId !== user?.id;

  useEffect(() => {
    const getProfile = async () => {
      if (!user?.id && !providerId) {
        console.log('⚠️ useProviderProfile: No user ID available');
        setFetchingProfile(false);
        return;
      }

      setFetchingProfile(true);
      try {
        const targetId = providerId || user?.id;
        console.log('🔍 useProviderProfile: Fetching profile for ID:', targetId);
        
        if (targetId) {
          const data = await fetchProviderProfile(providerId, user?.id);
          if (data) {
            console.log('✅ useProviderProfile: Profile fetched:', data);
            setProfile({
              ...data,
              country: data.country || 'BR'
            });
          } else {
            console.log('ℹ️ useProviderProfile: No profile found, using defaults');
            setProfile({
              ...DEFAULT_PROVIDER_PROFILE,
              country: 'BR'
            });
          }
        }
      } catch (error: any) {
        console.error('💥 useProviderProfile: Error fetching profile:', error);
        setProfile({
          ...DEFAULT_PROVIDER_PROFILE,
          country: 'BR'
        });
        
        // Only show toast for unexpected errors, not network issues
        if (!error.message?.includes('Failed to fetch') && 
            !error.message?.includes('Problema de conexão')) {
          toast({
            title: 'Erro ao Carregar Perfil',
            description: error.message || 'Não foi possível carregar os dados do perfil.',
            variant: 'destructive',
            duration: 5000,
          });
        }
      } finally {
        setFetchingProfile(false);
      }
    };
    
    getProfile();
  }, [user, providerId, isAdminEdit, toast]);

  const updateProfile = (updates: Partial<ProviderProfile>) => {
    console.log('🔄 useProviderProfile: Updating local profile with:', updates);
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const handleImageUpdate = (imageUrl: string) => {
    console.log('🖼️ useProviderProfile: Image update received:', imageUrl);
    updateProfile({ profile_image_url: imageUrl });
  };

  // Retry function for save operations
  const retrySave = async (saveFunction: () => Promise<any>, maxRetries = 2) => {
    let lastError;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`🔄 Save attempt ${attempt}/${maxRetries}`);
        return await saveFunction();
      } catch (error: any) {
        lastError = error;
        console.warn(`⚠️ Save attempt ${attempt} failed:`, error.message);
        
        // Don't retry on validation errors or auth issues
        if (error.message?.includes('obrigatórios') || 
            error.message?.includes('Sessão expirada') ||
            error.message?.includes('Unauthorized')) {
          throw error;
        }
        
        // Wait before retrying
        if (attempt < maxRetries) {
          const delay = 2000; // 2 seconds
          console.log(`⏳ Waiting ${delay}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    
    throw lastError;
  };

  const handleSaveProfile = async (profileDataToSave: Partial<ProviderProfile>) => {
    const targetUserId = providerId || user?.id;
    
    if (!targetUserId) {
      console.error('❌ useProviderProfile: No target user ID available');
      toast({
        title: 'Erro de Autenticação',
        description: 'Usuário não identificado. Faça login novamente.',
        variant: 'destructive',
      });
      throw new Error('No target user ID available');
    }
    
    console.log('💾 useProviderProfile: Starting save with data:', profileDataToSave);
    console.log('🎯 useProviderProfile: Target user ID:', targetUserId);
    
    setLoading(true);
    
    try {
      let savedProfile;
      
      // Use retry logic for save operations
      savedProfile = await retrySave(async () => {
        if (isAdminEdit) {
          console.log('👑 useProviderProfile: Using admin save service');
          return await saveProviderProfileAsAdmin(profileDataToSave);
        } else {
          console.log('👤 useProviderProfile: Using regular save service');
          return await saveProviderProfile(profileDataToSave, targetUserId);
        }
      });
      
      console.log('✅ useProviderProfile: Profile saved successfully:', savedProfile);
      
      // Update local state with saved data
      setProfile(savedProfile);
      
      toast({
        title: 'Sucesso!',
        description: 'Perfil salvo com sucesso!',
        duration: 3000,
      });
      
      return savedProfile;
    } catch (error: any) {
      console.error('💥 useProviderProfile: Error saving profile:', error);
      
      let errorMessage = error.message || 'Erro ao salvar perfil. Tente novamente.';
      
      // Handle specific network errors
      if (error.message?.includes('Failed to fetch') || !navigator.onLine) {
        errorMessage = 'Problema de conexão. Verifique sua internet e tente novamente.';
      } else if (error.message?.includes('rate limit')) {
        errorMessage = 'Muitas tentativas. Aguarde alguns minutos e tente novamente.';
      }
      
      toast({
        title: 'Erro ao Salvar',
        description: errorMessage,
        variant: 'destructive',
        duration: 5000,
      });
      
      throw error;
    } finally {
      setLoading(false);
    }
  };
  
  return { 
    profile, 
    loading, 
    fetchingProfile, 
    updateProfile,
    handleImageUpdate,
    saveProfile: handleSaveProfile,
    isAdminEdit
  };
}
