
import { useState, useEffect } from 'react';
import { ServiceProvider } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { serviceTypes } from '@/data/serviceTypes';

export const useProviderDetailPage = (providerId?: string) => {
  const [provider, setProvider] = useState<ServiceProvider | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  
  const calculateProviderRating = async (providerId: string): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('rating')
        .eq('provider_id', providerId);
        
      if (error) {
        console.error('Error fetching reviews for rating:', error);
        return 0;
      }
      
      if (data && data.length > 0) {
        const totalRating = data.reduce((sum, review) => sum + review.rating, 0);
        return totalRating / data.length;
      }
      
      return 0;
    } catch (error) {
      console.error('Error calculating rating:', error);
      return 0;
    }
  };
  
  useEffect(() => {
    const fetchProviderDetails = async () => {
      if (!providerId) {
        setLoading(false);
        return;
      }
      
      try {
        setLoading(true);
        
        const { data, error } = await supabase
          .from('providers')
          .select('*')
          .eq('id', providerId)
          .maybeSingle();
          
        if (error) {
          console.error('Error fetching provider:', error);
          setProvider(null);
          return;
        }
        
        if (data) {
          const serviceType = serviceTypes.find(st => st.id === data.service_type);
          const serviceName = serviceType ? serviceType.name : data.service_type;
          const realRating = await calculateProviderRating(data.id);

          const transformedProvider: ServiceProvider = {
            id: data.id,
            name: data.name,
            service: serviceName,
            phone: data.phone,
            website: data.website || '',
            profile_image_url: data.profile_image_url,
            socialMedia: {
              instagram: data.instagram_url || '',
              facebook: data.facebook_url || '',
              googleBusiness: data.linkedin_url || '',
              phone: data.phone_contact || '',
              sms: data.sms_contact || '',
              website: data.website || ''
            },
            rating: realRating,
            location: {
              lat: 0,
              lng: 0,
              address: data.address,
              city: data.city,
              state: data.state
            },
            experience_years: data.experience_years || undefined,
            service_region: data.service_region || undefined,
            about: data.about || undefined
          };
          
          setProvider(transformedProvider);
        } else {
          console.log('No provider found with ID:', providerId);
          setProvider(null);
        }
      } catch (error) {
        console.error('Error fetching provider details:', error);
        setProvider(null);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProviderDetails();
  }, [providerId]);

  return { provider, loading };
};
