
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ServiceProvider } from '@/types';
import { serviceTypes } from '@/data/serviceTypes';

export const useProviders = () => {
  const [providers, setProviders] = useState<ServiceProvider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const calculateProviderRating = async (providerId: string): Promise<number> => {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('rating')
        .eq('provider_id', providerId);
        
      if (error) {
        console.error('Error fetching reviews for rating:', error);
        return 0;
      }
      
      if (data && data.length > 0) {
        const totalRating = data.reduce((sum, review) => sum + review.rating, 0);
        return totalRating / data.length;
      }
      
      return 0;
    } catch (error) {
      console.error('Error calculating rating:', error);
      return 0;
    }
  };

  const fetchProviders = async () => {
    try {
      setLoading(true);
      console.log("=== BUSCANDO PROVIDERS ===");
      
      const { data, error } = await supabase
        .from('providers')
        .select('*')
        .eq('active', true);
        
      if (error) {
        throw error;
      }
      
      if (data) {
        console.log('🔍 Buscados', data.length, 'providers do banco de dados');
        
        const transformedProviders: ServiceProvider[] = await Promise.all(
          data.map(async (provider) => {
            const serviceType = serviceTypes.find(st => st.id === provider.service_type);
            const serviceName = serviceType ? serviceType.name : provider.service_type;
            const realRating = await calculateProviderRating(provider.id);

            console.log(`Processing provider ${provider.name}: profile_image_url = ${provider.profile_image_url}`);

            const transformedProvider: ServiceProvider = {
              id: provider.id,
              name: provider.name,
              service: serviceName,
              service_type: provider.service_type,
              phone: provider.phone || 'N/A',
              website: provider.website || '',
              profile_image_url: provider.profile_image_url || null,
              socialMedia: {
                instagram: provider.instagram_url || '',
                facebook: provider.facebook_url || '',
                googleBusiness: provider.linkedin_url || '',
                twitter: provider.twitter_url || '',
                phone: provider.phone_contact || provider.phone || '',
                sms: provider.sms_contact || provider.phone || '',
                website: provider.website || '',
              },
              rating: realRating,
              location: {
                lat: 0,
                lng: 0,
                address: provider.address || 'Endereço não disponível',
                city: provider.city || 'Cidade não disponível',
                state: provider.state || 'UF',
              },
              experience_years: provider.experience_years || undefined,
              service_region: provider.service_region || undefined,
              about: provider.about || undefined
            };

            console.log(`Transformed provider ${provider.name}: profile_image_url = ${transformedProvider.profile_image_url}`);
            return transformedProvider;
          })
        );
        
        console.log('🔄 Providers transformados:', transformedProviders.length);
        setProviders(transformedProviders);
      }
    } catch (err: any) {
      console.error('❌ Erro buscando providers:', err);
      setError(err.message || 'Failed to fetch providers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProviders();
  }, []);

  return { providers, loading, error, refetch: fetchProviders };
};
