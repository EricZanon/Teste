
import { useEffect, useRef } from 'react';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';
import { useToast } from '@/hooks/use-toast';

export const useSubscriptionCheck = () => {
  const { subscription, checkSubscription, hasActiveSubscription, loading } = useSubscriptionContext();
  const { toast } = useToast();
  const hasShownSuccessToast = useRef(false);
  const lastCheckTime = useRef<number>(0);

  // Throttle subscription checks to prevent too many requests
  const throttledCheckSubscription = async () => {
    const now = Date.now();
    if (now - lastCheckTime.current < 5000) { // 5 second throttle
      console.log('⏱️ Subscription check throttled');
      return;
    }
    lastCheckTime.current = now;
    
    try {
      await checkSubscription();
    } catch (error) {
      console.error('❌ Error in subscription check:', error);
      toast({
        title: 'Erro ao verificar assinatura',
        description: 'Não foi possível verificar o status da assinatura. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  // Check subscription when component mounts or when returning to the page
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        console.log('🔄 Page became visible, checking subscription');
        throttledCheckSubscription();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Check subscription when hook is first used (only once)
    console.log('🚀 Initial subscription check');
    throttledCheckSubscription();

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []); // Empty dependency array to run only once

  // Show success message when subscription becomes active (but only once)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const planName = urlParams.get('plan');

    if (success === 'true' && planName && !hasShownSuccessToast.current) {
      hasShownSuccessToast.current = true;
      toast({
        title: 'Assinatura realizada com sucesso!',
        description: `Bem-vindo ao plano ${planName}. Sua assinatura está ativa.`,
      });
      
      // Clean up URL parameters
      window.history.replaceState({}, '', window.location.pathname);
      
      // Force subscription check after success
      setTimeout(() => {
        console.log('✅ Success callback - checking subscription');
        throttledCheckSubscription();
      }, 2000);
    }
  }, [toast]); // Remove checkSubscription from dependencies to prevent loops

  return {
    subscription,
    hasActiveSubscription,
    checkSubscription: throttledCheckSubscription,
    loading
  };
};
