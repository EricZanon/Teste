
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { ProviderProfile } from '@/types/provider';
import { providerManagementService } from '@/services/providerManagementService';
import { useProviderDialogs } from './useProviderDialogs';
import { useProviderActions } from './useProviderActions';

export function useProviderManagement() {
  const { toast } = useToast();
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingAction, setLoadingAction] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  const dialogs = useProviderDialogs();
  const actions = useProviderActions();

  const fetchProviders = async () => {
    try {
      setLoading(true);
      setError(null);

      const data = await providerManagementService.fetchProviders();
      setProviders(data);
    } catch (err) {
      console.error('Error fetching providers:', err);
      setError(err as Error);
      
      toast({
        variant: 'destructive',
        title: 'Erro ao carregar profissionais',
        description: 'Verifique sua conexão.'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProvider = async (newEmail: string) => {
    setLoadingAction(true);
    try {
      await actions.handleCreateProvider(newEmail, (userId) => {
        dialogs.setEditingProvider(userId);
        dialogs.setIsSheetOpen(true);
      });
    } finally {
      setLoadingAction(false);
    }
  };

  const handleSetAdmin = async (adminEmail: string) => {
    setLoadingAction(true);
    try {
      await actions.handleSetAdmin(adminEmail);
    } finally {
      setLoadingAction(false);
    }
  };

  const handleDeleteProvider = async () => {
    if (!dialogs.providerToDelete) return;
    
    setLoadingAction(true);
    try {
      await actions.handleDeleteProvider(dialogs.providerToDelete, fetchProviders);
    } finally {
      setLoadingAction(false);
      dialogs.setIsDeleteDialogOpen(false);
      dialogs.setProviderToDelete(null);
    }
  };

  const handleToggleActiveStatus = async () => {
    if (!dialogs.providerToToggleActive) return;
    
    setLoadingAction(true);
    try {
      await actions.handleToggleActiveStatus(dialogs.providerToToggleActive, fetchProviders);
    } finally {
      setLoadingAction(false);
      dialogs.setIsToggleActiveDialogOpen(false);
      dialogs.setProviderToToggleActive(null);
    }
  };

  const handleEditProfile = (id: string) => {
    dialogs.setEditingProvider(id);
    dialogs.setIsSheetOpen(true);
  };

  const handleSheetClose = () => {
    dialogs.setIsSheetOpen(false);
    dialogs.setEditingProvider(null);
    fetchProviders();
  };

  return {
    providers,
    loading,
    loadingAction,
    error,
    ...dialogs,
    fetchProviders,
    handleCreateProvider,
    handleSetAdmin,
    handleDeleteProvider,
    handleToggleActiveStatus,
    handleEditProfile,
    handleSheetClose,
  };
}
