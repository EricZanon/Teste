
import React from 'react';
import { Star } from 'lucide-react';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { useLanguage } from '@/contexts/LanguageContext';

interface RatingFilterProps {
  minRating: number;
  setMinRating: (rating: number) => void;
}

const RatingFilter: React.FC<RatingFilterProps> = ({ minRating, setMinRating }) => {
  const { t } = useLanguage();
  
  return (
    <div className="flex flex-wrap items-center gap-2">
      <ToggleGroup 
        type="single"
        value={minRating.toString()}
        onValueChange={(value) => setMinRating(value ? parseInt(value) : 0)}
        className="flex-wrap"
      >
        {[1, 2, 3, 4, 5].map((rating) => (
          <ToggleGroupItem 
            key={rating} 
            value={rating.toString()}
            aria-label={`${rating} ${t('search.filter.starsAndAbove')}`}
            className="flex items-center gap-1 text-xs px-2 py-1"
          >
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            {rating}+
          </ToggleGroupItem>
        ))}
      </ToggleGroup>
    </div>
  );
};

export default RatingFilter;
