
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import ReviewCard from '@/components/ReviewCard';

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  created_at: string;
}

interface ReviewsListProps {
  reviews: Review[];
  isLoading: boolean;
}

const ReviewsList: React.FC<ReviewsListProps> = ({ reviews, isLoading }) => {
  const { t } = useLanguage();

  if (isLoading) {
    return (
      <p className="text-center py-6 text-gray-500 dark:text-gray-400">
        {t('common.loading')}...
      </p>
    );
  }

  if (reviews.length === 0) {
    return (
      <p className="text-center py-6 text-gray-500 dark:text-gray-400">
        {t('review.noReviews')}
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <ReviewCard
          key={review.id}
          name={review.name}
          rating={review.rating}
          comment={review.comment}
          created_at={review.created_at}
        />
      ))}
    </div>
  );
};

export default ReviewsList;
