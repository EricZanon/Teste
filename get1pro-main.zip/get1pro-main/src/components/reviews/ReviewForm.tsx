
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { Star } from 'lucide-react';

interface ReviewFormProps {
  providerId: string;
  onReviewSubmitted: () => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ providerId, onReviewSubmitted }) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [rating, setRating] = useState(0); // Start with 0 instead of 5
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !comment || rating === 0) {
      toast({
        title: t('review.error.title'),
        description: t('review.error.emptyFields'),
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const newReview = {
        provider_id: providerId,
        name,
        rating,
        comment,
      };
      
      const { error } = await supabase
        .from('reviews')
        .insert([newReview]);
        
      if (error) {
        console.error('Error saving review:', error);
        toast({
          title: t('review.error.title'),
          description: t('review.error.saving'),
          variant: "destructive",
        });
        return;
      }
      
      // Clear the form
      setName('');
      setComment('');
      setRating(0); // Reset to 0
      
      toast({
        description: t('review.success'),
      });
      
      // Notify parent component to refresh reviews
      onReviewSubmitted();
    } catch (error) {
      console.error('Error in review submission:', error);
      toast({
        title: t('review.error.title'),
        description: t('review.error.unexpected'),
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmitReview} className="space-y-4">
      <div>
        <label htmlFor="name" className="block text-sm font-medium mb-1 dark:text-gray-300">
          {t('Nome')}
        </label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={t('Nome Completo')}
          disabled={isSubmitting}
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1 dark:text-gray-300">
          {t('review.rating')} {rating > 0 && <span className="text-gray-500">({rating} estrela{rating !== 1 ? 's' : ''})</span>}
        </label>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <Button
              key={star}
              type="button"
              variant="ghost"
              size="sm"
              className="p-1 hover:bg-transparent"
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoveredRating(star)}
              onMouseLeave={() => setHoveredRating(0)}
              disabled={isSubmitting}
            >
              <Star
                style={{width: '1.2rem', height: '2rem'}}
                className={`h-8 w-8 transition-colors ${
                  star <= (hoveredRating || rating) 
                    ? 'text-yellow-400 fill-yellow-400' 
                    : 'text-gray-300 dark:text-gray-600'
                }`}
              />
            </Button>
          ))}
        </div>
      </div>
      
      <div>
        <label htmlFor="comment" className="block text-sm font-medium mb-1 dark:text-gray-300">
          {t('Avaliação')}
        </label>
        <Textarea
          id="comment"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder={t('Insira sua avaliação do profissional')}
          rows={4}
          disabled={isSubmitting}
        />
      </div>
      
      <Button type="submit" disabled={isSubmitting || rating === 0}>
        {isSubmitting ? t('common.submitting') : t('review.submit')}
      </Button>
    </form>
  );
};

export default ReviewForm;
