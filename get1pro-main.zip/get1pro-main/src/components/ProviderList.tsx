
import React from 'react';
import { ServiceProvider } from '@/types';
import ProviderCard from './ProviderCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFavoritesContext } from '@/contexts/FavoritesContext';

interface ProviderListProps {
  filteredProviders: ServiceProvider[];
}

const ProviderList: React.FC<ProviderListProps> = ({ filteredProviders }) => {
  const { t } = useLanguage();
  
  // Check if FavoritesContext is available
  let favoritesContextAvailable = true;
  try {
    useFavoritesContext();
  } catch (error) {
    console.warn('FavoritesContext not available in ProviderList', error);
    favoritesContextAvailable = false;
  }

  if (filteredProviders.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-app-darkgray dark:text-gray-400">{t('search.results.notFound')}</p>
        <p className="text-sm mt-2 text-app-darkgray dark:text-gray-500">{t('search.results.tryAgain')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 mb-20">
      {filteredProviders.map((provider) => (
        <div key={provider.id} className="provider-card-wrapper">
          {favoritesContextAvailable ? (
            <ProviderCard key={`provider-${provider.id}`} provider={provider} />
          ) : (
            <div className="p-4 border rounded-md shadow-sm bg-white dark:bg-gray-800">
              <p className="font-semibold">{provider.name}</p>
              <p className="text-sm text-gray-500">{provider.service}</p>
              <p className="text-xs text-red-500 mt-2">{t('favorites.contextError') || 'Error: Unable to access favorites'}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ProviderList;
