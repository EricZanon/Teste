
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { useCountries } from '@/hooks/useCountries';

interface CountrySelectProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

const CountrySelect: React.FC<CountrySelectProps> = ({ value, onChange, disabled = false }) => {
  const { t } = useLanguage();
  const { countries, loading } = useCountries();

  return (
    <div>
      <label htmlFor="country" className="block text-sm font-medium mb-1">
        {t('provider.country')}
      </label>
      <Select value={value} onValueChange={onChange} disabled={disabled || loading}>
        <SelectTrigger id="country">
          <SelectValue placeholder={loading ? "Carregando..." : t('provider.select_country')} />
        </SelectTrigger>
        <SelectContent>
          {countries.map((country) => (
            <SelectItem key={country.id} value={country.code}>
              {country.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default CountrySelect;
