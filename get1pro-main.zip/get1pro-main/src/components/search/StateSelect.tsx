
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useLanguage } from '@/contexts/LanguageContext';

interface StateSelectProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  countryCode?: string;
  availableStates?: Array<{code: string; name: string}>;
}

const StateSelect: React.FC<StateSelectProps> = ({ 
  value, 
  onChange, 
  disabled = false, 
  countryCode = 'BR',
  availableStates = []
}) => {
  const { t } = useLanguage();
  
  const handleStateChange = (newValue: string) => {
    console.log('StateSelect: State changed to:', newValue);
    onChange(newValue);
  };

  // Check if the component should be disabled
  const isDisabled = disabled || availableStates.length === 0;

  // Always use the current value - don't clear it based on availability
  const displayValue = value || '';

  console.log('StateSelect rendering with availableStates:', availableStates);

  return (
    <div>
      <label htmlFor="state" className="block text-sm font-medium mb-1">
        {t('search.form.state') || 'Estado'}
      </label>
      <Select 
        value={displayValue} 
        onValueChange={handleStateChange} 
        disabled={isDisabled}
      >
        <SelectTrigger id="state" className="w-full">
          <SelectValue 
            placeholder={
              availableStates.length === 0
                ? "Nenhum estado disponível"
                : t('search.form.selectState') || 'Selecione um estado'
            } 
          />
        </SelectTrigger>
        <SelectContent className="max-h-[300px] overflow-y-auto">
          {availableStates.length > 0 ? (
            availableStates.map((state) => (
              <SelectItem key={state.code} value={state.code}>
                {state.name}
              </SelectItem>
            ))
          ) : (
            <SelectItem value="placeholder" disabled>
              Nenhum estado disponível
            </SelectItem>
          )}
        </SelectContent>
      </Select>
    </div>
  );
};

export default StateSelect;
