
import React from 'react';
import { Button } from '../ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

interface SearchButtonsProps {
  onSearch: () => void;
  isSearchDisabled: boolean;
  loading: boolean;
}

const SearchButtons: React.FC<SearchButtonsProps> = ({ 
  onSearch, 
  isSearchDisabled, 
  loading
}) => {
  const { t } = useLanguage();

  return (
    <div className="pt-2">
      <Button 
        type="button" 
        className="w-full bg-app-primary hover:bg-app-primary/90 text-white"
        onClick={onSearch}
        disabled={isSearchDisabled || loading}
      >
        {loading ? t('search.form.loading') : t('search.form.searchButton')}
      </Button>
    </div>
  );
};

export default SearchButtons;
