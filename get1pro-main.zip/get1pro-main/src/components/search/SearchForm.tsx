import React, { useState, useEffect } from 'react';
import StateSelect from './StateSelect';
import CitySelect from './CitySelect';
import ServiceSelect from './ServiceSelect';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSearchFormData } from '@/hooks/useSearchFormData';
import SearchButtons from './SearchButtons';
import { City } from '@/types';
interface SearchFormProps {
  onSearch: (state: string, city: string, service: string) => void;
  initialState?: string;
  initialCity?: string;
  initialService?: string;
}
const SearchForm: React.FC<SearchFormProps> = ({
  onSearch,
  initialState = '',
  initialCity = '',
  initialService = ''
}) => {
  const [selectedState, setSelectedState] = useState<string>(initialState);
  const [selectedCity, setSelectedCity] = useState<string>(initialCity);
  const [selectedService, setSelectedService] = useState<string>(initialService);
  const {
    t
  } = useLanguage();
  const {
    availableStates,
    availableCities,
    availableServices,
    loading
  } = useSearchFormData(selectedState, selectedCity);
  console.log('SearchForm rendering with state:', selectedState, 'city:', selectedCity);
  console.log('Available cities in SearchForm:', availableCities.length, availableCities);

  // Apply initial values
  useEffect(() => {
    console.log('SearchForm initialValues:', {
      initialState,
      initialCity,
      initialService
    });
    if (initialState && initialState !== selectedState) {
      console.log('Setting initial state:', initialState);
      setSelectedState(initialState);
    }
    if (initialCity && initialCity !== selectedCity) {
      console.log('Setting initial city:', initialCity);
      setSelectedCity(initialCity);
    }
    if (initialService && initialService !== selectedService) {
      console.log('Setting initial service:', initialService);
      setSelectedService(initialService);
    }

    // If we have all initial values, trigger search automatically
    if (initialState && initialCity) {
      const timer = setTimeout(() => {
        if (initialState && initialCity) {
          console.log('Auto-triggering search with:', {
            initialState,
            initialCity,
            initialService
          });
          onSearch(initialState, initialCity, initialService);
        }
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [initialState, initialCity, initialService]);
  const handleSearchClick = () => {
    console.log('Search clicked with:', {
      selectedState,
      selectedCity,
      selectedService
    });
    onSearch(selectedState, selectedCity, selectedService);
  };

  // When state changes, reset city and service
  const handleStateChange = (state: string) => {
    console.log('State changed to:', state);
    setSelectedState(state);
    setSelectedCity('');
    setSelectedService('');
  };

  // When city changes, reset service
  const handleCityChange = (city: string) => {
    console.log('City changed to:', city);
    setSelectedCity(city);
    setSelectedService('');
  };

  // Transform the string array into City objects
  const formattedCities: City[] = availableCities.map(cityCode => ({
    code: cityCode,
    name: cityCode.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
  }));
  return <div style={{
    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
  }} className="bg-white dark:bg-slate-800 rounded-lg p-4 mb-6 py-[9px] my-0">
      <h2 className="text-lg font-semibold mb-4">{t('search.form.title') || 'Buscar Profissionais'}</h2>
      <div className="space-y-4">
        <StateSelect value={selectedState} onChange={handleStateChange} availableStates={availableStates} />
        
        <CitySelect value={selectedCity} onChange={handleCityChange} availableCities={formattedCities} disabled={!selectedState || loading} stateCode={selectedState} />
        
        <ServiceSelect value={selectedService} onChange={setSelectedService} availableServices={availableServices} disabled={!selectedCity || loading} hasCity={!!selectedCity} />

        <SearchButtons onSearch={handleSearchClick} isSearchDisabled={loading || !(selectedState && selectedCity)} loading={loading} />
      </div>
    </div>;
};
export default SearchForm;