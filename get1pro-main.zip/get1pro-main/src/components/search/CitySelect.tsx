
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { useCities } from '@/hooks/useCities';

interface CitySelectProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  countryCode?: string;
  stateCode?: string;
  availableCities?: Array<{code: string; name: string}>;
}

const CitySelect: React.FC<CitySelectProps> = ({ 
  value, 
  onChange, 
  disabled = false, 
  countryCode = 'BR',
  stateCode = '',
  availableCities = []
}) => {
  const { t } = useLanguage();
  const { cities, loading, error } = useCities(stateCode, countryCode);
  
  console.log('CitySelect render:', {
    stateCode,
    countryCode,
    value,
    citiesCount: cities.length,
    availableCitiesCount: availableCities.length,
    loading,
    error
  });
  
  // Use availableCities if provided, otherwise use all cities from database
  const citiesToDisplay = availableCities.length > 0 ? availableCities : cities;

  const handleCityChange = (newValue: string) => {
    console.log('CitySelect: City changed to:', newValue);
    onChange(newValue);
  };

  // Check if the component should be disabled
  const isDisabled = disabled || loading || !stateCode;

  // Show loading state
  if (loading) {
    return (
      <div>
        <label htmlFor="city" className="block text-sm font-medium mb-1">
          {t('search.form.city') || 'Cidade'}
        </label>
        <Select disabled={true}>
          <SelectTrigger id="city" className="w-full">
            <SelectValue placeholder="Carregando cidades..." />
          </SelectTrigger>
        </Select>
      </div>
    );
  }

  // Show error state
  if (error) {
    console.error('CitySelect: Error loading cities:', error);
  }

  // Determine placeholder text
  let placeholderText = t('search.form.selectCity') || 'Selecione uma cidade';
  
  if (!stateCode) {
    placeholderText = "Selecione um estado primeiro";
  } else if (citiesToDisplay.length === 0 && !loading) {
    placeholderText = "Nenhuma cidade encontrada";
  }

  return (
    <div>
      <label htmlFor="city" className="block text-sm font-medium mb-1">
        {t('search.form.city') || 'Cidade'}
      </label>
      <Select 
        value={value || ''} 
        onValueChange={handleCityChange} 
        disabled={isDisabled}
      >
        <SelectTrigger id="city" className="w-full">
          <SelectValue placeholder={placeholderText} />
        </SelectTrigger>
        <SelectContent className="max-h-[300px] overflow-y-auto">
          {citiesToDisplay.length > 0 ? (
            citiesToDisplay.map((city) => (
              <SelectItem key={city.code} value={city.code}>
                {city.name}
              </SelectItem>
            ))
          ) : (
            <SelectItem value="no-cities" disabled>
              {!stateCode 
                ? "Selecione um estado primeiro"
                : "Nenhuma cidade encontrada"
              }
            </SelectItem>
          )}
        </SelectContent>
      </Select>
    </div>
  );
};

export default CitySelect;
