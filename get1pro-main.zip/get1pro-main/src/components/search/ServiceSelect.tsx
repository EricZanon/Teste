
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { ServiceType } from '@/hooks/useSearchFormData';

interface ServiceSelectProps {
  value: string;
  onChange: (value: string) => void;
  availableServices: ServiceType[];
  disabled: boolean;
  hasCity: boolean;
}

const ServiceSelect: React.FC<ServiceSelectProps> = ({ 
  value, 
  onChange, 
  availableServices, 
  disabled, 
  hasCity 
}) => {
  const { t } = useLanguage();
  
  console.log('Available services:', availableServices);
  console.log('Current selected service:', value);

  return (
    <div>
      <label htmlFor="service" className="block text-sm font-medium mb-1">
        {t('search.form.service')}
      </label>
      <Select 
        value={value} 
        onValueChange={onChange}
        disabled={disabled}
      >
        <SelectTrigger id="service">
          <SelectValue 
            placeholder={t('search.form.selectService')} 
          />
        </SelectTrigger>
        <SelectContent>
          {availableServices.map((service) => (
            <SelectItem key={service.id} value={service.id}>
              {service.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default ServiceSelect;
