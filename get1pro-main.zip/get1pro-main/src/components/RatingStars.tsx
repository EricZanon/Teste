
import React from "react";
import { Star, StarHalf } from "lucide-react";

interface RatingStarsProps {
  rating: number; // 1 a 5, aceita casas decimais como 4.5
  reviewsUrl?: string;
}

const getStars = (rating: number) => {
  const stars = [];
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.25 && rating % 1 < 0.75;
  const totalStars = hasHalf ? fullStars + 1 : fullStars;
  
  for (let i = 0; i < fullStars; i++) {
    stars.push(<Star key={i} className="text-yellow-400 fill-yellow-400" size={18} />);
  }
  if (hasHalf) {
    stars.push(<StarHalf key="half" className="text-yellow-400 fill-yellow-400" size={18} />);
  }
  for (let i = totalStars; i < 5; i++) {
    stars.push(<Star key={i + "empty"} className="text-app-lightgray text-gray-300 dark:text-gray-600" size={18} />);
  }
  return stars;
};

const RatingStars: React.FC<RatingStarsProps> = ({ rating }) => {
  return (
    <div className="flex items-center gap-1" style={{marginTop: '8px'}}>
      {getStars(rating)}
      <span className="ml-1 text-xs text-gray-500">{rating.toFixed(1)}</span>
    </div>
  );
};

export default RatingStars;
