
import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { AddProviderDialog } from './AddProviderDialog';
import { SetAdminDialog } from './SetAdminDialog';
import { ProvidersTable } from './ProvidersTable';
import { DeleteProviderDialog } from './DeleteProviderDialog';
import { ToggleActiveDialog } from './ToggleActiveDialog';
import { EditProviderSheet } from './EditProviderSheet';
import { useProviderManagement } from '@/hooks/useProviderManagement';

export function AdminPanel() {
  const { t } = useLanguage();
  const {
    providers,
    loading,
    loadingAction,
    error,
    providerToDelete,
    providerToToggleActive,
    isDeleteDialogOpen,
    isToggleActiveDialogOpen,
    editingProvider,
    isSheetOpen,
    fetchProviders,
    handleCreateProvider,
    handleSetAdmin,
    handleDeleteProvider,
    handleToggleActiveStatus,
    handleEditProfile,
    handleSheetClose,
    setProviderToDelete,
    setProviderToToggleActive,
    setIsDeleteDialogOpen,
    setIsToggleActiveDialogOpen,
  } = useProviderManagement();

  useEffect(() => {
    fetchProviders();
  }, []);

  const handleRetry = () => {
    fetchProviders();
  };

  const handleView = (id: string) => {
    // Navigate to provider profile - in a real app this would use router
    window.open(`/profissional/${id}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div>
              <CardTitle>{t('admin.providers_management')}</CardTitle>
              <p className="text-muted-foreground mt-1">
                {t('admin.manage_providers_description')}
              </p>
            </div>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              {error && (
                <Button onClick={handleRetry} variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Tentar novamente
                </Button>
              )}
              <AddProviderDialog onAddProvider={handleCreateProvider} loading={loadingAction} />
              <SetAdminDialog onSetAdmin={handleSetAdmin} loading={loadingAction} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-6">
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <p>{t('common.loading')}</p>
              </div>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <AlertCircle className="h-8 w-8 text-yellow-500 mb-2" />
              <h3 className="text-lg font-semibold mb-2">Problema de Conectividade</h3>
              <p className="text-muted-foreground mb-4">
                Não foi possível carregar a lista de profissionais. Exibindo dados de exemplo.
              </p>
              <Button onClick={handleRetry} variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Tentar novamente
              </Button>
            </div>
          ) : null}
          
          <ProvidersTable
            providers={providers}
            loading={loading}
            onView={handleView}
            onEdit={handleEditProfile}
            onDelete={(provider) => {
              setProviderToDelete(provider);
              setIsDeleteDialogOpen(true);
            }}
            onToggleActive={(provider) => {
              setProviderToToggleActive(provider);
              setIsToggleActiveDialogOpen(true);
            }}
          />
        </CardContent>
      </Card>

      <DeleteProviderDialog
        provider={providerToDelete}
        isOpen={isDeleteDialogOpen}
        onOpenChange={(open) => {
          setIsDeleteDialogOpen(open);
          if (!open) setProviderToDelete(null);
        }}
        onConfirm={handleDeleteProvider}
        loading={loadingAction}
      />

      <ToggleActiveDialog
        provider={providerToToggleActive}
        isOpen={isToggleActiveDialogOpen}
        onOpenChange={(open) => {
          setIsToggleActiveDialogOpen(open);
          if (!open) setProviderToToggleActive(null);
        }}
        onConfirm={handleToggleActiveStatus}
        loading={loadingAction}
      />

      <EditProviderSheet
        providerId={editingProvider}
        isOpen={isSheetOpen}
        onOpenChange={(open) => {
          if (!open) handleSheetClose();
        }}
        onSuccess={handleSheetClose}
      />
    </div>
  );
}
