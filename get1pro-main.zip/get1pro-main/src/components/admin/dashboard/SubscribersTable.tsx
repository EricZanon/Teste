
import React from 'react';
import { DataTable } from '@/components/ui/data-table/DataTable';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ColumnDef } from '@tanstack/react-table';
import { ExternalLink, Eye } from 'lucide-react';
import { useSubscribers } from '@/hooks/useSubscribers';

interface Subscriber {
  id: string;
  email: string;
  status: string;
  plan_name: string;
  current_period_end: string;
  created_at: string;
}

export const SubscribersTable = () => {
  const { subscribers, loading } = useSubscribers();

  const columns: ColumnDef<Subscriber>[] = [
    {
      accessorKey: 'email',
      header: 'Email',
    },
    {
      accessorKey: 'plan_name',
      header: 'Plano',
      cell: ({ row }) => {
        const planName = row.getValue('plan_name') as string;
        return planName || 'N/A';
      },
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const status = row.getValue('status') as string;
        const variant = status === 'active' ? 'default' : 'secondary';
        return (
          <Badge variant={variant}>
            {status === 'active' ? 'Ativo' : 'Inativo'}
          </Badge>
        );
      },
    },
    {
      accessorKey: 'current_period_end',
      header: 'Próxima Renovação',
      cell: ({ row }) => {
        const date = row.getValue('current_period_end') as string;
        if (!date) return 'N/A';
        return new Date(date).toLocaleDateString('pt-BR');
      },
    },
    {
      accessorKey: 'created_at',
      header: 'Data de Assinatura',
      cell: ({ row }) => {
        const date = row.getValue('created_at') as string;
        return new Date(date).toLocaleDateString('pt-BR');
      },
    },
    {
      id: 'actions',
      header: 'Ações',
      cell: ({ row }) => {
        const subscriber = row.original;
        return (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`https://dashboard.stripe.com/customers`, '_blank')}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Assinantes</h3>
      </div>
      
      <DataTable
        columns={columns}
        data={subscribers}
        loading={loading}
        searchPlaceholder="Buscar por email..."
        emptyMessage="Nenhum assinante encontrado."
      />
    </div>
  );
};
