
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { ProviderMetrics } from '@/types/metrics';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';
import { addDays, format, subDays, subMonths, subYears } from 'date-fns';

interface SharesTimelineProps {
  metrics: ProviderMetrics[];
  timeframe: 'week' | 'month' | 'year';
}

export const SharesTimeline = ({ metrics, timeframe }: SharesTimelineProps) => {
  const { t } = useLanguage();

  // Generate mock timeline data based on metrics and timeframe
  const timelineData = useMemo(() => {
    // In a real implementation, this would use actual timestamped data
    // For now, we'll simulate timeline data based on the total shares
    const totalShares = metrics.reduce((sum, provider) => sum + (provider.shares || 0), 0);
    const dataPoints: Array<{ date: string; shares: number }> = [];
    
    // Determine date range based on timeframe
    let startDate: Date;
    let dateFormat: string;
    let days: number;
    
    switch (timeframe) {
      case 'week':
        startDate = subDays(new Date(), 7);
        dateFormat = 'EEE';
        days = 7;
        break;
      case 'month':
        startDate = subMonths(new Date(), 1);
        dateFormat = 'dd/MM';
        days = 30;
        break;
      case 'year':
        startDate = subYears(new Date(), 1);
        dateFormat = 'MMM';
        days = 12;
        break;
    }
    
    // Generate data points with some randomness to simulate trends
    if (timeframe === 'year') {
      // Monthly data for year view
      for (let i = 0; i < 12; i++) {
        const currentDate = addDays(startDate, i * 30);
        const monthShare = Math.round(totalShares / 12 * (0.7 + Math.random() * 0.6));
        dataPoints.push({
          date: format(currentDate, dateFormat),
          shares: monthShare,
        });
      }
    } else {
      // Daily data for week/month view
      for (let i = 0; i < days; i++) {
        const currentDate = addDays(startDate, i);
        const dailyShare = Math.round(totalShares / days * (0.7 + Math.random() * 0.6));
        dataPoints.push({
          date: format(currentDate, dateFormat),
          shares: dailyShare,
        });
      }
    }
    
    return dataPoints;
  }, [metrics, timeframe]);

  const chartConfig = {
    shares: { color: '#10b981', label: 'Compartilhamentos' },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          {t('Compartilhamentos ao Longo do Tempo') || 'Compartilhamentos ao Longo do Tempo'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip content={<ChartTooltipContent />} />
              <Line 
                type="monotone" 
                dataKey="shares" 
                stroke="#10b981" 
                name="Compartilhamentos"
                strokeWidth={2} 
                dot={{ r: 4 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};
