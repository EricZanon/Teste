
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { ChartPie, ChartBar } from 'lucide-react';
import { MetricsOverview } from './MetricsOverview';
import { SocialEngagementChart } from './SocialEngagementChart';
import { SharesTimeline } from './SharesTimeline';
import { ProviderComparisonChart } from './ProviderComparisonChart';
import { useAdminMetrics } from '@/hooks/useAdminMetrics';

export const MetricsDashboard = () => {
  const { t } = useLanguage();
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'year'>('month');
  const { metrics, loading, fetchMetrics } = useAdminMetrics();

  const handleTimeframeChange = (newTimeframe: 'week' | 'month' | 'year') => {
    setTimeframe(newTimeframe);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div>
              <CardTitle>{t('admin.metrics_dashboard') || 'Métricas & Análises'}</CardTitle>
              <CardDescription>
                {t('admin.metrics_description') || 'Visão geral das métricas dos profissionais cadastrados'}
              </CardDescription>
            </div>
            <div className="flex space-x-2 mt-2 md:mt-0">
              <button 
                onClick={() => handleTimeframeChange('week')}
                className={`px-3 py-1 text-sm rounded-md ${timeframe === 'week' ? 'bg-primary text-white' : 'bg-muted'}`}
              >
                {t('Semana') || 'Semana'}
              </button>
              <button 
                onClick={() => handleTimeframeChange('month')}
                className={`px-3 py-1 text-sm rounded-md ${timeframe === 'month' ? 'bg-primary text-white' : 'bg-muted'}`}
              >
                {t('Mês') || 'Mês'}
              </button>
              <button 
                onClick={() => handleTimeframeChange('year')}
                className={`px-3 py-1 text-sm rounded-md ${timeframe === 'year' ? 'bg-primary text-white' : 'bg-muted'}`}
              >
                {t('Ano') || 'Ano'}
              </button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-6">
              <p>{t('Carregando...') || 'Carregando...'}</p>
            </div>
          ) : (
            <div className="space-y-6">
              <MetricsOverview metrics={metrics} />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <SocialEngagementChart metrics={metrics} />
                <SharesTimeline metrics={metrics} timeframe={timeframe} />
              </div>
              
              <ProviderComparisonChart metrics={metrics} />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
