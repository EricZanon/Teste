
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { MetricsOverview } from './MetricsOverview';
import { SocialEngagementChart } from './SocialEngagementChart';
import { SharesTimeline } from './SharesTimeline';
import { ProviderComparisonChart } from './ProviderComparisonChart';
import { MetricsTimeframeSelector } from './MetricsTimeframeSelector';
import { useAdminMetrics } from '@/hooks/useAdminMetrics';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertCircle } from 'lucide-react';

export const DashboardMetrics = () => {
  const { t } = useLanguage();
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'year'>('month');
  const { metrics, loading, error, fetchMetrics } = useAdminMetrics();

  const handleTimeframeChange = (newTimeframe: 'week' | 'month' | 'year') => {
    setTimeframe(newTimeframe);
  };

  const handleRetry = () => {
    fetchMetrics();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div>
            <CardTitle>{t('admin.metrics_analytics')}</CardTitle>
            <CardDescription>
              {t('admin.metrics_overview_description')}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {error && (
              <Button onClick={handleRetry} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Tentar novamente
              </Button>
            )}
            <MetricsTimeframeSelector 
              timeframe={timeframe} 
              onTimeframeChange={handleTimeframeChange} 
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center p-6">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 animate-spin" />
              <p>{t('common.loading')}</p>
            </div>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center p-6 text-center">
            <AlertCircle className="h-8 w-8 text-yellow-500 mb-2" />
            <h3 className="text-lg font-semibold mb-2">Problema de Conectividade</h3>
            <p className="text-muted-foreground mb-4">
              Não foi possível carregar as métricas. Exibindo dados de exemplo.
            </p>
            <Button onClick={handleRetry} variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Tentar novamente
            </Button>
          </div>
        ) : null}
        
        <div className="space-y-6">
          <MetricsOverview metrics={metrics} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <SocialEngagementChart metrics={metrics} />
            <SharesTimeline metrics={metrics} timeframe={timeframe} />
          </div>
          
          <ProviderComparisonChart metrics={metrics} />
        </div>
      </CardContent>
    </Card>
  );
};
