
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

interface MetricsTimeframeSelectorProps {
  timeframe: 'week' | 'month' | 'year';
  onTimeframeChange: (timeframe: 'week' | 'month' | 'year') => void;
}

export const MetricsTimeframeSelector = ({ 
  timeframe, 
  onTimeframeChange 
}: MetricsTimeframeSelectorProps) => {
  const { t } = useLanguage();
  
  return (
    <div className="flex space-x-2 mt-2 md:mt-0">
      <button 
        onClick={() => onTimeframeChange('week')}
        className={`px-3 py-1 text-sm rounded-md ${timeframe === 'week' ? 'bg-primary text-white' : 'bg-muted'}`}
      >
        {t('common.week')}
      </button>
      <button 
        onClick={() => onTimeframeChange('month')}
        className={`px-3 py-1 text-sm rounded-md ${timeframe === 'month' ? 'bg-primary text-white' : 'bg-muted'}`}
      >
        {t('common.month')}
      </button>
      <button 
        onClick={() => onTimeframeChange('year')}
        className={`px-3 py-1 text-sm rounded-md ${timeframe === 'year' ? 'bg-primary text-white' : 'bg-muted'}`}
      >
        {t('common.year')}
      </button>
    </div>
  );
};
