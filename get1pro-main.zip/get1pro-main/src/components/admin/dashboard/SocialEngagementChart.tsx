
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { ProviderMetrics } from '@/types/metrics';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';

interface SocialEngagementChartProps {
  metrics: ProviderMetrics[];
}

export const SocialEngagementChart = ({ metrics }: SocialEngagementChartProps) => {
  const { t } = useLanguage();

  // Calculate totals for each social platform
  const socialData = React.useMemo(() => {
    const totals = metrics.reduce(
      (acc, curr) => {
        return {
          facebook: acc.facebook + (curr.facebook_clicks || 0),
          instagram: acc.instagram + (curr.instagram_clicks || 0),
          google: acc.google + (curr.google_business_clicks || 0),
          website: acc.website + 0, // Placeholder for website clicks
        };
      },
      { facebook: 0, instagram: 0, google: 0, website: 0 }
    );

    return [
      {
        name: 'Facebook',
        value: totals.facebook,
        color: '#4267B2',
      },
      {
        name: 'Instagram',
        value: totals.instagram,
        color: '#C13584',
      },
      {
        name: 'Google Meu Negócio',
        value: totals.google,
        color: '#4285F4',
      },
      {
        name: 'Website',
        value: totals.website,
        color: '#2E7D32',
      },
    ];
  }, [metrics]);

  // Configuration for the chart
  const chartConfig = {
    facebook: { color: '#4267B2', label: 'Facebook' },
    instagram: { color: '#C13584', label: 'Instagram' },
    google: { color: '#4285F4', label: 'Google Meu Negócio' },
    website: { color: '#2E7D32', label: 'Website' },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          {t('Engajamento em Redes Sociais') || 'Engajamento em Redes Sociais'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={chartConfig}
          className="h-[300px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={socialData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {socialData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltipContent />} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};
