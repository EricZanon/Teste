
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { ProviderMetrics } from '@/types/metrics';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';

interface ProviderComparisonChartProps {
  metrics: ProviderMetrics[];
}

export const ProviderComparisonChart = ({ metrics }: ProviderComparisonChartProps) => {
  const { t } = useLanguage();

  // Process data for the chart
  const chartData = useMemo(() => {
    // Get top 5 providers by total engagement
    return metrics
      .map(provider => {
        const totalSocial = 
          (provider.facebook_clicks || 0) +
          (provider.instagram_clicks || 0) +
          (provider.twitter_clicks || 0) +
          (provider.google_business_clicks || 0);
        
        return {
          name: provider.provider_name || 'Unknown',
          shares: provider.shares || 0,
          social: totalSocial,
          total: (provider.shares || 0) + totalSocial,
        };
      })
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [metrics]);

  const chartConfig = {
    shares: { color: '#10b981', label: 'Compartilhamentos' },
    social: { color: '#6366f1', label: 'Redes Sociais' },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          {t('Top Profissionais por Engajamento') || 'Top Profissionais por Engajamento'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip content={<ChartTooltipContent />} />
              <Legend />
              <Bar dataKey="shares" stackId="a" fill="#10b981" name="Compartilhamentos" />
              <Bar dataKey="social" stackId="a" fill="#6366f1" name="Redes Sociais" />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};
