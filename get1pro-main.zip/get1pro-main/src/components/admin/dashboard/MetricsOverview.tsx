
import React, { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { ProviderMetrics } from '@/types/metrics';
import { Share, Facebook, Instagram, Globe, Star } from 'lucide-react';

interface MetricsOverviewProps {
  metrics: ProviderMetrics[];
}

export const MetricsOverview = ({ metrics }: MetricsOverviewProps) => {
  const { t } = useLanguage();

  const totals = useMemo(() => {
    return metrics.reduce((acc, curr) => {
      return {
        shares: acc.shares + (curr.shares || 0),
        facebook: acc.facebook + (curr.facebook_clicks || 0),
        instagram: acc.instagram + (curr.instagram_clicks || 0),
        google: acc.google + (curr.google_business_clicks || 0),
        favorites: acc.favorites + 0, // Placeholder for favorites count
        website: acc.website + 0, // Placeholder for website clicks
      };
    }, {
      shares: 0,
      facebook: 0,
      instagram: 0,
      google: 0,
      favorites: 0,
      website: 0,
    });
  }, [metrics]);

  const cards = [
    {
      title: t('Compartilhamentos') || 'Compartilhamentos',
      value: totals.shares,
      icon: <Share className="h-5 w-5 text-blue-600" />,
      color: 'bg-blue-100 dark:bg-blue-800/20',
    },
    {
      title: t('Cliques Facebook') || 'Cliques Facebook',
      value: totals.facebook,
      icon: <Facebook className="h-5 w-5 text-blue-600" />,
      color: 'bg-blue-100 dark:bg-blue-800/20',
    },
    {
      title: t('Cliques Instagram') || 'Cliques Instagram',
      value: totals.instagram,
      icon: <Instagram className="h-5 w-5 text-pink-600" />,
      color: 'bg-pink-100 dark:bg-pink-800/20',
    },
    {
      title: t('Cliques Google Meu Negócio') || 'Cliques Google Meu Negócio',
      value: totals.google,
      icon: <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 48 48"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5 text-blue-600"
      >
        <path d="m31.6814,34.8868c-1.9155,1.29-4.3586,2.0718-7.2514,2.0718-5.59,0-10.3395-3.7723-12.04-8.8541v-.0195c-.43-1.29-.6841-2.6582-.6841-4.085s.2541-2.795.6841-4.085c1.7005-5.0818,6.45-8.8541,12.04-8.8541,3.1664,0,5.9809,1.0945,8.2286,3.2055l6.1568-6.1568c-3.7332-3.4791-8.5805-5.6095-14.3855-5.6095-8.4045,0-15.6559,4.8277-19.1936,11.8641-1.4659,2.8927-2.3064,6.1568-2.3064,9.6359s.8405,6.7432,2.3064,9.6359v.0195c3.5377,7.0168,10.7891,11.8445,19.1936,11.8445,5.805,0,10.6718-1.9155,14.2291-5.1991,4.0655-3.7527,6.4109-9.2645,6.4109-15.8123,0-1.5245-.1368-2.9905-.3909-4.3977h-20.2491v8.3264h11.5709c-.5082,2.6777-2.0327,4.945-4.3195,6.4695h0Z"></path>
      </svg>,
      color: 'bg-blue-100 dark:bg-blue-800/20',
    },
    {
      title: t('Cliques Website') || 'Cliques Website',
      value: totals.website,
      icon: <Globe className="h-5 w-5 text-green-600" />,
      color: 'bg-green-100 dark:bg-green-800/20',
    },
    {
      title: t('Total de Favoritos') || 'Total de Favoritos',
      value: totals.favorites,
      icon: <Star className="h-5 w-5 text-yellow-600" />,
      color: 'bg-yellow-100 dark:bg-yellow-800/20',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {cards.map((card, index) => (
        <Card key={index}>
          <CardContent className={`p-4 flex items-center space-x-4 ${card.color} rounded-lg`}>
            <div className="bg-white dark:bg-slate-800 p-2 rounded-full">
              {card.icon}
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
              <p className="text-2xl font-bold">{card.value.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
