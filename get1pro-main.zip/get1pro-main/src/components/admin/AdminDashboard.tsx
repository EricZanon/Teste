
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DashboardMetrics } from './dashboard/DashboardMetrics';
import { SubscriptionMetrics } from './dashboard/SubscriptionMetrics';
import { SubscribersTable } from './dashboard/SubscribersTable';

export function AdminDashboard() {
  const { t } = useLanguage();
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{t('admin.dashboard')}</CardTitle>
          <CardDescription>
            {t('admin.dashboard_overview')}
          </CardDescription>
        </CardHeader>
      </Card>
      
      <Tabs defaultValue="providers" className="w-full">
        <TabsList>
          <TabsTrigger value="providers">Profissionais</TabsTrigger>
          <TabsTrigger value="subscriptions">Assinaturas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="providers" className="space-y-6">
          <DashboardMetrics />
        </TabsContent>
        
        <TabsContent value="subscriptions" className="space-y-6">
          <SubscriptionMetrics />
          <Card>
            <CardContent className="pt-6">
              <SubscribersTable />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
