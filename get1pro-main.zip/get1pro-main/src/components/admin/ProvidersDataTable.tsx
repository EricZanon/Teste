
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Edit, Eye, Trash2, XCircle } from 'lucide-react';
import { DataTable } from '@/components/ui/data-table/DataTable';
import { ProviderProfile } from '@/types/provider';
import { serviceTypes } from '@/data/serviceTypes';
import { useCountries } from '@/hooks/useCountries';
import { useStates } from '@/hooks/useStates';
import { useCities } from '@/hooks/useCities';
import { ColumnDef } from '@tanstack/react-table';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';

interface ProvidersDataTableProps {
  providers: ProviderProfile[];
  loading: boolean;
  onView: (id: string) => void;
  onEdit: (id: string) => void;
  onToggleActive: (provider: ProviderProfile) => void;
  onDelete: (provider: ProviderProfile) => void;
}

export function ProvidersDataTable({
  providers,
  loading,
  onView,
  onEdit,
  onToggleActive,
  onDelete
}: ProvidersDataTableProps) {
  const { t } = useLanguage();
  const { user } = useAuth();
  const { countries } = useCountries();
  const { states } = useStates('BR'); // Load all Brazilian states for display
  const { cities } = useCities(); // Load all cities for display

  // Helper functions for displaying location data
  const getServiceTypeName = (serviceTypeId: string) => {
    const serviceType = serviceTypes.find(st => st.id === serviceTypeId);
    return serviceType ? serviceType.name : serviceTypeId;
  };

  const getCountryName = (countryCode: string) => {
    const country = countries.find(c => c.code === countryCode);
    return country ? country.name : countryCode;
  };

  const getStateName = (stateCode: string) => {
    const state = states.find(s => s.code === stateCode);
    return state ? state.name : stateCode;
  };

  const getCityName = (cityCode: string) => {
    const city = cities.find(c => c.code === cityCode);
    return city ? city.name : cityCode.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const columns: ColumnDef<ProviderProfile>[] = [
    {
      accessorKey: 'name',
      header: t('Nome') || 'Nome',
    },
    {
      accessorKey: 'service_type',
      header: t('Tipo de Serviço') || 'Tipo de Serviço',
      cell: ({ row }) => getServiceTypeName(row.original.service_type),
    },
    {
      accessorKey: 'country',
      header: t('País') || 'País',
      cell: ({ row }) => getCountryName(row.original.country || 'BR'),
    },
    {
      accessorKey: 'state',
      header: t('Estado') || 'Estado',
      cell: ({ row }) => getStateName(row.original.state),
    },
    {
      accessorKey: 'city',
      header: t('Cidade') || 'Cidade',
      cell: ({ row }) => getCityName(row.original.city),
    },
    {
      accessorKey: 'active',
      header: t('Status') || 'Status',
      cell: ({ row }) => (
        <Badge 
          variant={row.original.active ? "success" : "destructive"}
          className="whitespace-nowrap"
        >
          {row.original.active 
            ? (t('Ativo') || 'Ativo') 
            : (t('Inativo') || 'Inativo')
          }
        </Badge>
      ),
    },
    {
      id: 'actions',
      header: t('Ações') || 'Ações',
      cell: ({ row }) => (
        <div className="flex space-x-1">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onView(row.original.id)}
            title={t('Visualizar') || 'Visualizar'}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onEdit(row.original.id)}
            title={t('Editar') || 'Editar'}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onToggleActive(row.original)}
            title={row.original.active 
              ? (t('Inativar') || 'Inativar') 
              : (t('Ativar') || 'Ativar')
            }
            className={row.original.active 
              ? "text-red-600 hover:text-red-700" 
              : "text-green-600 hover:text-green-700"
            }
          >
            <XCircle className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onDelete(row.original)}
            title={t('Excluir') || 'Excluir'}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <DataTable 
      columns={columns}
      data={providers}
      loading={loading}
      filterColumn="name"
      searchPlaceholder={t('Buscar profissionais...') || "Buscar profissionais..."}
      emptyMessage={t('admin.no_providers') || "Nenhum profissional cadastrado."}
    />
  );
}
