
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit, Eye, Trash2, XCircle } from 'lucide-react';
import { ProviderProfile } from '@/types/provider';
import { serviceTypes } from '@/data/serviceTypes';
import { useCountries } from '@/hooks/useCountries';
import { useStates } from '@/hooks/useStates';
import { useCities } from '@/hooks/useCities';

interface ProvidersTableProps {
  providers: ProviderProfile[];
  loading: boolean;
  onView: (id: string) => void;
  onEdit: (id: string) => void;
  onToggleActive: (provider: ProviderProfile) => void;
  onDelete: (provider: ProviderProfile) => void;
}

export const ProvidersTable: React.FC<ProvidersTableProps> = ({
  providers,
  loading,
  onView,
  onEdit,
  onToggleActive,
  onDelete
}) => {
  const { t } = useLanguage();
  const { countries } = useCountries();
  const { states } = useStates('BR'); // Load all Brazilian states for display
  const { cities } = useCities(); // Load all cities for display

  // Helper functions for displaying location data
  const getServiceTypeName = (serviceTypeId: string) => {
    const serviceType = serviceTypes.find(st => st.id === serviceTypeId);
    return serviceType ? serviceType.name : serviceTypeId;
  };

  const getCountryName = (countryCode: string) => {
    const country = countries.find(c => c.code === countryCode);
    return country ? country.name : countryCode;
  };

  const getStateName = (stateCode: string) => {
    const state = states.find(s => s.code === stateCode);
    return state ? state.name : stateCode;
  };

  const getCityName = (cityCode: string) => {
    const city = cities.find(c => c.code === cityCode);
    return city ? city.name : cityCode.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (loading) {
    return <div className="py-8 text-center">{t('Carregando...') || 'Carregando...'}</div>;
  }

  return (
    <Table>
      <TableCaption>{t('Total de profissionais cadastrados') || 'Total de profissionais cadastrados'}: {providers.length}</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>{t('Nome') || 'Nome'}</TableHead>
          <TableHead>{t('Tipo de Serviço') || 'Tipo de Serviço'}</TableHead>
          <TableHead>{t('País') || 'País'}</TableHead>
          <TableHead>{t('Estado') || 'Estado'}</TableHead>
          <TableHead>{t('Cidade') || 'Cidade'}</TableHead>
          <TableHead>{t('Status') || 'Status'}</TableHead>
          <TableHead className="w-[150px]">{t('Ações') || 'Ações'}</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {providers.length === 0 ? (
          <TableRow>
            <TableCell colSpan={7} className="h-24 text-center">
              {t('Nenhum profissional cadastrado.') || 'Nenhum profissional cadastrado.'}
            </TableCell>
          </TableRow>
        ) : (
          providers.map((provider) => (
            <TableRow key={provider.id} className={!provider.active ? "bg-gray-100 dark:bg-gray-800" : ""}>
              <TableCell>{provider.name}</TableCell>
              <TableCell>{getServiceTypeName(provider.service_type)}</TableCell>
              <TableCell>{getCountryName(provider.country || 'BR')}</TableCell>
              <TableCell>{getStateName(provider.state)}</TableCell>
              <TableCell>{getCityName(provider.city)}</TableCell>
              <TableCell>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${provider.active ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'}`}>
                  {provider.active ? (t('provider.active') || 'Ativo') : (t('provider.inactive') || 'Inativo')}
                </span>
              </TableCell>
              <TableCell className="space-x-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => onView(provider.id)}
                  title={t('Visualizar') || 'Visualizar'}
                >
                  <Eye className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => onEdit(provider.id)}
                  title={t('Editar') || 'Editar'}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => onToggleActive(provider)}
                  title={provider.active ? (t('common.deactivate') || 'Inativar') : (t('common.activate') || 'Ativar')}
                  className={provider.active ? "text-red-600 hover:text-red-700" : "text-green-600 hover:text-green-700"}
                >
                  <XCircle className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => onDelete(provider)}
                  title={t('Excluir') || 'Excluir'}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
};
