
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { ProviderProfile } from '@/types/provider';

interface ToggleActiveDialogProps {
  provider: ProviderProfile | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
  loading: boolean;
}

export const ToggleActiveDialog: React.FC<ToggleActiveDialogProps> = ({
  provider,
  isOpen,
  onOpenChange,
  onConfirm,
  loading,
}) => {
  const { t } = useLanguage();

  if (!provider) return null;

  const handleConfirm = async (e: React.MouseEvent) => {
    e.preventDefault();
    await onConfirm();
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {provider.active 
              ? (t('Confirmar inativação') || 'Confirmar inativação') 
              : (t('Confirmar ativação') || 'Confirmar ativação')}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {provider.active
              ? (t('Tem certeza que deseja inativar este profissional? Ele não aparecerá nos resultados de busca.') || 'Tem certeza que deseja inativar este profissional? Ele não aparecerá nos resultados de busca.')
              : (t('Tem certeza que deseja ativar este profissional? Ele voltará a aparecer nos resultados de busca.') || 'Tem certeza que deseja ativar este profissional? Ele voltará a aparecer nos resultados de busca.')}
            <p className="font-medium mt-2">{provider.name}</p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>
            {t('Cancelar') || 'Cancelar'}
          </AlertDialogCancel>
          <AlertDialogAction 
            onClick={handleConfirm}
            disabled={loading}
            className={provider.active ? "bg-red-500 hover:bg-red-600" : "bg-green-500 hover:bg-green-600"}
          >
            {loading 
              ? (provider.active ? (t('Inativando...') || 'Inativando...') : (t('Ativando...') || 'Ativando...'))
              : (provider.active ? (t('Inativar') || 'Inativar') : (t('Ativar') || 'Ativar'))}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
