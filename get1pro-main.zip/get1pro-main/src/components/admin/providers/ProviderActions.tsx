
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { UserPlus, ShieldCheck } from 'lucide-react';
import { AddProviderDialog } from '../AddProviderDialog';
import { SetAdminDialog } from '../SetAdminDialog';

interface ProviderActionsProps {
  onAddProvider: (email: string) => Promise<void>;
  onSetAdmin: (email: string) => Promise<void>;
  loading: boolean;
}

export const ProviderActions = ({ 
  onAddProvider, 
  onSetAdmin, 
  loading 
}: ProviderActionsProps) => {
  const { t } = useLanguage();

  return (
    <div className="flex space-x-2">
      <AddProviderDialog 
        onAddProvider={onAddProvider}
        loading={loading}
      />
      <SetAdminDialog
        onSetAdmin={onSetAdmin}
        loading={loading}
      />
    </div>
  );
};
