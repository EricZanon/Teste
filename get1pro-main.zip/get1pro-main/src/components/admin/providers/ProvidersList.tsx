
import React, { useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ProvidersDataTable } from '../ProvidersDataTable';
import { ProviderActions } from './ProviderActions';
import { useProviderManagement } from '@/hooks/useProviderManagement';
import { EditProviderSheet } from '../EditProviderSheet';
import { DeleteProviderDialog } from '../DeleteProviderDialog';
import { ToggleActiveDialog } from '../ToggleActiveDialog';

export function ProvidersList() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const {
    providers,
    loading,
    loadingAction,
    providerToDelete,
    providerToToggleActive,
    isDeleteDialogOpen,
    isToggleActiveDialogOpen,
    editingProvider,
    isSheetOpen,
    fetchProviders,
    handleCreateProvider,
    handleSetAdmin,
    handleDeleteProvider,
    handleToggleActiveStatus,
    handleEditProfile,
    handleSheetClose,
    setProviderToDelete,
    setProviderToToggleActive,
    setIsDeleteDialogOpen,
    setIsToggleActiveDialogOpen,
  } = useProviderManagement();

  // Fetch providers on component mount
  useEffect(() => {
    console.log('Fetching providers');
    fetchProviders();
  }, []);

  const handleViewProfile = (id: string) => {
    navigate(`/profissional/${id}`);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between">
          <div>
            <CardTitle>{t('Lista de Profissionais') || 'Lista de Profissionais'}</CardTitle>
            <CardDescription>{t('Gerencie todos os profissionais cadastrados no sistema') || 'Gerencie todos os profissionais cadastrados no sistema'}</CardDescription>
          </div>
          <ProviderActions 
            onAddProvider={handleCreateProvider}
            onSetAdmin={handleSetAdmin}
            loading={loadingAction}
          />
        </div>
      </CardHeader>
      <CardContent>
        <ProvidersDataTable 
          providers={providers}
          loading={loading}
          onView={handleViewProfile}
          onEdit={handleEditProfile}
          onToggleActive={(provider) => {
            console.log('Toggle active for provider:', provider);
            setProviderToToggleActive(provider);
            setIsToggleActiveDialogOpen(true);
          }}
          onDelete={(provider) => {
            console.log('Delete provider:', provider);
            setProviderToDelete(provider);
            setIsDeleteDialogOpen(true);
          }}
        />
      </CardContent>

      {/* Edit Provider Sheet */}
      <EditProviderSheet
        providerId={editingProvider}
        isOpen={isSheetOpen}
        onOpenChange={isOpen => !isOpen && handleSheetClose()}
        onSuccess={handleSheetClose}
      />

      {/* Delete Provider Dialog */}
      <DeleteProviderDialog
        provider={providerToDelete}
        isOpen={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteProvider}
        loading={loadingAction}
      />

      {/* Toggle Active Status Dialog */}
      <ToggleActiveDialog
        provider={providerToToggleActive}
        isOpen={isToggleActiveDialogOpen}
        onOpenChange={setIsToggleActiveDialogOpen}
        onConfirm={handleToggleActiveStatus}
        loading={loadingAction}
      />
    </Card>
  );
}
