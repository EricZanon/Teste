
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle 
} from '@/components/ui/sheet';
import ProfessionalProfileForm from '@/components/settings/ProfessionalProfileForm';

interface EditProviderSheetProps {
  providerId: string | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export const EditProviderSheet: React.FC<EditProviderSheetProps> = ({
  providerId,
  isOpen,
  onOpenChange,
  onSuccess,
}) => {
  const { t } = useLanguage();

  const handleSuccess = () => {
    console.log('Provider edit successful, closing sheet');
    onSuccess();
  };

  // Don't render if no providerId
  if (!providerId) {
    console.log('EditProviderSheet: No providerId provided');
    return null;
  }

  console.log('EditProviderSheet rendering with providerId:', providerId);

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>{t('admin.edit_provider')}</SheetTitle>
        </SheetHeader>
        <div className="py-4">
          <ProfessionalProfileForm 
            userId={providerId} 
            onSuccess={handleSuccess} 
            isAdminEdit={true}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
};
