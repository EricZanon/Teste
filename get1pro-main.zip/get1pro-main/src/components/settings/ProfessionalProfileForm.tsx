
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { useLanguage } from '@/contexts/LanguageContext';
import BasicInfoForm from './provider/BasicInfoForm';
import { LocationForm } from './provider/LocationForm';
import { SocialMediaForm } from './provider/SocialMediaForm';
import { ProfessionalInfoForm } from './provider/ProfessionalInfoForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { profileSchema, ProfileFormData } from './provider/schemas/profileFormSchema';
import { useProfileFormData } from './provider/hooks/useProfileFormData';
import { useProfileFormHandlers } from './provider/hooks/useProfileFormHandlers';
import { Loader2, Save, User, MapPin, Briefcase, Share2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ProfessionalProfileFormProps {
  userId?: string;
  onSuccess?: () => void;
  isAdminEdit?: boolean;
}

const ProfessionalProfileForm: React.FC<ProfessionalProfileFormProps> = ({
  userId,
  onSuccess,
  isAdminEdit = false
}) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: '',
      service_type: '',
      address: '',
      city: '',
      state: '',
      country: 'BR',
      phone: '',
      website: '',
      facebook_url: '',
      instagram_url: '',
      linkedin_url: '',
      phone_contact: '',
      sms_contact: '',
      experience_years: undefined,
      service_region: '',
      about: '',
      profile_image_url: ''
    }
  });

  const { profile, loading, fetchingProfile } = useProfileFormData({
    form,
    userId
  });

  const {
    handlePhoneChange,
    handleImageUpdate,
    handleLocationChange,
    handleCountryChange,
    handleStateChange,
    handleCityChange,
    onSubmit
  } = useProfileFormHandlers({
    form,
    userId,
    onSuccess
  });

  if (fetchingProfile) {
    return (
      <div className="flex items-center justify-center py-8">
        <LoadingSpinner />
        <span className="ml-2">Carregando perfil...</span>
      </div>
    );
  }

  // Obter o telefone principal atual
  const mainPhone = form.watch('phone');

  const handleFormSubmit = async (data: ProfileFormData) => {
    console.log('🚀 Form submit initiated');

    // Show immediate feedback
    toast({
      title: 'Salvando...',
      description: 'Suas informações estão sendo salvas.'
    });

    try {
      await onSubmit(data);
      console.log('✅ Form submit completed successfully');
    } catch (error) {
      console.error('❌ Form submit failed:', error);
      // Error handling is already done in onSubmit, but we can add extra feedback here if needed
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
        <Tabs defaultValue="basic" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 h-auto p-1 bg-muted">
            <TabsTrigger 
              value="basic" 
              className="flex flex-col items-center gap-1 py-2 px-1 text-xs min-h-[2.5rem] data-[state=active]:bg-background data-[state=active]:text-foreground"
            >
              <User className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="font-medium text-[10px] sm:text-xs leading-tight text-center">
                Básico
              </span>
            </TabsTrigger>
            <TabsTrigger 
              value="location" 
              className="flex flex-col items-center gap-1 py-2 px-1 text-xs min-h-[2.5rem] data-[state=active]:bg-background data-[state=active]:text-foreground"
            >
              <MapPin className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="font-medium text-[10px] sm:text-xs leading-tight text-center">
                Local
              </span>
            </TabsTrigger>
            <TabsTrigger 
              value="professional" 
              className="flex flex-col items-center gap-1 py-2 px-1 text-xs min-h-[2.5rem] data-[state=active]:bg-background data-[state=active]:text-foreground"
            >
              <Briefcase className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="font-medium text-[10px] sm:text-xs leading-tight text-center">
                Profissional
              </span>
            </TabsTrigger>
            <TabsTrigger 
              value="social" 
              className="flex flex-col items-center gap-1 py-2 px-1 text-xs min-h-[2.5rem] data-[state=active]:bg-background data-[state=active]:text-foreground"
            >
              <Share2 className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="font-medium text-[10px] sm:text-xs leading-tight text-center">
                Social
              </span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <BasicInfoForm 
              control={form.control} 
              profile={profile} 
              onImageUpdate={handleImageUpdate} 
            />
          </TabsContent>

          <TabsContent value="location" className="space-y-4">
            <LocationForm 
              address={form.watch('address')} 
              city={form.watch('city')} 
              state={form.watch('state')} 
              country={form.watch('country')} 
              onChange={handleLocationChange} 
              onCountryChange={handleCountryChange} 
              onStateChange={handleStateChange} 
              onCityChange={handleCityChange} 
            />
          </TabsContent>

          <TabsContent value="professional" className="space-y-4">
            <ProfessionalInfoForm control={form.control} />
          </TabsContent>

          <TabsContent value="social" className="space-y-4">
            <SocialMediaForm 
              facebookUrl={form.watch('facebook_url')} 
              instagramUrl={form.watch('instagram_url')} 
              googleBusinessUrl={form.watch('linkedin_url')} 
              phoneContact={form.watch('phone_contact')} 
              smsContact={form.watch('sms_contact')} 
              website={form.watch('website')} 
              mainPhone={mainPhone} 
              onChange={handleLocationChange} 
              onPhoneChange={handlePhoneChange} 
            />
          </TabsContent>
        </Tabs>

        <div className="flex flex-col gap-3 pt-4 border-t">
          <Button 
            type="submit" 
            className="w-full" 
            disabled={loading} 
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Salvar Perfil
              </>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default ProfessionalProfileForm;
