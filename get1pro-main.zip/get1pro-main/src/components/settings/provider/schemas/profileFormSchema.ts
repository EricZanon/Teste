
import * as z from 'zod';

export const profileSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório').trim(),
  service_type: z.string().min(1, 'Tipo de serviço é obrigatório').trim(),
  address: z.string().min(1, 'Endereço é obrigatório').trim(),
  city: z.string().min(1, 'Cidade é obrigatória').trim(),
  state: z.string().min(1, 'Estado é obrigatório').trim(),
  country: z.string().min(1, 'País é obrigatório').default('BR'),
  phone: z.string().min(1, 'Telefone é obrigatório').trim(),
  website: z.string().optional().transform(val => val?.trim() || ''),
  facebook_url: z.string().optional().transform(val => val?.trim() || ''),
  instagram_url: z.string().optional().transform(val => val?.trim() || ''),
  linkedin_url: z.string().optional().transform(val => val?.trim() || ''),
  phone_contact: z.string().optional().transform(val => val?.trim() || ''),
  sms_contact: z.string().optional().transform(val => val?.trim() || ''),
  experience_years: z.number().optional().nullable(),
  service_region: z.string().optional().transform(val => val?.trim() || ''),
  about: z.string().optional().transform(val => val?.trim() || ''),
  profile_image_url: z.string().optional().transform(val => val?.trim() || ''),
});

export type ProfileFormData = z.infer<typeof profileSchema>;
