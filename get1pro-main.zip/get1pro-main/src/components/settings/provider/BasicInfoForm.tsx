
import React from 'react';
import { Control } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useLanguage } from '@/contexts/LanguageContext';
import { PhoneInput } from '@/components/ui/phone-input';
import ProfileImageUpload from './ProfileImageUpload';
import { ProviderProfile } from '@/types/provider';
import { useAuth } from '@/contexts/AuthContext';

interface BasicInfoFormProps {
  control: Control<any>;
  profile: Partial<ProviderProfile>;
  onImageUpdate: (imageUrl: string) => void;
}

export default function BasicInfoForm({ control, profile, onImageUpdate }: BasicInfoFormProps) {
  const { t } = useLanguage();
  const { user } = useAuth();

  return (
    <div className="space-y-4">
      <ProfileImageUpload 
        currentImageUrl={profile.profile_image_url || ''}
        onImageUpdate={onImageUpdate}
        providerName={profile.name || ''}
        userId={user?.id || ''}
      />
      
      <FormField
        control={control}
        name="name"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('provider.name')}</FormLabel>
            <FormControl>
              <Input {...field} placeholder={t('provider.namePlaceholder')} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="service_type"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('provider.serviceType')}</FormLabel>
            <FormControl>
              <Input {...field} placeholder={t('provider.serviceTypePlaceholder')} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="phone"
        render={({ field }) => (
          <FormItem>
            <FormLabel>{t('provider.phone')}</FormLabel>
            <FormControl>
              <PhoneInput 
                value={field.value || ''} 
                onChange={field.onChange}
                placeholder="(555) 123-4567"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
