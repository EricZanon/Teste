
import React from 'react';
import { Control } from 'react-hook-form';
import { useLanguage } from '@/contexts/LanguageContext';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Briefcase, MapPin, Info } from 'lucide-react';

interface ProfessionalInfoFormProps {
  control: Control<any>;
}

export function ProfessionalInfoForm({ control }: ProfessionalInfoFormProps) {
  const { t, language } = useLanguage();
  
  // Get the proper placeholder based on the language
  const getServiceRegionPlaceholder = () => {
    return language === 'pt' 
      ? t('provider.service_region_placeholder') + ' (ex: 10km)'
      : t('provider.service_region_placeholder') + ' (ex: 6mi)';
  };
  
  return (
    <>
      <FormField
        control={control}
        name="experience_years"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" /> {t('provider.experience_years')}
            </FormLabel>
            <FormControl>
              <Input
                type="number"
                min="0"
                {...field}
                value={field.value || ''}
                onChange={(e) => {
                  const value = e.target.value;
                  console.log('Experience years input change:', value);
                  field.onChange(value === '' ? undefined : parseInt(value) || undefined);
                }}
                placeholder={t('provider.experience_years_placeholder')}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      
      <FormField
        control={control}
        name="service_region"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <MapPin className="h-4 w-4" /> {t('provider.service_region')}
            </FormLabel>
            <FormControl>
              <Input
                {...field}
                value={field.value || ''}
                onChange={(e) => {
                  console.log('Service region input change:', e.target.value);
                  field.onChange(e.target.value);
                }}
                placeholder={getServiceRegionPlaceholder()}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      
      <FormField
        control={control}
        name="about"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <Info className="h-4 w-4" /> {t('provider.about_info')}
            </FormLabel>
            <FormControl>
              <Textarea
                {...field}
                value={field.value || ''}
                onChange={(e) => {
                  console.log('About textarea change:', e.target.value);
                  field.onChange(e.target.value);
                }}
                placeholder={t('provider.about_placeholder')}
                rows={4}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </>
  );
}
