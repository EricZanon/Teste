
import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ProviderAvatar from '@/components/provider/ProviderAvatar';

interface ProfileImageUploadProps {
  currentImageUrl?: string | null;
  providerName: string;
  userId: string;
  onImageUpdate: (imageUrl: string) => void;
}

const ProfileImageUpload: React.FC<ProfileImageUploadProps> = ({
  currentImageUrl,
  providerName,
  userId,
  onImageUpdate
}) => {
  const [uploading, setUploading] = useState(false);
  const [imageUrl, setImageUrl] = useState(currentImageUrl);
  const [forceRefresh, setForceRefresh] = useState(0); // Force re-render
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Update local image URL when prop changes
  React.useEffect(() => {
    console.log('🔄 ProfileImageUpload: currentImageUrl changed:', currentImageUrl);
    setImageUrl(currentImageUrl);
    setForceRefresh(prev => prev + 1); // Force avatar re-render
  }, [currentImageUrl]);

  const handleFileSelect = () => {
    if (uploading) return;
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !userId) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Erro',
        description: 'Por favor, selecione apenas arquivos de imagem.',
        variant: 'destructive'
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'Erro',
        description: 'A imagem deve ter no máximo 5MB.',
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);

    try {
      console.log('🔄 ProfileImageUpload: Starting upload for user:', userId);
      
      const fileExt = file.name.split('.').pop();
      const timestamp = Date.now();
      const fileName = `${userId}/profile_${timestamp}.${fileExt}`;

      // Delete existing image if any
      if (currentImageUrl) {
        try {
          const urlParts = currentImageUrl.split('/profile-images/');
          if (urlParts.length > 1) {
            const existingPath = urlParts[1].split('?')[0]; // Remove query params
            await supabase.storage
              .from('profile-images')
              .remove([existingPath]);
            console.log('🗑️ ProfileImageUpload: Old image removed');
          }
        } catch (error) {
          console.warn('⚠️ ProfileImageUpload: Could not remove old image:', error);
          // Continue with upload even if old image removal fails
        }
      }

      // Upload new image with unique filename
      const { error: uploadError, data } = await supabase.storage
        .from('profile-images')
        .upload(fileName, file, {
          upsert: true,
          cacheControl: 'no-cache'
        });

      if (uploadError) {
        console.error('❌ ProfileImageUpload: Upload error:', uploadError);
        throw new Error(uploadError.message);
      }

      // Get public URL with cache busting
      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(fileName);

      const finalImageUrl = `${publicUrl}?v=${timestamp}`;

      console.log('✅ ProfileImageUpload: Image uploaded successfully, URL:', finalImageUrl);
      
      // Update local state immediately for instant feedback
      setImageUrl(finalImageUrl);
      setForceRefresh(prev => prev + 1); // Force avatar re-render
      
      // Call the parent's update function to sync with form
      onImageUpdate(finalImageUrl);

      toast({
        title: 'Sucesso',
        description: 'Foto de perfil carregada com sucesso! Clique em "Salvar Perfil" para confirmar.',
        duration: 4000,
      });

    } catch (error: any) {
      console.error('💥 ProfileImageUpload: Error uploading image:', error);
      
      // Reset to previous image on error
      setImageUrl(currentImageUrl);
      setForceRefresh(prev => prev + 1);
      
      let errorMessage = 'Erro ao fazer upload da imagem.';
      
      if (!navigator.onLine) {
        errorMessage = 'Sem conexão com a internet. Verifique sua conexão e tente novamente.';
      } else if (error.message?.includes('rate limit')) {
        errorMessage = 'Muitas tentativas. Aguarde alguns minutos e tente novamente.';
      } else if (error.message?.includes('timeout')) {
        errorMessage = 'Upload demorou muito. Verifique sua conexão e tente novamente.';
      } else if (error.message?.includes('Failed to fetch')) {
        errorMessage = 'Problema de conexão. Verifique sua internet e tente novamente.';
      }
      
      toast({
        title: 'Erro no Upload',
        description: errorMessage,
        variant: 'destructive',
        duration: 5000,
      });
    } finally {
      setUploading(false);
      // Reset input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative" key={`avatar-${forceRefresh}`}>
        <ProviderAvatar 
          name={providerName || 'Usuario'}
          imageUrl={imageUrl}
          size="xl"
        />
        <Button
          type="button"
          size="sm"
          variant="secondary"
          className="absolute -bottom-2 -right-2 rounded-full p-2 h-8 w-8"
          onClick={handleFileSelect}
          disabled={uploading || !userId}
        >
          {uploading ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <Camera className="h-3 w-3" />
          )}
        </Button>
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />
      
      <p className="text-sm text-muted-foreground text-center">
        {uploading ? 'Carregando imagem...' : 'Clique no ícone da câmera para alterar sua foto de perfil'}
      </p>
    </div>
  );
};

export default ProfileImageUpload;
