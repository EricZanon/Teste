
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useSubscription } from '@/hooks/useSubscription';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';
import { PlanCard } from './subscription/PlanCard';
import { SubscriptionStatus } from './subscription/SubscriptionStatus';
import { SubscriptionBanner } from './subscription/SubscriptionBanner';
import { PlansHeader } from './subscription/PlansHeader';

export const SubscriptionPlans = () => {
  const { plans, loading } = useSubscription();
  const { subscription } = useSubscriptionContext();

  return (
    <div className="space-y-6">
      <SubscriptionBanner />
      
      <PlansHeader 
        title="Planos de Assinatura"
        description="Escolha o plano ideal para destacar seu perfil profissional e atrair mais clientes."
      />
      
      <SubscriptionStatus />
      
      <Card>
        <CardHeader>
          <CardTitle>Planos Disponíveis</CardTitle>
          <CardDescription>
            Compare os planos e escolha o que melhor atende às suas necessidades
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
                    <div className="space-y-2">
                      {[...Array(4)].map((_, j) => (
                        <div key={j} className="h-3 bg-gray-200 rounded"></div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {plans.map((plan) => (
                <PlanCard 
                  key={plan.id} 
                  plan={plan}
                  isCurrentPlan={subscription.plan?.id === plan.id && subscription.subscribed}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
