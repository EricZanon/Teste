
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PhoneInput } from '@/components/ui/phone-input';
import { Facebook, Instagram, MessageSquare, Globe, Phone } from 'lucide-react';

interface SocialMediaFormProps {
  facebookUrl: string;
  instagramUrl: string;
  googleBusinessUrl: string;
  phoneContact?: string;
  smsContact?: string;
  website?: string;
  mainPhone?: string; // Adicionar telefone principal
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onPhoneChange: (name: string, value: string) => void;
}

export function SocialMediaForm({ 
  facebookUrl, 
  instagramUrl, 
  googleBusinessUrl,
  phoneContact,
  smsContact,
  website,
  mainPhone, // Telefone principal do BasicInfo
  onChange,
  onPhoneChange
}: SocialMediaFormProps) {
  const { t } = useLanguage();
  
  // Usar o telefone principal como base para contato e SMS
  const syncedPhoneContact = mainPhone || phoneContact || '';
  const syncedSmsContact = mainPhone || smsContact || '';
  
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">
        {t('provider.social_media')} ({t('common.optional')})
      </h3>
      
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Globe className="h-5 w-5 text-blue-600" />
          <Label htmlFor="website" className="flex-1">{t('provider.website')}</Label>
          <Input
            id="website"
            name="website"
            value={website || ''}
            onChange={onChange}
            placeholder="https://yourwebsite.com"
            className="flex-[3]"
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <Phone className="h-5 w-5 text-green-600" />
          <Label htmlFor="phone_contact" className="flex-1">
            {t('provider.phone_contact')}
          </Label>
          <div className="flex-[3]">
            <PhoneInput
              value={syncedPhoneContact}
              onChange={() => {}} // Não permite edição
              placeholder="(555) 123-4567"
              readOnly
              className="bg-muted/50 cursor-not-allowed text-muted-foreground dark:bg-muted/30 dark:text-muted-foreground"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Sincronizado automaticamente com o telefone principal
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <MessageSquare className="h-5 w-5 text-green-500" />
          <Label htmlFor="sms_contact" className="flex-1">
            WhatsApp/SMS
          </Label>
          <div className="flex-[3]">
            <PhoneInput
              value={syncedSmsContact}
              onChange={() => {}} // Não permite edição
              placeholder="(555) 123-4567"
              readOnly
              className="bg-muted/50 cursor-not-allowed text-muted-foreground dark:bg-muted/30 dark:text-muted-foreground"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Sincronizado automaticamente com o telefone principal
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Facebook className="h-5 w-5 text-blue-600" />
          <Label htmlFor="facebook_url" className="flex-1">Facebook</Label>
          <Input
            id="facebook_url"
            name="facebook_url"
            value={facebookUrl || ''}
            onChange={onChange}
            placeholder="https://facebook.com/yourprofile"
            className="flex-[3]"
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <Instagram className="h-5 w-5 text-pink-600" />
          <Label htmlFor="instagram_url" className="flex-1">Instagram</Label>
          <Input
            id="instagram_url"
            name="instagram_url"
            value={instagramUrl || ''}
            onChange={onChange}
            placeholder="https://instagram.com/yourprofile"
            className="flex-[3]"
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="20" 
            height="20" 
            viewBox="0 0 48 48" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="h-5 w-5 text-blue-500"
          >
            <path d="m31.6814,34.8868c-1.9155,1.29-4.3586,2.0718-7.2514,2.0718-5.59,0-10.3395-3.7723-12.04-8.8541v-.0195c-.43-1.29-.6841-2.6582-.6841-4.085s.2541-2.795.6841-4.085c1.7005-5.0818,6.45-8.8541,12.04-8.8541,3.1664,0,5.9809,1.0945,8.2286,3.2055l6.1568-6.1568c-3.7332-3.4791-8.5805-5.6095-14.3855-5.6095-8.4045,0-15.6559,4.8277-19.1936,11.8641-1.4659,2.8927-2.3064,6.1568-2.3064,9.6359s.8405,6.7432,2.3064,9.6359v.0195c3.5377,7.0168,10.7891,11.8445,19.1936,11.8445,5.805,0,10.6718-1.9155,14.2291-5.1991,4.0655-3.7527,6.4109-9.2645,6.4109-15.8123,0-1.5245-.1368-2.9905-.3909-4.3977h-20.2491v8.3264h11.5709c-.5082,2.6777-2.0327,4.945-4.3195,6.4695h0Z"></path>
          </svg>
          <Label htmlFor="linkedin_url" className="flex-1">Google Business</Label>
          <Input
            id="linkedin_url"
            name="linkedin_url"
            value={googleBusinessUrl || ''}
            onChange={onChange}
            placeholder="https://business.google.com/yourbusiness"
            className="flex-[3]"
          />
        </div>
      </div>
    </div>
  );
}
