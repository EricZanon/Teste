
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { useProviderProfile } from '@/hooks/useProviderProfile';
import { useProviderReviews } from '@/hooks/useProviderReviews';
import { useFavoritesContext } from '@/contexts/FavoritesContext';
import { Star, MessageSquare, Share, Facebook, Instagram } from 'lucide-react';
import { useProviderMetrics } from '@/hooks/useProviderMetrics';
import { MainMetricsChart } from './charts/MainMetricsChart';
import { SocialClicksChart } from './charts/SocialClicksChart';
import { MetricsData } from '@/types/metrics';
import { useIsMobile } from '@/hooks/use-mobile';

export const ProviderDashboard = () => {
  const { t } = useLanguage();
  const { profile, fetchingProfile } = useProviderProfile();
  const { reviews } = useProviderReviews(profile?.id);
  const { favorites } = useFavoritesContext();
  const { metrics, loading: loadingMetrics, fetchMetrics, incrementMetric } = useProviderMetrics(profile?.id);
  const isMobile = useIsMobile();
  
  // Função para rastrear cliques em redes sociais
  const trackSocialClick = async (platform: 'facebook' | 'instagram' | 'google_business') => {
    if (profile?.id) {
      await incrementMetric(platform);
    }
  };

  // Função para rastrear compartilhamentos
  const trackShare = async () => {
    if (profile?.id) {
      await incrementMetric('shares');
    }
  };

  // Dados para gráfico de métricas principais
  const mainMetricsData: MetricsData[] = [
    { 
      name: t('favorites.title'), 
      value: favorites?.filter(fav => fav.id === profile?.id)?.length || 0, 
      icon: <Star className="h-4 w-4 text-yellow-400" /> 
    },
    { 
      name: t('review.reviews'), 
      value: reviews?.length || 0, 
      icon: <MessageSquare className="h-4 w-4 text-blue-400" /> 
    },
    { 
      name: t('dashboard.share'), 
      value: metrics?.shares || 0, 
      icon: <Share className="h-4 w-4 text-green-400" /> 
    }
  ];

  // Dados para gráfico de cliques em redes sociais
  const socialClicksData: MetricsData[] = [
    { 
      name: 'Facebook', 
      value: metrics?.facebook_clicks || 0, 
      color: '#4267B2', 
      icon: <Facebook className="h-4 w-4" />,
      onClick: () => trackSocialClick('facebook')
    },
    { 
      name: 'Instagram', 
      value: metrics?.instagram_clicks || 0, 
      color: '#C13584', 
      icon: <Instagram className="h-4 w-4" />,
      onClick: () => trackSocialClick('instagram') 
    },
    { 
      name: t('provider.google_business'), 
      value: metrics?.google_business_clicks || 0, 
      color: '#4285F4', 
      icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
        <path d="m31.6814,34.8868c-1.9155,1.29-4.3586,2.0718-7.2514,2.0718-5.59,0-10.3395-3.7723-12.04-8.8541v-.0195c-.43-1.29-.6841-2.6582-.6841-4.085s.2541-2.795.6841-4.085c1.7005-5.0818,6.45-8.8541,12.04-8.8541,3.1664,0,5.9809,1.0945,8.2286,3.2055l6.1568-6.1568c-3.7332-3.4791-8.5805-5.6095-14.3855-5.6095-8.4045,0-15.6559,4.8277-19.1936,11.8641-1.4659,2.8927-2.3064,6.1568-2.3064,9.6359s.8405,6.7432,2.3064,9.6359v.0195c3.5377,7.0168,10.7891,11.8445,19.1936,11.8445,5.805,0,10.6718-1.9155,14.2291-5.1991,4.0655-3.7527,6.4109-9.2645,6.4109-15.8123,0-1.5245-.1368-2.9905-.3909-4.3977h-20.2491v8.3264h11.5709c-.5082,2.6777-2.0327,4.945-4.3195,6.4695h0Z"></path>
      </svg>,
      onClick: () => trackSocialClick('google_business') 
    }
  ];

  if (fetchingProfile || loadingMetrics) {
    return <div className="flex justify-center p-6">{t('common.loading')}...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{t('dashboard.title')}</CardTitle>
          <CardDescription>
            {t('dashboard.description')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-8">
            {/* Gráfico de Métricas Principais */}
            <MainMetricsChart data={mainMetricsData} />

            {/* Gráfico de Cliques em Redes Sociais */}
            <SocialClicksChart 
              data={socialClicksData} 
              onShareClick={trackShare}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
