
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, CheckCircle, AlertCircle, RefreshCw, AlertTriangle } from 'lucide-react';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';

export const SubscriptionBanner = () => {
  const { subscription, hasActiveSubscription, loading, checkSubscription } = useSubscriptionContext();

  if (loading) {
    return (
      <Card className="mb-6 border-blue-200 bg-blue-50">
        <CardContent className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <RefreshCw className="h-5 w-5 text-blue-600 animate-spin" />
            <span className="text-sm font-medium text-blue-800">
              Verificando status da assinatura...
            </span>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Handle error state
  if (subscription.status === 'error') {
    return (
      <Card className="mb-6 border-red-200 bg-red-50">
        <CardContent className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <div>
              <span className="text-sm font-medium text-red-800">
                Erro ao verificar assinatura
              </span>
              <p className="text-xs text-red-600 mt-1">
                Não foi possível conectar com o servidor. Verifique sua conexão.
              </p>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={checkSubscription}
            className="border-red-300 text-red-700 hover:bg-red-100"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Tentar Novamente
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (hasActiveSubscription) {
    return (
      <Card className="mb-6 border-green-200 bg-green-50">
        <CardContent className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <div>
              <span className="text-sm font-medium text-green-800">
                Assinatura Ativa
              </span>
              {subscription.plan && (
                <p className="text-xs text-green-600 mt-1">
                  Plano {subscription.plan.name} - Renovação: {subscription.current_period_end ? new Date(subscription.current_period_end).toLocaleDateString('pt-BR') : 'N/A'}
                </p>
              )}
            </div>
          </div>
          <Badge variant="default" className="bg-green-600">
            <Crown className="h-3 w-3 mr-1" />
            Premium
          </Badge>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6 border-yellow-200 bg-yellow-50">
      <CardContent className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-600" />
          <div>
            <span className="text-sm font-medium text-yellow-800">
              Nenhuma assinatura ativa
            </span>
            <p className="text-xs text-yellow-600 mt-1">
              Assine um plano para acessar recursos premium
            </p>
          </div>
        </div>
        <Badge variant="outline" className="border-yellow-300 text-yellow-700">
          Gratuito
        </Badge>
      </CardContent>
    </Card>
  );
};
