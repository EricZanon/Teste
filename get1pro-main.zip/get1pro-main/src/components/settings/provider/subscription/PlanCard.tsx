
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';
import { useSubscription } from '@/hooks/useSubscription';

interface PlanCardProps {
  plan: {
    id: string;
    name: string;
    description: string;
    price: number;
    currency: string;
    billing_period: string;
    features: string[];
  };
  isCurrentPlan?: boolean;
}

export const PlanCard: React.FC<PlanCardProps> = ({ plan, isCurrentPlan = false }) => {
  const { subscribe, loading } = useSubscription();

  const handleSubscribe = () => {
    subscribe(plan.id);
  };

  const isRecommended = plan.name === 'Mensal';

  return (
    <Card 
      className={`relative overflow-hidden ${isRecommended ? 'ring-2 ring-primary' : ''} ${isCurrentPlan ? 'border-green-500 bg-green-50' : ''}`}
    >
      {isRecommended && (
        <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-bl-lg">
          Recomendado
        </div>
      )}
      {isCurrentPlan && (
        <div className="absolute top-0 left-0 bg-green-500 text-white text-xs font-medium px-3 py-1 rounded-br-lg">
          Plano Atual
        </div>
      )}
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{plan.name}</CardTitle>
            <CardDescription className="text-sm">{plan.description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pb-4">
        <div className="mb-4">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold">${plan.price.toFixed(2)}</span>
            <span className="text-sm text-muted-foreground">
              /{plan.billing_period === 'month' ? 'mês' : 'ano'}
            </span>
          </div>
          {plan.name === 'Anual' && (
            <div className="text-xs text-muted-foreground mt-1">
              $210 cobrado anualmente
            </div>
          )}
        </div>
        
        <ul className="space-y-2">
          {plan.features.map((feature, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <Check className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      
      <CardFooter className="pt-0">
        <Button 
          onClick={handleSubscribe} 
          disabled={loading || isCurrentPlan}
          className="w-full"
          variant={isRecommended && !isCurrentPlan ? "default" : "outline"}
          size="lg"
        >
          {loading ? 'Processando...' : isCurrentPlan ? 'Plano Atual' : 'Assinar'}
        </Button>
      </CardFooter>
    </Card>
  );
};
