
export const subscriptionPlans = [
  {
    name: 'Teste (1 mês)',
    description: 'Experimentar por um mês',
    price: 25,
    period: '1 mês',
    features: [
      'Destaque nos resultados de busca',
      'Estatísticas detalhadas',
      'Ferramentas de promoção',
      'Suporte prioritário',
    ],
    style: ''
  },
  {
    name: 'Mensal',
    description: 'Pagamento todo mês',
    price: 20,
    period: 'por mês',
    features: [
      'Destaque nos resultados de busca',
      'Estatísticas detalhadas',
      'Ferramentas de promoção',
      'Suporte prioritário',
      'Perfil verificado',
    ],
    style: 'border-primary',
    recommended: true
  },
  {
    name: 'Anual',
    description: 'Melhor valor!',
    price: 210/12,
    actualPrice: 210,
    period: 'por mês',
    billing: 'cobrado anualmente',
    features: [
      'Destaque nos resultados de busca',
      'Estatísticas detalhadas',
      'Ferramentas de promoção',
      'Suporte prioritário',
      'Perfil verificado',
      'Economia de 12.5%',
      'Acesso a recursos beta',
    ],
    style: ''
  }
];

export type SubscriptionPlan = typeof subscriptionPlans[0];
