
import React from 'react';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface PlansHeaderProps {
  title: string;
  description: string;
}

export const PlansHeader: React.FC<PlansHeaderProps> = ({ title, description }) => {
  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-xl">{title}</CardTitle>
        <CardDescription className="text-sm">
          {description}
        </CardDescription>
      </CardHeader>
    </Card>
  );
};
