
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, RefreshCw, Settings } from 'lucide-react';
import { useSubscription } from '@/hooks/useSubscription';
import { useLanguage } from '@/contexts/LanguageContext';

export const SubscriptionStatus = () => {
  const { subscription, loading, manageSubscription, checkSubscription } = useSubscription();
  const { t } = useLanguage();

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default" className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Ativo</Badge>;
      case 'inactive':
        return <Badge variant="secondary"><XCircle className="w-3 h-3 mr-1" />Inativo</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Status da Assinatura</CardTitle>
            <CardDescription>
              Gerencie sua assinatura e veja os detalhes do seu plano atual
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={checkSubscription}
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Atualizar
            </Button>
            {subscription.subscribed && (
              <Button
                variant="outline"
                size="sm"
                onClick={manageSubscription}
                disabled={loading}
              >
                <Settings className="w-4 h-4 mr-2" />
                Gerenciar
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="font-medium">Status:</span>
          {getStatusBadge(subscription.status)}
        </div>
        
        {subscription.plan && (
          <>
            <div className="flex items-center justify-between">
              <span className="font-medium">Plano atual:</span>
              <span>{subscription.plan.name}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="font-medium">Preço:</span>
              <span>${subscription.plan.price.toFixed(2)}/{subscription.plan.billing_period === 'month' ? 'mês' : 'ano'}</span>
            </div>
          </>
        )}
        
        {subscription.current_period_end && (
          <div className="flex items-center justify-between">
            <span className="font-medium">Próxima renovação:</span>
            <span>{formatDate(subscription.current_period_end)}</span>
          </div>
        )}
        
        {!subscription.subscribed && (
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-2">
              Você não possui uma assinatura ativa
            </p>
            <p className="text-xs text-gray-500">
              Escolha um plano abaixo para começar
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
