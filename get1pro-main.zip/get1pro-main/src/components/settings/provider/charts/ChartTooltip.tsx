
import React from 'react';

// CustomTooltipProps interface to handle all Recharts' complex types
export interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    name?: string | number;
    value?: string | number | Array<string | number>;
    payload?: any;
    dataKey?: string | number;  // Accept both string and number
    fill?: string;
    color?: string;
  }>;
  label?: string;
}

// CustomTooltip component with proper TypeScript definitions
export const CustomTooltip = ({ active, payload }: CustomTooltipProps) => {
  if (active && payload && payload.length) {
    const value = payload[0].value;
    // Handle different value types (single value or array)
    const displayValue = Array.isArray(value) ? value.join(', ') : value;
    
    return (
      <div className="bg-background border rounded-md shadow-md p-2 text-sm">
        <p className="font-medium">{payload[0].name}: {displayValue}</p>
      </div>
    );
  }

  return null;
};
