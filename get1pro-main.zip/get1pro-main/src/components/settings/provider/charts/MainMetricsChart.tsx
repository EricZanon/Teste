
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartBarIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer } from '@/components/ui/chart';
import { CustomTooltip } from './ChartTooltip';
import { useLanguage } from '@/contexts/LanguageContext';
import { useIsMobile } from '@/hooks/use-mobile';

interface MetricsData {
  name: string;
  value: number;
  icon?: React.ReactNode;
  color?: string;
}

interface MainMetricsChartProps {
  data: MetricsData[];
}

export const MainMetricsChart: React.FC<MainMetricsChartProps> = ({ data }) => {
  const { t } = useLanguage();
  const isMobile = useIsMobile();
  
  // More compact representation for mobile
  const chartHeight = isMobile ? 200 : 300;
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">
          <div className="flex items-center gap-2">
            <ChartBarIcon className="h-5 w-5" />
            <span>{t('dashboard.main_metrics') || 'Métricas Principais'}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div style={{ height: chartHeight }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 20, bottom: isMobile ? 40 : 20, left: isMobile ? 0 : 20 }}>
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: isMobile ? 10 : 12 }}
                angle={isMobile ? -45 : 0}
                textAnchor={isMobile ? "end" : "middle"}
                height={isMobile ? 60 : 30}
              />
              <YAxis tick={{ fontSize: isMobile ? 10 : 12 }} width={isMobile ? 30 : 40} />
              <Tooltip content={(props) => <CustomTooltip {...props} />} />
              <Bar dataKey="value" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};
