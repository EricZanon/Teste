
import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { Share } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CustomTooltip } from './ChartTooltip';
import { useLanguage } from '@/contexts/LanguageContext';
import { useIsMobile } from '@/hooks/use-mobile';

interface MetricsData {
  name: string;
  value: number;
  icon?: React.ReactNode;
  color?: string;
  onClick?: () => void;
}

interface SocialClicksChartProps {
  data: MetricsData[];
  onShareClick: () => void;
}

export const SocialClicksChart: React.FC<SocialClicksChartProps> = ({ 
  data,
  onShareClick
}) => {
  const { t } = useLanguage();
  const isMobile = useIsMobile();
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  // Adjust chart size based on device
  const outerRadius = isMobile ? 60 : 80;
  
  // Renderização customizada dos labels do gráfico de pizza
  const renderCustomizedLabel = ({ 
    cx, 
    cy, 
    midAngle, 
    innerRadius, 
    outerRadius, 
    percent, 
    index, 
    value 
  }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
    const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontSize={isMobile ? 10 : 12}
      >
        {value}
      </text>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">
          <div className="flex items-center gap-2">
            <Share className="h-5 w-5" />
            <span>{t('dashboard.social_clicks') || 'Cliques em Redes Sociais'}</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomizedLabel}
                outerRadius={outerRadius}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={(props) => <CustomTooltip {...props} />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Legenda com botões clicáveis */}
        <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-2 mt-4`}>
          {data.map((entry, index) => (
            <div 
              key={index} 
              className="flex items-center gap-2 p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
              onClick={entry.onClick}
            >
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry.color || COLORS[index % COLORS.length] }} 
              />
              <div className="flex items-center gap-1">
                {entry.icon}
                <span className="text-sm">{entry.name}: {entry.value}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Botão para simular compartilhamentos */}
        <div className="mt-4">
          <button 
            className="w-full flex items-center justify-center gap-2 p-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            onClick={onShareClick}
          >
            <Share className="h-4 w-4" />
            <span>{isMobile ? 'Compartilhar' : 'Simular Compartilhamento'}</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
};
