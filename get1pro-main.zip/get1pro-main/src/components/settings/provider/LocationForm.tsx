
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import CountrySelect from '@/components/search/CountrySelect';
import StateSelect from '@/components/search/StateSelect';
import CitySelect from '@/components/search/CitySelect';
import { useStates } from '@/hooks/useStates';
import { useCities } from '@/hooks/useCities';
import { useLocationValidation } from '@/hooks/useLocationValidation';

interface LocationFormProps {
  address: string;
  city: string;
  state: string;
  country: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCountryChange: (value: string) => void;
  onStateChange: (value: string) => void;
  onCityChange: (value: string) => void;
}

export function LocationForm({ 
  address, 
  city, 
  state, 
  country, 
  onChange, 
  onCountryChange,
  onStateChange,
  onCityChange
}: LocationFormProps) {
  const { t } = useLanguage();
  const { states } = useStates(country);
  const { cities } = useCities(state, country);

  // Use validation hook to manage location consistency
  useLocationValidation({
    country,
    state,
    city,
    availableStates: states,
    availableCities: cities,
    onStateChange,
    onCityChange
  });

  const handleCountryChange = (newCountry: string) => {
    console.log('LocationForm: Country changing from', country, 'to', newCountry);
    onCountryChange(newCountry);
    
    // Reset state and city when country changes
    if (state) {
      console.log('LocationForm: Clearing state due to country change');
      onStateChange('');
    }
    if (city) {
      console.log('LocationForm: Clearing city due to country change');
      onCityChange('');
    }
  };

  const handleStateChange = (newState: string) => {
    console.log('LocationForm: State changing from', state, 'to', newState);
    onStateChange(newState);
    
    // Reset city when state changes
    if (city && state !== newState) {
      console.log('LocationForm: Clearing city due to state change');
      onCityChange('');
    }
  };

  const handleCityChange = (newCity: string) => {
    console.log('LocationForm: City changing from', city, 'to', newCity);
    onCityChange(newCity);
  };
  
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="address">{t('provider.address')}</Label>
        <Input
          id="address"
          name="address"
          value={address || ''}
          onChange={onChange}
          placeholder={t('provider.address_placeholder')}
          required
        />
      </div>
      
      <div className="space-y-2">
        <CountrySelect
          value={country || 'BR'}
          onChange={handleCountryChange}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <StateSelect
            value={state || ''}
            onChange={handleStateChange}
            countryCode={country || 'BR'}
          />
        </div>
        
        <div className="space-y-2">
          <CitySelect
            value={city || ''}
            onChange={handleCityChange}
            countryCode={country || 'BR'}
            stateCode={state || ''}
          />
        </div>
      </div>
    </>
  );
}
