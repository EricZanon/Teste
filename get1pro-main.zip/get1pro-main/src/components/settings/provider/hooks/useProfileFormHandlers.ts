
import { useCallback } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { useProviderProfile } from '@/hooks/useProviderProfile';
import { cleanPhoneNumber } from '@/utils/phoneUtils';
import { ProfileFormData } from '../schemas/profileFormSchema';

interface UseProfileFormHandlersProps {
  form: UseFormReturn<ProfileFormData>;
  userId?: string;
  onSuccess?: () => void;
}

export function useProfileFormHandlers({ form, userId, onSuccess }: UseProfileFormHandlersProps) {
  const { t } = useLanguage();
  const { toast } = useToast();
  const { updateProfile, saveProfile } = useProviderProfile(userId);

  const handlePhoneChange = useCallback((name: string, value: string) => {
    console.log('📞 Phone change handler:', { name, value });
    form.setValue(name as keyof ProfileFormData, value);
    
    // Only sync contact fields if main phone is changed
    if (name === 'phone') {
      form.setValue('phone_contact', value);
      form.setValue('sms_contact', value);
    }
    
    updateProfile({ [name]: value });
  }, [form, updateProfile]);

  const handleImageUpdate = useCallback((imageUrl: string) => {
    console.log('🖼️ Image update in handler:', imageUrl);
    form.setValue('profile_image_url', imageUrl);
    updateProfile({ profile_image_url: imageUrl });
  }, [form, updateProfile]);

  const handleLocationChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    console.log('📍 Location change:', { name, value });
    form.setValue(name as keyof ProfileFormData, value);
    updateProfile({ [name]: value });
  }, [form, updateProfile]);

  const handleCountryChange = useCallback((value: string) => {
    console.log('🌍 Country changed:', value);
    form.setValue('country', value);
    form.setValue('state', '');
    form.setValue('city', '');
    updateProfile({ country: value, state: '', city: '' });
  }, [form, updateProfile]);

  const handleStateChange = useCallback((value: string) => {
    console.log('🏛️ State changed:', value);
    form.setValue('state', value);
    form.setValue('city', '');
    updateProfile({ state: value, city: '' });
  }, [form, updateProfile]);

  const handleCityChange = useCallback((value: string) => {
    console.log('🏙️ City changed:', value);
    form.setValue('city', value);
    updateProfile({ city: value });
  }, [form, updateProfile]);

  const onSubmit = useCallback(async (data: ProfileFormData) => {
    console.log('🚀 Form submission started with data:', data);
    
    try {
      // Validate required fields
      const requiredFields = ['name', 'service_type', 'address', 'city', 'state', 'phone'];
      const missingFields = requiredFields.filter(field => {
        const value = data[field as keyof ProfileFormData];
        return !value || String(value).trim() === '';
      });
      
      if (missingFields.length > 0) {
        console.error('❌ Missing required fields:', missingFields);
        
        // Map field names to Portuguese
        const fieldNames: Record<string, string> = {
          name: 'Nome',
          service_type: 'Tipo de Serviço', 
          address: 'Endereço',
          city: 'Cidade',
          state: 'Estado',
          phone: 'Telefone'
        };
        
        const missingFieldsPortuguese = missingFields.map(field => fieldNames[field] || field);
        
        toast({
          title: 'Campos Obrigatórios',
          description: `Por favor, preencha: ${missingFieldsPortuguese.join(', ')}`,
          variant: 'destructive',
          duration: 5000,
        });
        return;
      }
      
      // Prepare clean data for save
      const profileDataToSave = {
        name: data.name.trim(),
        service_type: data.service_type.trim(),
        address: data.address.trim(),
        city: data.city.trim(),
        state: data.state.trim(),
        country: data.country || 'BR',
        phone: cleanPhoneNumber(data.phone),
        phone_contact: data.phone_contact?.trim() || cleanPhoneNumber(data.phone),
        sms_contact: data.sms_contact?.trim() || cleanPhoneNumber(data.phone),
        website: data.website?.trim() || null,
        facebook_url: data.facebook_url?.trim() || null,
        instagram_url: data.instagram_url?.trim() || null,
        linkedin_url: data.linkedin_url?.trim() || null,
        experience_years: data.experience_years || null,
        service_region: data.service_region?.trim() || null,
        about: data.about?.trim() || null,
        profile_image_url: data.profile_image_url?.trim() || null,
      };
      
      console.log('📋 Prepared data for save:', profileDataToSave);
      
      // Save to database
      await saveProfile(profileDataToSave);
      
      console.log('✅ Profile saved successfully');
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      console.error('💥 Error in form submission:', error);
      // Error handling is done in saveProfile, so just re-throw
      throw error;
    }
  }, [saveProfile, toast, onSuccess]);

  return {
    handlePhoneChange,
    handleImageUpdate,
    handleLocationChange,
    handleCountryChange,
    handleStateChange,
    handleCityChange,
    onSubmit,
  };
}
