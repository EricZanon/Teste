
import React from 'react';
import { UseFormReturn } from 'react-hook-form';
import { useProviderProfile } from '@/hooks/useProviderProfile';
import { ProfileFormData } from '../schemas/profileFormSchema';

interface UseProfileFormDataProps {
  form: UseFormReturn<ProfileFormData>;
  userId?: string;
}

export function useProfileFormData({ form, userId }: UseProfileFormDataProps) {
  const { profile, loading, fetchingProfile } = useProviderProfile(userId);

  React.useEffect(() => {
    if (profile && !fetchingProfile) {
      console.log('🔄 useProfileFormData: Setting form values from profile:', profile);
      
      // Set form values without forcing phone sync - let user control this
      form.reset({
        name: profile.name || '',
        service_type: profile.service_type || '',
        address: profile.address || '',
        city: profile.city || '',
        state: profile.state || '',
        country: profile.country || 'BR',
        phone: profile.phone || '',
        website: profile.website || '',
        facebook_url: profile.facebook_url || '',
        instagram_url: profile.instagram_url || '',
        linkedin_url: profile.linkedin_url || '',
        phone_contact: profile.phone_contact || '',
        sms_contact: profile.sms_contact || '',
        experience_years: profile.experience_years || undefined,
        service_region: profile.service_region || '',
        about: profile.about || '',
        profile_image_url: profile.profile_image_url || '',
      });
      
      console.log('✅ useProfileFormData: Form reset completed');
    }
  }, [profile, fetchingProfile, form]);

  return {
    profile,
    loading,
    fetchingProfile,
  };
}
