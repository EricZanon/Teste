
import React from 'react';

interface LoadingSpinnerProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  className = "", 
  size = "md" 
}) => {
  const sizeClasses = {
    sm: "h-6 w-6",
    md: "h-10 w-10",
    lg: "h-14 w-14"
  };

  return (
    <div className="flex items-center justify-center py-8">
      <div className={`animate-spin rounded-full ${sizeClasses[size]} border-b-2 border-app-primary ${className}`}></div>
    </div>
  );
};

export default LoadingSpinner;
