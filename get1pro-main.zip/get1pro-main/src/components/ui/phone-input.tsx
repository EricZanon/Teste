
import React from 'react';
import { Input } from '@/components/ui/input';
import { formatPhoneNumber } from '@/utils/phoneUtils';
import { cn } from '@/lib/utils';

interface PhoneInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  value: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
}

export const PhoneInput: React.FC<PhoneInputProps> = ({ 
  value, 
  onChange, 
  placeholder = "(555) 123-4567",
  readOnly = false,
  className,
  ...props 
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (readOnly) return;
    const formatted = formatPhoneNumber(e.target.value);
    onChange(formatted);
  };

  return (
    <Input
      {...props}
      type="tel"
      value={value}
      onChange={handleChange}
      placeholder={placeholder}
      maxLength={14} // (XXX) XXX-XXXX = 14 characters
      readOnly={readOnly}
      className={cn(
        readOnly && "bg-muted/50 cursor-not-allowed text-muted-foreground dark:bg-muted/30 dark:text-muted-foreground border-muted",
        className
      )}
    />
  );
};
