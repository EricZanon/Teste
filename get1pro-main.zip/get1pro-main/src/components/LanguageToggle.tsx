
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { Languages } from "lucide-react";

export function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleLanguage}
      className="rounded-full"
      title={`Switch to ${language === 'pt' ? 'English' : 'Portuguese'}`}
    >
      <Languages className="h-5 w-5" />
    </Button>
  );
}
