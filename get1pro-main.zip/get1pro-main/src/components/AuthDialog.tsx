
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import * as z from 'zod';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogAction } from '@/components/ui/alert-dialog';

interface AuthDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const emailSchema = z.string().email("Invalid email address");
const passwordSchema = z.string().min(6, "Password must be at least 6 characters");
const nameSchema = z.string().min(2, "Name must be at least 2 characters");

export function AuthDialog({ isOpen, onOpenChange }: AuthDialogProps) {
  const [activeTab, setActiveTab] = useState<string>('login');
  const [loading, setLoading] = useState(false);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');

  // Verification dialog state
  const [verificationDialogOpen, setVerificationDialogOpen] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState('');
  const [resendingVerification, setResendingVerification] = useState(false);
  
  // Validation errors
  const [errors, setErrors] = useState<{
    loginEmail?: string;
    loginPassword?: string;
    signupName?: string;
    signupEmail?: string;
    signupPassword?: string;
  }>({});

  const { signIn, signUp, resendVerificationEmail } = useAuth();
  const { toast } = useToast();
  const { t } = useLanguage();

  const validateLoginForm = () => {
    const newErrors: { loginEmail?: string; loginPassword?: string } = {};
    
    try {
      emailSchema.parse(loginEmail);
    } catch (error) {
      if (error instanceof z.ZodError) {
        newErrors.loginEmail = error.errors[0].message;
      }
    }
    
    try {
      passwordSchema.parse(loginPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        newErrors.loginPassword = error.errors[0].message;
      }
    }
    
    setErrors((prevErrors) => ({ ...prevErrors, ...newErrors }));
    return Object.keys(newErrors).length === 0;
  };

  const validateSignupForm = () => {
    const newErrors: { signupName?: string; signupEmail?: string; signupPassword?: string } = {};
    
    try {
      nameSchema.parse(signupName);
    } catch (error) {
      if (error instanceof z.ZodError) {
        newErrors.signupName = error.errors[0].message;
      }
    }
    
    try {
      emailSchema.parse(signupEmail);
    } catch (error) {
      if (error instanceof z.ZodError) {
        newErrors.signupEmail = error.errors[0].message;
      }
    }
    
    try {
      passwordSchema.parse(signupPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        newErrors.signupPassword = error.errors[0].message;
      }
    }
    
    setErrors((prevErrors) => ({ ...prevErrors, ...newErrors }));
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateLoginForm()) {
      return;
    }
    
    setLoading(true);
    try {
      const result = await signIn(loginEmail, loginPassword);
      
      if (!result.success) {
        if (result.error?.includes("Email not confirmed")) {
          // Show verification dialog if email not confirmed
          setVerificationEmail(loginEmail);
          setVerificationDialogOpen(true);
        } else {
          toast({
            variant: "destructive",
            title: "Login failed",
            description: result.error || "Please check your credentials and try again",
          });
        }
      } else {
        onOpenChange(false);
        resetForms();
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login error",
        description: error.message || "An unexpected error occurred",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateSignupForm()) {
      return;
    }
    
    setLoading(true);
    try {
      const result = await signUp(signupEmail, signupPassword, signupName);
      
      if (!result.success) {
        toast({
          variant: "destructive",
          title: "Sign up failed",
          description: result.error || "Please check your information and try again",
        });
      } else {
        setVerificationEmail(signupEmail);
        setVerificationDialogOpen(true);
        onOpenChange(false);
        resetForms();
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Sign up error",
        description: error.message || "An unexpected error occurred",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResendVerification = async () => {
    if (!verificationEmail) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Email address is required",
      });
      return;
    }

    setResendingVerification(true);
    try {
      const result = await resendVerificationEmail(verificationEmail);
      
      if (!result.success) {
        toast({
          variant: "destructive",
          title: "Failed to resend verification",
          description: result.error || "An error occurred while sending the verification email",
        });
      } else {
        toast({
          title: "Verification email sent",
          description: `A new verification email has been sent to ${verificationEmail}`,
        });
        setVerificationDialogOpen(false);
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "An unexpected error occurred",
      });
    } finally {
      setResendingVerification(false);
    }
  };

  const resetForms = () => {
    setLoginEmail('');
    setLoginPassword('');
    setSignupName('');
    setSignupEmail('');
    setSignupPassword('');
    setErrors({});
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setErrors({});
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t('Área do Usuário')}</DialogTitle>
            <DialogDescription>
              {t('Entre com os seus dados para acessar o sistema')}
            </DialogDescription>
          </DialogHeader>
          
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">{t('Login')}</TabsTrigger>
              <TabsTrigger value="signup">{t('Criar Conta')}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="email">{t('E-mail')}</Label>
                  <Input
                    id="email"
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="seu@email.com"
                    disabled={loading}
                  />
                  {errors.loginEmail && (
                    <p className="text-sm text-red-500">{errors.loginEmail}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">{t('Senha')}</Label>
                  <Input
                    id="password"
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    disabled={loading}
                  />
                  {errors.loginPassword && (
                    <p className="text-sm text-red-500">{errors.loginPassword}</p>
                  )}
                </div>
                
                <DialogFooter>
                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('auth.loggingIn')}
                      </>
                    ) : (
                      t('Entrar')
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </TabsContent>
            
            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t('Nome')}</Label>
                  <Input
                    id="name"
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                    placeholder={t('Insira seu nome')}
                    disabled={loading}
                  />
                  {errors.signupName && (
                    <p className="text-sm text-red-500">{errors.signupName}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="signup-email">{t('E-mail')}</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="seu@email.com"
                    disabled={loading}
                  />
                  {errors.signupEmail && (
                    <p className="text-sm text-red-500">{errors.signupEmail}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="signup-password">{t('Senha')}</Label>
                  <Input
                    id="signup-password"
                    type="password"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    disabled={loading}
                  />
                  {errors.signupPassword && (
                    <p className="text-sm text-red-500">{errors.signupPassword}</p>
                  )}
                </div>
                
                <DialogFooter>
                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('auth.signingUp')}
                      </>
                    ) : (
                      t('Cadastrar')
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      <AlertDialog open={verificationDialogOpen} onOpenChange={setVerificationDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Verify Your Email</AlertDialogTitle>
            <AlertDialogDescription>
              Please check your email inbox for a verification link. If you didn't receive it, you can request a new one.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button
              variant="outline"
              onClick={() => setVerificationDialogOpen(false)}
            >
              Close
            </Button>
            <Button 
              onClick={handleResendVerification}
              disabled={resendingVerification}
            >
              {resendingVerification ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                'Resend Verification Email'
              )}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
