
import React from 'react';
import { Card } from '@/components/ui/card';
import RatingStars from '@/components/RatingStars';

interface ReviewCardProps {
  name: string;
  rating: number;
  comment: string;
  created_at: string;
}

const ReviewCard = ({ name, rating, comment, created_at }: ReviewCardProps) => {
  // Format the date string to a more readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  return (
    <Card className="bg-white dark:bg-gray-800 p-4" style={{boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'}}>
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-semibold dark:text-white">{name}</h3>
          <RatingStars rating={rating} />
        </div>
        <span className="text-sm text-gray-500 dark:text-gray-400">
          {formatDate(created_at)}
        </span>
      </div>
      <p className="text-gray-700 dark:text-gray-300">{comment}</p>
    </Card>
  );
};

export default ReviewCard;
