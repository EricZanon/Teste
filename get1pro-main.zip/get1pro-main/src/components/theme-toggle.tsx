
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export function ThemeToggle() {
  const { theme, setTheme, systemTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Button variant="outline" size="icon" className="rounded-full">
        <div className="h-[1.2rem] w-[1.2rem]" />
        <span className="sr-only">Toggle theme</span>
      </Button>
    )
  }

  // Use resolvedTheme to get the actual applied theme
  const isDark = resolvedTheme === "dark"

  const toggleTheme = () => {
    console.log('Current theme:', theme, 'Resolved theme:', resolvedTheme, 'System theme:', systemTheme)
    
    if (theme === "system") {
      // If using system theme, switch to the opposite of the current resolved theme
      const newTheme = resolvedTheme === "dark" ? "light" : "dark"
      console.log('Switching from system to:', newTheme)
      setTheme(newTheme)
    } else {
      // Toggle between light and dark
      const newTheme = theme === "dark" ? "light" : "dark"
      console.log('Toggling to:', newTheme)
      setTheme(newTheme)
    }
  }

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleTheme}
      className="rounded-full transition-colors"
    >
      {isDark ? (
        <Sun className="h-[1.2rem] w-[1.2rem] transition-all" />
      ) : (
        <Moon className="h-[1.2rem] w-[1.2rem] transition-all" />
      )}
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}
