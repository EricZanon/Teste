
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const ProviderNotFound: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <h1 className="text-2xl font-bold mb-4">{t('provider.notFound')}</h1>
      <Button onClick={() => navigate('/')} variant="outline" className="flex items-center gap-2">
        <ArrowLeft className="h-4 w-4" /> {t('provider.backToHome')}
      </Button>
    </div>
  );
};

export default ProviderNotFound;
