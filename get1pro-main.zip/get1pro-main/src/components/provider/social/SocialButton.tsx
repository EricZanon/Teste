
import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { LucideIcon } from 'lucide-react';

interface SocialButtonProps {
  icon: LucideIcon | React.ReactNode;
  tooltip: string;
  onClick: () => void;
  platform?: string;
  size?: 'sm' | 'md' | 'lg';
}

const SocialButton: React.FC<SocialButtonProps> = ({ icon, tooltip, onClick, platform, size = 'md' }) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [isMounted, setIsMounted] = useState(false);
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  
  // Set up mounted state to prevent hydration issues
  useEffect(() => {
    setIsMounted(true);
    
    // For iOS, set focus-related attributes
    if (buttonRef.current && isIOS) {
      // Apply immediate iOS optimizations
      buttonRef.current.setAttribute('tabindex', '0');
      buttonRef.current.style.touchAction = 'manipulation';
      buttonRef.current.style.webkitTapHighlightColor = 'rgba(0,0,0,0)'; // Fixed camelCase
      buttonRef.current.style.userSelect = 'none';
      buttonRef.current.style.cursor = 'pointer';
      
      // Add data attribute for debugging
      buttonRef.current.setAttribute('data-ios-enhanced', 'true');
    }
  }, [isIOS]);
  
  // Enhanced iOS touch handler with multiple event bindings
  useEffect(() => {
    const button = buttonRef.current;
    if (!button || !isIOS) return;
    
    console.log('Setting up iOS touch handlers on SocialButton');
    
    // Direct touch event handler for iOS
    const touchStartHandler = (e: TouchEvent) => {
      console.log('touchstart on social button');
      e.stopPropagation();
    };
    
    const touchEndHandler = (e: TouchEvent) => {
      console.log('touchend on social button');
      e.preventDefault();
      e.stopPropagation();
      
      // Use increased timeout for iOS
      setTimeout(() => {
        console.log('Executing delayed social button action');
        onClick();
      }, 150); // Increased delay for iOS reliability
    };
    
    // Add both touch events with capture phase to ensure they run first
    button.addEventListener('touchstart', touchStartHandler, { passive: false, capture: true });
    button.addEventListener('touchend', touchEndHandler, { passive: false, capture: true });
    
    // Also add click event directly for redundancy on iOS
    const clickHandler = (e: MouseEvent) => {
      console.log('click on social button');
      e.preventDefault();
      e.stopPropagation();
      
      setTimeout(() => {
        onClick();
      }, 150);
    };
    
    button.addEventListener('click', clickHandler, { capture: true });
    
    return () => {
      button.removeEventListener('touchstart', touchStartHandler, { capture: true });
      button.removeEventListener('touchend', touchEndHandler, { capture: true });
      button.removeEventListener('click', clickHandler, { capture: true });
    };
  }, [isIOS, onClick, isMounted]);
  
  // Handle click for non-iOS devices
  const handleButtonClick = (e: React.MouseEvent) => {
    if (isIOS) {
      // On iOS, prevent default to avoid double execution (touch handler will handle it)
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    
    // For non-iOS, execute directly
    e.preventDefault();
    e.stopPropagation();
    onClick();
  };

  // Get size classes
  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'h-8 w-8';
      case 'lg':
        return 'h-12 w-12';
      default:
        return 'h-10 w-10';
    }
  };

  // Get icon size
  const getIconSize = () => {
    switch (size) {
      case 'sm':
        return 16;
      case 'lg':
        return 24;
      default:
        return 20;
    }
  };

  // Get icon classes
  const getIconClasses = () => {
    switch (size) {
      case 'sm':
        return 'h-4 w-4';
      case 'lg':
        return 'h-6 w-6';
      default:
        return 'h-5 w-5';
    }
  };
  
  // Get background color based on platform
  const getBackgroundColor = () => {
    switch (platform) {
      case 'facebook':
        return 'bg-blue-600 hover:bg-blue-700';
      case 'instagram':
        return 'bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 hover:from-purple-700 hover:via-pink-700 hover:to-orange-600';
      case 'phone':
        return 'bg-green-600 hover:bg-green-700';
      case 'sms':
        return 'bg-blue-600 hover:bg-blue-700';
      case 'website':
        return 'bg-gray-700 hover:bg-gray-800 dark:bg-gray-600 dark:hover:bg-gray-700';
      case 'googleBusiness':
        return 'bg-red-600 hover:bg-red-700';
      default:
        return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  // Get icon color based on platform
  const getIconColor = () => {
    switch (platform) {
      case 'facebook':
        return 'text-white';
      case 'instagram':
        return 'text-white';
      case 'phone':
        return 'text-white';
      case 'sms':
        return 'text-white';
      case 'website':
        return 'text-white';
      case 'googleBusiness':
        return 'text-white';
      default:
        return 'text-white';
    }
  };
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            ref={buttonRef}
            size="icon" 
            variant="ghost" 
            className={`${getSizeClasses()} rounded-full cursor-pointer touch-manipulation transition-colors duration-200 ${getBackgroundColor()} flex-shrink-0`}
            onClick={handleButtonClick}
            type="button"
            aria-label={tooltip}
            role="button"
            tabIndex={0}
            style={{ 
              WebkitTouchCallout: 'none',
              WebkitUserSelect: 'none',
              touchAction: 'manipulation',
              cursor: 'pointer',
              WebkitTapHighlightColor: 'rgba(0,0,0,0)'
            }} 
            data-social-button="true"
          >
            {React.isValidElement(icon) ? (
              React.cloneElement(icon as React.ReactElement, {
                className: `${getIconClasses()} ${getIconColor()}`
              })
            ) : (
              React.createElement(icon as any, { 
                size: getIconSize(),
                className: getIconColor()
              })
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltip}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default SocialButton;
