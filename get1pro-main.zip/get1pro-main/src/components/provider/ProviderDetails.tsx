
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { ServiceProvider } from '@/types';
import { Briefcase, MapPin, Info } from 'lucide-react';

interface ProviderDetailsProps {
  provider: ServiceProvider;
}

const ProviderDetails: React.FC<ProviderDetailsProps> = ({ provider }) => {
  const { t, language } = useLanguage();

  const formatServiceRegion = () => {
    if (!provider.service_region) {
      return language === 'pt' 
        ? 'Região de atendimento não especificada' 
        : 'Service region not specified';
    }

    if (/\d/.test(provider.service_region)) {
      const numericValue = parseFloat(provider.service_region.replace(/[^\d.]/g, ''));
      if (!isNaN(numericValue)) {
        return language === 'pt' 
          ? `${numericValue}km` 
          : `${Math.round(numericValue * 0.621371)}mi`;
      }
    }

    return provider.service_region;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4" style={{boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'}}>
      <h2 className="text-xl font-semibold mb-3">{t('provider.additionalInfo')}</h2>
      <p className="mb-2"><strong>{t('provider.specialty')}:</strong> {provider.service}</p>
      
      <div className="flex items-center gap-2 mb-2">
        <Briefcase className="h-4 w-4" />
        <p>
          <strong>{t('provider.experience')}:</strong> {provider.experience_years || Math.floor(Math.random() * 10) + 5} {t('provider.years')}
        </p>
      </div>
      
      <div className="flex items-center gap-2 mb-4">
        <MapPin className="h-4 w-4" />
        <p>
          <strong>{t('provider.serviceArea')}:</strong> {formatServiceRegion()}
        </p>
      </div>
      
      <div className="mt-4">
        <div className="flex items-center gap-2 mb-2">
          <Info className="h-4 w-4" />
          <h3 className="text-lg font-semibold">{t('provider.about')}</h3>
        </div>
        <p className="text-gray-600 dark:text-gray-300">
          {provider.about || 
            `${t('provider.about')} ${provider.service.toLowerCase()} com ampla experiência no mercado.
            Atendimento personalizado e comprometido com a qualidade do serviço. Entre em contato
            para mais informações e para agendar uma visita.`
          }
        </p>
      </div>
    </div>
  );
};

export default ProviderDetails;
