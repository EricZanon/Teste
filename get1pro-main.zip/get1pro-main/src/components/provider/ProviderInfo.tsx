
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Info } from 'lucide-react';
import RatingStars from '../RatingStars';
import { useLanguage } from '@/contexts/LanguageContext';
import { useCityName } from '@/hooks/useCityName';
import { formatPhoneForDisplay } from '@/utils/phoneUtils';

interface ProviderInfoProps {
  id: string;
  name: string;
  service: string;
  rating: number;
  phone: string;
  location: {
    address: string;
    city: string;
    state: string;
  };
  reviewCount: number;
  isLoading: boolean;
}

const ProviderInfo: React.FC<ProviderInfoProps> = ({
  id,
  name,
  service,
  rating,
  phone,
  location,
  reviewCount,
  isLoading
}) => {
  const { t } = useLanguage();
  const { cityName } = useCityName(location.city, location.state);

  return (
    <>
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-semibold text-lg dark:text-white">{name}</h3>
          <p className="text-app-darkgray dark:text-gray-300 text-sm">{service}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-2 mb-2">
        <RatingStars rating={rating} />
        <Link to={`/profissional/${id}/avaliacoes`} className="inline-flex items-center gap-1 text-app-primary hover:underline text-xs dark:text-blue-400">
          <span className="flex items-center">
            <MessageSquare className="h-3 w-3 mr-1" />
            {isLoading ? '...' : reviewCount} {reviewCount === 1 ? t('avaliação') : t('avaliações')}
          </span>
        </Link>
      </div>

      <div className="text-sm mb-3 dark:text-gray-300">
        <p className="py-[5px]">📞 {formatPhoneForDisplay(phone)}</p>
        <p className="py-[5px]">📍 {cityName || location.city}, {location.state}</p>
        <Link to={`/profissional/${id}`} className="text-app-darkgray dark:text-gray-400 text-xs flex items-center gap-1 hover:text-app-primary hover:underline" style={{
          marginTop: '5px'
        }}>
          <Info className="h-3 w-3" />
          {t('provider.details')}
        </Link>
      </div>
    </>
  );
};

export default ProviderInfo;
