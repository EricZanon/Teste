
import React from 'react';
import { Phone, Instagram, Facebook, MessageSquare, Globe } from 'lucide-react';
import { useSocialMediaClick } from '@/hooks/useSocialMediaClick';
import SocialButton from './social/SocialButton';
import { useLanguage } from '@/contexts/LanguageContext';

interface SocialMediaButtonsProps {
  providerId: string;
  phone: string;
  socialMedia: {
    instagram?: string;
    facebook?: string;
    sms?: string;
    website?: string;
    googleBusiness?: string;
    phone?: string;
  };
}

const SocialMediaButtons: React.FC<SocialMediaButtonsProps> = ({ providerId, phone, socialMedia }) => {
  const { handlePhoneCall, handleSendSMS, handleSocialClick } = useSocialMediaClick(providerId);
  const { t } = useLanguage();
  
  // Enhanced logging for troubleshooting
  console.log(`SocialMediaButtons rendering for provider ${providerId}:`, {
    phone,
    socialMedia
  });
  
  // Check if there are any social media links to display
  const hasSocials = 
    !!phone ||
    !!socialMedia?.instagram || 
    !!socialMedia?.facebook ||
    !!socialMedia?.website || 
    !!socialMedia?.googleBusiness;

  if (!hasSocials) {
    return null;
  }

  // Google Business Icon
  const GoogleBusinessIcon = (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 48 48"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-4 w-4"
    >
      <path d="m31.6814,34.8868c-1.9155,1.29-4.3586,2.0718-7.2514,2.0718-5.59,0-10.3395-3.7723-12.04-8.8541v-.0195c-.43-1.29-.6841-2.6582-.6841-4.085s.2541-2.795.6841-4.085c1.7005-5.0818,6.45-8.8541,12.04-8.8541,3.1664,0,5.9809,1.0945,8.2286,3.2055l6.1568-6.1568c-3.7332-3.4791-8.5805-5.6095-14.3855-5.6095-8.4045,0-15.6559,4.8277-19.1936,11.8641-1.4659,2.8927-2.3064,6.1568-2.3064,9.6359s.8405,6.7432,2.3064,9.6359v.0195c3.5377,7.0168,10.7891,11.8445,19.1936,11.8445,5.805,0,10.6718-1.9155,14.2291-5.1991,4.0655-3.7527,6.4109-9.2645,6.4109-15.8123,0-1.5245-.1368-2.9905-.3909-4.3977h-20.2491v8.3264h11.5709c-.5082,2.6777-2.0327,4.945-4.3195,6.4695h0Z"></path>
    </svg>
  );

  return (
    <div className="flex flex-wrap gap-1 md:gap-2 justify-start items-center">
      {!!phone && (
        <SocialButton
          icon={Phone}
          tooltip={t('provider.call')}
          platform="phone"
          size="sm"
          onClick={() => {
            console.log('Phone button clicked:', phone);
            handlePhoneCall(phone);
          }}
        />
      )}
      
      {!!socialMedia?.sms && (
        <SocialButton
          icon={MessageSquare}
          tooltip={t('provider.sms')}
          platform="sms"
          size="sm"
          onClick={() => {
            console.log('SMS button clicked:', socialMedia.sms);
            handleSendSMS(socialMedia.sms || '', phone);
          }}
        />
      )}
      
      {!!socialMedia?.instagram && (
        <SocialButton
          icon={Instagram}
          tooltip="Instagram"
          platform="instagram"
          size="sm"
          onClick={() => {
            console.log('Instagram button clicked:', socialMedia.instagram);
            handleSocialClick('instagram', socialMedia.instagram || '');
          }}
        />
      )}
      
      {!!socialMedia?.facebook && (
        <SocialButton
          icon={Facebook}
          tooltip="Facebook"
          platform="facebook"
          size="sm"
          onClick={() => {
            console.log('Facebook button clicked:', socialMedia.facebook);
            handleSocialClick('facebook', socialMedia.facebook || '');
          }}
        />
      )}

      {!!socialMedia?.googleBusiness && (
        <SocialButton
          icon={GoogleBusinessIcon}
          tooltip={t('provider.google_business')}
          platform="googleBusiness"
          size="sm"
          onClick={() => {
            console.log('Google Business button clicked:', socialMedia.googleBusiness);
            handleSocialClick('googleBusiness', socialMedia.googleBusiness || '');
          }}
        />
      )}

      {!!socialMedia?.website && (
        <SocialButton
          icon={Globe}
          tooltip={t('provider.website')}
          platform="website"
          size="sm"
          onClick={() => {
            console.log('Website button clicked:', socialMedia.website);
            handleSocialClick('website', socialMedia.website || '');
          }}
        />
      )}
    </div>
  );
};

export default SocialMediaButtons;
