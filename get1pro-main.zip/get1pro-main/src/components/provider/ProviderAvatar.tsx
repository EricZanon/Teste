
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface ProviderAvatarProps {
  name: string;
  imageUrl?: string | null;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const ProviderAvatar: React.FC<ProviderAvatarProps> = ({ 
  name, 
  imageUrl, 
  size = 'md' 
}) => {
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12', 
    lg: 'h-16 w-16',
    xl: 'h-24 w-24'
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('');
  };

  // Force reload for new images with cache busting
  const getImageWithCacheBuster = (url: string | null | undefined) => {
    if (!url) return undefined;
    
    // If URL already has query params, don't modify it
    if (url.includes('?v=') || url.includes('?t=')) {
      return url;
    }
    
    // Add cache buster for URLs without it
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}cb=${Date.now()}`;
  };

  return (
    <Avatar className={sizeClasses[size]} key={imageUrl || `fallback-${Date.now()}`}>
      <AvatarImage 
        src={getImageWithCacheBuster(imageUrl)} 
        alt={`${name} avatar`}
        onLoad={() => {
          console.log('✅ Avatar image loaded successfully:', imageUrl);
        }}
        onError={(e) => {
          console.log('❌ Avatar image failed to load:', imageUrl);
          // Force fallback by setting src to empty
          e.currentTarget.src = '';
        }}
      />
      <AvatarFallback className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
        {getInitials(name)}
      </AvatarFallback>
    </Avatar>
  );
};

export default ProviderAvatar;
