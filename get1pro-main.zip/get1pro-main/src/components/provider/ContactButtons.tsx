
import React from 'react';
import { Button } from '@/components/ui/button';
import { Phone, MessageSquare } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface ContactButtonsProps {
  phone: string;
  smsNumber?: string;
}

const ContactButtons: React.FC<ContactButtonsProps> = ({ phone, smsNumber }) => {
  const { t } = useLanguage();

  const handlePhoneCall = () => {
    if (phone) {
      window.location.href = `tel:${phone.replace(/\D/g, '')}`;
    }
  };

  const handleSendSMS = () => {
    const phoneNumber = smsNumber || phone;
    if (phoneNumber) {
      window.location.href = `sms:${phoneNumber.replace(/\D/g, '')}`;
    }
  };

  return (
    <div className="flex flex-wrap gap-3 mb-4">
      <Button 
        onClick={handlePhoneCall} 
        variant="outline" 
        size="sm" 
        className="flex items-center gap-2 border-app-primary text-app-primary hover:bg-app-primary/10"
      >
        <Phone className="h-4 w-4" />
        {t('provider.call')}
      </Button>
      
      {(smsNumber || phone) && (
        <Button 
          onClick={handleSendSMS} 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-2 border-app-primary text-app-primary hover:bg-app-primary/10"
        >
          <MessageSquare className="h-4 w-4" />
          {t('provider.sms')}
        </Button>
      )}
    </div>
  );
};

export default ContactButtons;
