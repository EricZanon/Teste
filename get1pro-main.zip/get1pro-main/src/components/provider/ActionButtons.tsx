
import React, { useEffect, useRef } from 'react';
import { Share2, Heart } from 'lucide-react';
import { Button } from '../ui/button';
import { useToast } from '../ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { ServiceProvider } from '@/types';
import { incrementProviderMetric } from '@/services/metricsService';

interface ActionButtonsProps {
  provider: ServiceProvider;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ 
  provider, 
  isFavorite,
  onToggleFavorite 
}) => {
  const { toast } = useToast();
  const { t } = useLanguage();
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  
  // References for direct event handling
  const favoriteButtonRef = useRef<HTMLButtonElement>(null);
  const shareButtonRef = useRef<HTMLButtonElement>(null);

  // Direct touch event handlers for iOS compatibility
  useEffect(() => {
    if (!isIOS) return;
    
    const favoriteBtn = favoriteButtonRef.current;
    const shareBtn = shareButtonRef.current;
    
    if (favoriteBtn) {
      console.log('Setting up iOS touch handler on favorite button');
      
      const handleFavoriteTouch = (e: TouchEvent) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('iOS touch detected on favorite button');
        
        // Use timeout to break iOS event chain
        setTimeout(() => {
          onToggleFavorite();
        }, 100); // Increased delay for iOS
      };
      
      favoriteBtn.addEventListener('touchend', handleFavoriteTouch, { passive: false });
      
      return () => {
        favoriteBtn.removeEventListener('touchend', handleFavoriteTouch);
      };
    }
    
    return () => {};
  }, [isIOS, onToggleFavorite]);
  
  // Separate effect for share button to avoid cleanup issues
  useEffect(() => {
    if (!isIOS) return;
    
    const shareBtn = shareButtonRef.current;
    if (shareBtn) {
      console.log('Setting up iOS touch handler on share button');
      
      const handleShareTouch = (e: TouchEvent) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('iOS touch detected on share button');
        
        // Use timeout to break iOS event chain
        setTimeout(() => {
          handleShare();
        }, 100); // Increased delay for iOS
      };
      
      shareBtn.addEventListener('touchend', handleShareTouch, { passive: false });
      
      return () => {
        shareBtn.removeEventListener('touchend', handleShareTouch);
      };
    }
    
    return () => {};
  }, [isIOS, provider.id]);

  const handleShare = async () => {
    const providerUrl = `${window.location.origin}/profissional/${provider.id}`;
    console.log('Sharing provider URL:', providerUrl);
    
    // Record the share in metrics
    try {
      await incrementProviderMetric(provider.id, 'shares');
    } catch (error) {
      console.error('Error recording share:', error);
    }
    
    // iOS-optimized sharing
    if (navigator.share) {
      try {
        console.log('Using Web Share API');
        await navigator.share({
          title: `${provider.name} - ${provider.service}`,
          text: `${provider.name}, ${provider.service}`,
          url: providerUrl,
        });
        console.log('Content shared successfully');
        
        // Show toast on successful share
        toast({
          description: t('provider.share.success'),
          duration: 2000
        });
        return; // Exit early if successful
      } catch (err) {
        console.error('Error sharing via Web Share API:', err);
        // Continue to fallback
      }
    } 
    
    // Fallback to clipboard
    copyToClipboard(providerUrl);
  };
  
  const copyToClipboard = (text: string) => {
    // Choose the best clipboard method based on platform and capabilities
    if (navigator.clipboard && !isIOS) {
      // Modern clipboard API for non-iOS
      navigator.clipboard.writeText(text)
        .then(() => {
          toast({
            description: t('provider.share.copied'),
            duration: 2000
          });
        })
        .catch((err) => {
          console.error('Clipboard API failed:', err);
          // Fall back to legacy method
          legacyClipboardCopy(text);
        });
    } else {
      // Use legacy method for iOS or as fallback
      legacyClipboardCopy(text);
    }
  };
  
  // iOS-optimized clipboard method
  const legacyClipboardCopy = (text: string) => {
    console.log('Using legacy clipboard method optimized for iOS');
    const textArea = document.createElement('textarea');
    textArea.value = text;
    
    // Style specifically for iOS
    textArea.style.position = 'fixed';
    textArea.style.left = '0';
    textArea.style.top = '0';
    textArea.style.opacity = '0';
    textArea.style.fontSize = '16px'; // Prevents zoom on iOS
    textArea.style.userSelect = 'text'; // Ensures text is selectable on iOS
    
    document.body.appendChild(textArea);
    
    // iOS specific focus and selection
    textArea.focus();
    textArea.select();
    
    try {
      const successful = document.execCommand('copy');
      if (successful) {
        toast({
          description: t('provider.share.copied'),
          duration: 2000
        });
      } else {
        throw new Error('Copy command failed');
      }
    } catch (err) {
      console.error('Fallback clipboard copy failed:', err);
      toast({
        description: t('provider.share.error'),
        duration: 2000
      });
    }
    
    document.body.removeChild(textArea);
  };

  // For non-iOS, still have the onClick handler
  const handleFavoriteClick = (e: React.MouseEvent) => {
    if (isIOS) {
      // For iOS, prevent default behavior to avoid double execution
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    onToggleFavorite();
  };

  const handleShareClick = (e: React.MouseEvent) => {
    if (isIOS) {
      // For iOS, prevent default behavior to avoid double execution
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    handleShare();
  };

  return (
    <div className="flex space-x-2">
      <Button 
        ref={favoriteButtonRef}
        size="icon" 
        variant="ghost" 
        className={`h-8 w-8 ${isFavorite ? 'text-red-500' : 'text-app-darkgray dark:text-gray-400'} touch-manipulation`}
        onClick={handleFavoriteClick}
        aria-label={isFavorite ? t('provider.unfavorite') : t('provider.favorite')}
        style={{ 
          WebkitTouchCallout: 'none',
          WebkitUserSelect: 'none',
          touchAction: 'manipulation',
          cursor: 'pointer'
        }}
      >
        <Heart className="h-4 w-4" fill={isFavorite ? "currentColor" : "none"} />
      </Button>
      <Button 
        ref={shareButtonRef}
        size="icon" 
        variant="ghost" 
        className="h-8 w-8 text-app-darkgray dark:text-gray-400 dark:hover:bg-gray-700 touch-manipulation"
        onClick={handleShareClick}
        aria-label={t('provider.share')}
        style={{ 
          WebkitTouchCallout: 'none',
          WebkitUserSelect: 'none',
          touchAction: 'manipulation',
          cursor: 'pointer'
        }}
      >
        <Share2 className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default ActionButtons;
