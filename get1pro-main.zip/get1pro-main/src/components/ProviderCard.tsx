
import React, { useState, useEffect, useRef } from 'react';
import { ServiceProvider } from '@/types';
import { Card, CardContent } from './ui/card';
import { useFavoritesContext } from '@/contexts/FavoritesContext';
import { useToast } from './ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import ProviderInfo from './provider/ProviderInfo';
import SocialMediaButtons from './provider/SocialMediaButtons';
import ActionButtons from './provider/ActionButtons';
import ProviderAvatar from './provider/ProviderAvatar';
import { useProviderRating } from '@/hooks/useProviderRating';

interface ProviderCardProps {
  provider: ServiceProvider;
}

const ProviderCard: React.FC<ProviderCardProps> = ({ provider }) => {
  // Safely access FavoritesContext - with fallback values if context is not available
  let favorites = {
    isFavorite: (id: string) => false,
    toggleFavorite: (provider: ServiceProvider) => console.warn('Favorites context not available'),
    lastUpdateTime: Date.now()
  };
  
  try {
    favorites = useFavoritesContext();
  } catch (error) {
    console.warn(`FavoritesContext not available for provider ${provider.id}`, error);
  }
  
  const { isFavorite, toggleFavorite, lastUpdateTime } = favorites;
  
  const { toast } = useToast();
  const { t } = useLanguage();
  const cardRef = useRef<HTMLDivElement>(null);
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  
  // Use the rating hook to get real-time rating and review count
  const { rating: realRating, reviewCount: realReviewCount, isLoading: ratingLoading, refreshRating } = useProviderRating(provider.id);
  
  // Generate a unique instance ID for this card to help with React's reconciliation
  const instanceId = useRef(`card-${provider.id}-${Math.random().toString(36).substring(2)}`);

  // Use lastUpdateTime in dependency array to ensure card refreshes when favorites change
  useEffect(() => {
    // Set up real-time listener for new reviews to refresh rating
    const channel = supabase
      .channel('reviews-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'reviews',
          filter: `provider_id=eq.${provider.id}`
        },
        () => {
          console.log('Review updated for provider:', provider.id);
          refreshRating();
        }
      )
      .subscribe();
    
    // Additional touch handling for iOS
    if (isIOS && cardRef.current) {
      console.log(`Setting up iOS touch handling for card ${instanceId.current}`);
      
      // Apply touch-action to make sure iOS recognizes touch events correctly
      if (cardRef.current) {
        // Apply these styles directly and immediately
        cardRef.current.style.touchAction = 'manipulation';
        cardRef.current.style.webkitTapHighlightColor = 'rgba(0,0,0,0)';
        cardRef.current.style.WebkitTouchCallout = 'none';
        
        // Find all buttons and improve their touch handling
        const buttons = cardRef.current.querySelectorAll('button');
        buttons.forEach(button => {
          button.style.touchAction = 'manipulation';
          button.style.webkitTapHighlightColor = 'rgba(0,0,0,0)';
          button.style.cursor = 'pointer';
          button.setAttribute('tabindex', '0');
          
          // Add data attribute to track enhanced buttons
          button.setAttribute('data-ios-enhanced', 'true');
        });
      }
    }

    return () => {
      supabase.removeChannel(channel);
    };
  }, [provider.id, isIOS, lastUpdateTime, refreshRating]);

  const handleFavoriteClick = () => {
    console.log('Toggling favorite with provider:', provider);
    toggleFavorite(provider);
    toast({
      description: isFavorite(provider.id) 
        ? t('favorites.removed')
        : t('favorites.added'),
      duration: 2000
    });
  };

  // Ensure all social media data is properly formatted with website included
  const socialMediaData = {
    website: provider.website || provider.socialMedia?.website || '',
    instagram: provider.socialMedia?.instagram || '',
    facebook: provider.socialMedia?.facebook || '',
    googleBusiness: provider.socialMedia?.googleBusiness || '',
    sms: provider.socialMedia?.sms || provider.phone || '',
    phone: provider.socialMedia?.phone || provider.phone || '',
  };

  console.log(`ProviderCard ${instanceId.current} rendering with real rating: ${realRating}, reviews: ${realReviewCount}`);
  console.log(`ProviderCard ${instanceId.current} avatar URL: ${provider.profile_image_url}`);
  console.log('SocialMediaData being passed:', socialMediaData);

  return (
    <Card 
      ref={cardRef}
      className="mb-4 overflow-hidden border-app-lightgray dark:bg-gray-800 dark:border-gray-700"
      style={{ 
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'rgba(0,0,0,0)',
        WebkitUserSelect: 'none',
        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
      }}
      data-instance-id={instanceId.current}
      data-ios-optimized="true"
    >
      <CardContent className="p-4">
        {/* Provider Info with Avatar */}
        <div className="flex items-start gap-3 mb-4">
          <ProviderAvatar 
            name={provider.name}
            imageUrl={provider.profile_image_url}
            size="md"
          />
          <div className="flex-1">
            <ProviderInfo 
              id={provider.id}
              name={provider.name}
              service={provider.service}
              rating={realRating}
              phone={provider.phone}
              location={provider.location}
              reviewCount={realReviewCount}
              isLoading={ratingLoading}
            />
          </div>
        </div>
        
        <div 
          className="flex justify-between items-center mt-4"
          style={{ touchAction: 'manipulation' }}
        >
          <SocialMediaButtons 
            providerId={provider.id}
            phone={provider.phone}
            socialMedia={socialMediaData}
            key={`social-${provider.id}-${lastUpdateTime}`}
          />
          
          <ActionButtons 
            provider={provider}
            isFavorite={isFavorite(provider.id)}
            onToggleFavorite={handleFavoriteClick}
            key={`action-${provider.id}-${lastUpdateTime}`}
          />
        </div>
      </CardContent>
    </Card>
  );
};

// Use React.memo to prevent unnecessary re-renders, but ensure we update when favorites change
export default React.memo(ProviderCard, (prevProps, nextProps) => {
  // Only re-render if the provider ID changes or if there's a significant change in the provider data
  const prevJSON = JSON.stringify(prevProps.provider);
  const nextJSON = JSON.stringify(nextProps.provider);
  return prevProps.provider.id === nextProps.provider.id && prevJSON === nextJSON;
});
