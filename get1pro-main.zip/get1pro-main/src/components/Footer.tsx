
import React from 'react';
import { Heart } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFavoritesContext } from '@/contexts/FavoritesContext';

const Footer: React.FC = () => {
  const isMobile = useIsMobile();
  const { t } = useLanguage();
  const location = useLocation();
  
  // Check if the current page is an admin page
  const isAdminPage = location.pathname.includes('/admin');
  
  // Use different max-width based on page type
  const containerMaxWidth = isAdminPage ? "max-w-[1400px]" : "max-w-[600px]";
  
  // Try to access the FavoritesContext but provide a fallback
  let favoriteCount = 0;
  try {
    const { favorites } = useFavoritesContext();
    favoriteCount = favorites.length;
  } catch (error) {
    console.error('FavoritesContext not available:', error);
  }

  return (
    <footer className="bg-background border-t z-10 w-full mt-auto">
      <div className={`${containerMaxWidth} mx-auto px-4`}>
        <div className="grid grid-cols-3 gap-2 text-xs text-center py-3">
          <a href="#" className="hover:text-primary">
            {t('footer.howTo')}
          </a>
          <Link to="/favoritos" className="flex items-center justify-center gap-2 hover:text-primary">
            <Heart className="h-4 w-4" />
            <span>{t('footer.favorites')} ({favoriteCount})</span>
          </Link>
          <a href="#" className="hover:text-primary">
            {t('footer.contact')}
          </a>
        </div>
        <div className="text-center text-xs text-muted-foreground pb-3">
          {t('footer.copyright')}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
