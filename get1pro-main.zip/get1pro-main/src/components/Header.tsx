
import React, { useState } from 'react';
import { ThemeToggle } from "./theme-toggle";
import { LanguageToggle } from "./LanguageToggle";
import { useLanguage } from "@/contexts/LanguageContext";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";
import { AuthDialog } from "./AuthDialog";
import { useAuth } from "@/contexts/AuthContext";
import { UserMenu } from "./UserMenu";
import { useTheme } from "next-themes";
import { useFilterContext } from "@/contexts/FilterContext";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const Header = () => {
  const { t } = useLanguage();
  const { user, loading } = useAuth();
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  
  // Get reset function from FilterContext
  let resetFilters: (() => void) | null = null;
  try {
    const filterContext = useFilterContext();
    resetFilters = filterContext.resetFilters;
  } catch (error) {
    // FilterContext not available, which is fine for some pages
    console.log('FilterContext not available in Header');
  }
  
  // Check if the current page is an admin page
  const isAdminPage = location.pathname.includes('/admin');
  
  // Use different max-width based on page type
  const containerMaxWidth = isAdminPage ? "max-w-[1400px]" : "max-w-[600px]";
  
  // Handle logo click to reset filters and navigate to home
  const handleLogoClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Reset filters if available
    if (resetFilters) {
      resetFilters();
    }
    
    // Navigate to home
    navigate('/');
  };
  
  return (
    <header className="w-full bg-background border-b fixed left-0 right-0 top-0 z-50">
      <div className={`${containerMaxWidth} mx-auto px-4 h-16`}>
        <div className="flex items-center justify-between h-full">
          {/* Logo container with exact sizing */}
          <div className="flex items-center flex-shrink-0 h-full">
            <a href="/" onClick={handleLogoClick} className="flex items-center gap-2 py-3">
              {theme === 'dark' 
                ? <img src="/lovable-uploads/aadf16b5-4664-4223-a9c5-e93309c9c4f3.png" alt="Get1Pro Logo" className="h-8 w-auto object-contain" /> 
                : <img src="/lovable-uploads/df1e89c1-842a-4041-aca0-31f96ef5556d.png" alt="Get1Pro Logo" className="h-8 w-auto object-contain" />
              }
            </a>
          </div>

          {/* User controls with consistent spacing */}
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex-shrink-0">
                    <ThemeToggle />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{theme === 'dark' ? t('theme.toggle.light') || 'Light Mode' : t('theme.toggle.dark') || 'Dark Mode'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex-shrink-0">
                    <LanguageToggle />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{t('language.toggle') || 'Change Language'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            {!loading && (user 
              ? <UserMenu /> 
              : <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline" 
                        size="icon" 
                        onClick={() => setAuthDialogOpen(true)} 
                        className="rounded-full flex-shrink-0"
                      >
                        <User className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{t('auth.login') || 'Login/Register'}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            <AuthDialog isOpen={authDialogOpen} onOpenChange={setAuthDialogOpen} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
