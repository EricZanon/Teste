
/// <reference types="vite/client" />

// Google Maps API TypeScript declarations
interface Window {
  google: typeof google;
}

// Add WebKit-specific CSS properties to TypeScript's CSSStyleDeclaration interface
interface CSSStyleDeclaration {
  WebkitTapHighlightColor: string;
  webkitTapHighlightColor: string;
  WebkitTouchCallout: string;
  webkitTouchCallout: string;
  WebkitUserSelect: string;
  webkitUserSelect: string;
}

declare namespace google {
  namespace maps {
    class DistanceMatrixService {
      getDistanceMatrix(
        request: DistanceMatrixRequest,
        callback: (response: DistanceMatrixResponse, status: DistanceMatrixStatus) => void
      ): void;
    }

    class Geocoder {
      geocode(
        request: GeocoderRequest,
        callback: (results: GeocoderResult[], status: GeocoderStatus) => void
      ): void;
    }

    interface DistanceMatrixRequest {
      origins: (LatLng | LatLngLiteral | string)[];
      destinations: (LatLng | LatLngLiteral | string)[];
      travelMode: TravelMode;
      unitSystem: UnitSystem;
    }

    interface LatLng {
      lat(): number;
      lng(): number;
    }

    interface LatLngLiteral {
      lat: number;
      lng: number;
    }

    interface DistanceMatrixResponse {
      rows: DistanceMatrixRow[];
    }

    interface DistanceMatrixRow {
      elements: DistanceMatrixElement[];
    }

    interface DistanceMatrixElement {
      status: string;
      distance?: {
        text: string;
        value: number;
      };
      duration?: {
        text: string;
        value: number;
      };
    }

    interface GeocoderRequest {
      address?: string;
      location?: LatLng | LatLngLiteral;
      bounds?: LatLngBounds;
      componentRestrictions?: GeocoderComponentRestrictions;
      region?: string;
    }

    interface GeocoderResult {
      geometry: {
        location: LatLng;
      };
      address_components: AddressComponent[];
      formatted_address?: string;
      place_id?: string;
      types?: string[];
    }

    interface AddressComponent {
      long_name: string;
      short_name: string;
      types: string[];
    }

    interface GeocoderComponentRestrictions {
      country: string | string[];
    }

    interface LatLngBounds {
      getSouthWest(): LatLng;
      getNorthEast(): LatLng;
    }

    enum TravelMode {
      DRIVING = "DRIVING",
      WALKING = "WALKING",
      BICYCLING = "BICYCLING",
      TRANSIT = "TRANSIT"
    }

    enum UnitSystem {
      METRIC = 0,
      IMPERIAL = 1
    }

    type DistanceMatrixStatus = "OK" | "INVALID_REQUEST" | "MAX_ELEMENTS_EXCEEDED" | "MAX_DIMENSIONS_EXCEEDED" | "OVER_QUERY_LIMIT" | "REQUEST_DENIED" | "UNKNOWN_ERROR";
    type GeocoderStatus = "OK" | "ZERO_RESULTS" | "OVER_QUERY_LIMIT" | "REQUEST_DENIED" | "INVALID_REQUEST" | "UNKNOWN_ERROR";
  }
}
