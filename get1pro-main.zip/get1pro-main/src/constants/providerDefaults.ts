
import { ProviderProfile } from '@/types/provider';

/**
 * Default empty provider profile state
 */
export const DEFAULT_PROVIDER_PROFILE: Partial<ProviderProfile> = {
  name: '',
  service_type: '',
  address: '',
  city: '',
  state: '',
  country: 'BR',  // Default to Brazil
  phone: '',
  website: '',
  facebook_url: '',
  instagram_url: '',
  linkedin_url: '', // Using linkedin_url for Google Business
  phone_contact: '',
  sms_contact: '',
  // Additional fields
  experience_years: null,
  service_region: null,
  about: null,
};
